import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json();
    const conversation_id = body?.conversation_id;
    const deleted_by = body?.deleted_by;
    if (!conversation_id || typeof conversation_id !== 'string') {
      return Response.json({ error: 'conversation_id requis' }, { status: 400 });
    }
    if (!deleted_by || typeof deleted_by !== 'string') {
      return Response.json({ error: 'deleted_by requis' }, { status: 400 });
    }

    // The two parties are encoded in the conversation_id as "<idA>__<idB>".
    const parties = conversation_id.split('__').filter(Boolean);

    // Record this user's deletion (idempotent: remove previous, then create).
    await base44.asServiceRole.entities.ConversationDeletion
      .deleteMany({ conversation_id, deleted_by })
      .catch(() => {});
    await base44.asServiceRole.entities.ConversationDeletion
      .create({ conversation_id, deleted_by });

    // Check whether both parties have now marked the conversation as deleted.
    const deletions = await base44.asServiceRole.entities.ConversationDeletion
      .filter({ conversation_id })
      .catch(() => []);
    const deletedBy = new Set(deletions.map(d => d.deleted_by));
    const bothDeleted = parties.length === 2 && parties.every(p => deletedBy.has(p));

    if (bothDeleted) {
      // Definitive server-side deletion: remove all messages and deletion records.
      await base44.asServiceRole.entities.ChatMessage
        .deleteMany({ conversation_id });
      await base44.asServiceRole.entities.ConversationDeletion
        .deleteMany({ conversation_id });
      return Response.json({ ok: true, conversation_id, status: 'definitive' });
    }

    return Response.json({ ok: true, conversation_id, status: 'pending_other' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}