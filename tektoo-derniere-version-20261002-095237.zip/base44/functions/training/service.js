import { hashPassword, verifyPassword, bytesToHex } from '../../shared/passwordHash.ts';
import { isTrainerActive, trainingStatus, validateTraining } from '../../shared/trainingRules.js';

export class TrainingError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

const randomToken = (size = 32) => bytesToHex(crypto.getRandomValues(new Uint8Array(size)));
const digest = async (value) => bytesToHex(new Uint8Array(
  await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value))
));
const fail = (message, status = 400) => { throw new TrainingError(message, status); };
const publicTraining = (training) => ({
  id: training.id,
  trainer_id: training.trainer_id,
  trainer_name: training.trainer_name,
  title: training.title,
  starts_at: training.starts_at,
  ends_at: training.ends_at,
  duration_hours: training.duration_hours,
  participant_count: training.participant_count,
  messages_enabled: training.messages_enabled,
  selected_question_id: training.selected_question_id || '',
  has_credentials: Boolean(training.credential_batch),
  cancelled: Boolean(training.cancelled),
  status: trainingStatus(training)
});

async function getRecord(entity, id, message) {
  if (typeof id !== 'string' || !id) fail(message, 401);
  try {
    const record = await entity.get(id);
    if (!record) fail(message, 401);
    return record;
  } catch (error) {
    if (error instanceof TrainingError) throw error;
    if (error?.status === 404 || error?.response?.status === 404) fail(message, 401);
    throw error;
  }
}

async function requireTrainer(entities, body) {
  const account = await getRecord(entities.TechnicianAccount, body.accountId, 'Session invalide. Reconnectez-vous.');
  if (typeof body.sessionToken !== 'string' || !body.sessionToken || account.session_token !== body.sessionToken) {
    fail('Session invalide. Reconnectez-vous.', 401);
  }
  const technician = await getRecord(entities.Technician, account.technician_id, 'Profil introuvable.');
  if (!isTrainerActive(technician)) fail('Votre accès Formateur est expiré ou non activé. Contactez Admin Pro.', 403);
  return technician;
}

async function authorize(entities, body, training) {
  const trainer = await getRecord(entities.Technician, training.trainer_id, 'Formateur introuvable.');
  if (!isTrainerActive(trainer)) fail('L’espace du formateur n’est plus actif.', 403);
  if (body.accountId) {
    const technician = await requireTrainer(entities, body);
    if (technician.id !== training.trainer_id) fail('Cette formation appartient à un autre formateur.', 403);
    return { id: technician.id, name: technician.name, isTrainer: true };
  }
  if (trainingStatus(training) !== 'live') fail('La session n’est pas ouverte ou est terminée.', 403);
  const access = await getRecord(entities.TrainingAccess, body.accessId, 'Accès participant invalide.');
  if (access.training_id !== training.id || access.batch !== training.credential_batch
    || !(Date.parse(access.expires_at) > Date.now())
    || typeof body.participantToken !== 'string' || !body.participantToken
    || access.token_hash !== await digest(body.participantToken)) {
    fail('Accès participant invalide ou expiré.', 401);
  }
  return { id: access.id, name: access.label, isTrainer: false };
}

export async function handleTraining(base44, body, file) {
  const entities = base44.asServiceRole.entities;
  const action = body.action;
  if (action === 'list') {
    const now = new Date().toISOString();
    const sessions = await entities.TrainingSession.filter({ cancelled: false, ends_at: { $gt: now } }, 'starts_at', 500);
    const trainerIds = [...new Set(sessions.map((session) => session.trainer_id))];
    const trainers = await Promise.all(trainerIds.map(async (id) => {
      try {
        return await entities.Technician.get(id);
      } catch (error) {
        if (error?.status === 404 || error?.response?.status === 404) {
          console.warn('Formation masquée : profil formateur supprimé.', id);
          return null;
        }
        throw error;
      }
    }));
    const activeIds = new Set(trainers.filter((trainer) => isTrainerActive(trainer)).map((trainer) => trainer.id));
    return { trainings: sessions.filter((session) => activeIds.has(session.trainer_id)).map(publicTraining) };
  }
  if (action === 'mine' || action === 'create') {
    const technician = await requireTrainer(entities, body);
    if (action === 'mine') {
      const sessions = await entities.TrainingSession.filter({ trainer_id: technician.id }, '-starts_at', 500);
      return { technician, trainings: sessions.map(publicTraining) };
    }
    let fields;
    try {
      fields = validateTraining(body, technician);
    } catch (error) {
      fail(error.message);
    }
    const training = await entities.TrainingSession.create({
      ...fields, trainer_id: technician.id, trainer_name: technician.name,
      messages_enabled: true, credential_batch: '', cancelled: false, selected_question_id: ''
    });
    return { training: publicTraining(training) };
  }
  const training = await getRecord(entities.TrainingSession, body.trainingId, 'Formation introuvable.');
  if (action === 'info') return { training: publicTraining(training) };
  if (action === 'join') {
    if (trainingStatus(training) !== 'live') fail('Les accès sont utilisables uniquement pendant la session.', 403);
    const trainer = await entities.Technician.get(training.trainer_id);
    if (!isTrainerActive(trainer)) fail('L’espace du formateur n’est plus actif.', 403);
    const username = typeof body.username === 'string' ? body.username.trim().toLowerCase() : '';
    if (!username || username.length > 64 || typeof body.password !== 'string'
      || !body.password || body.password.length > 128) fail('Identifiant et mot de passe requis.');
    const matches = await entities.TrainingAccess.filter({ training_id: training.id, batch: training.credential_batch, username }, undefined, 1);
    const access = matches[0];
    if (!access || !(Date.parse(access.expires_at) > Date.now()) || !await verifyPassword(body.password, access.password_hash)) {
      fail('Identifiant ou mot de passe incorrect.', 401);
    }
    const current = await entities.TrainingSession.get(training.id);
    const currentTrainer = await entities.Technician.get(training.trainer_id);
    if (trainingStatus(current) !== 'live' || !isTrainerActive(currentTrainer)
      || current.credential_batch !== access.batch) fail('Cette session n’est plus accessible.', 403);
    const token = randomToken();
    await entities.TrainingAccess.update(access.id, { token_hash: await digest(token) });
    return { accessId: access.id, participantToken: token, label: access.label, expiresAt: access.expires_at };
  }
  const identity = await authorize(entities, body, training);
  if (action === 'credentials') {
    if (!identity.isTrainer) fail('Action réservée au formateur.', 403);
    if (trainingStatus(training) !== 'scheduled') fail('Les accès ne peuvent être générés qu’avant le début de la session.', 403);
    const batch = randomToken(16);
    const credentials = [];
    // The batch becomes usable only after every seat has been persisted.
    for (let offset = 0; offset < training.participant_count; offset += 10) {
      const rows = await Promise.all(Array.from({ length: Math.min(10, training.participant_count - offset) }, async (_, index) => {
        const label = `Participant ${offset + index + 1}`;
        const username = `f-${randomToken(8)}`;
        const password = randomToken(12);
        await entities.TrainingAccess.create({
          training_id: training.id, batch, username, label,
          password_hash: await hashPassword(password), token_hash: '', expires_at: training.ends_at
        });
        return { label, username, password };
      }));
      credentials.push(...rows);
    }
    const current = await entities.TrainingSession.get(training.id);
    await authorize(entities, body, current);
    if (trainingStatus(current) !== 'scheduled') fail('La session a déjà commencé : génération annulée.', 403);
    await entities.TrainingSession.update(training.id, { credential_batch: batch });
    return { credentials, training: publicTraining({ ...training, credential_batch: batch }) };
  }
  if (action === 'cancel') {
    if (!identity.isTrainer) fail('Action réservée au formateur.', 403);
    await entities.TrainingSession.update(training.id, { cancelled: true, messages_enabled: false });
    return { training: publicTraining({ ...training, cancelled: true, messages_enabled: false }) };
  }
  if (action === 'history') {
    const filter = { training_id: training.id };
    if (body.before) {
      if (!Number.isFinite(Date.parse(body.before))) fail('Curseur invalide.');
      if (!Array.isArray(body.beforeIds) || body.beforeIds.some((id) => typeof id !== 'string')) {
        fail('Identifiants du curseur invalides.');
      }
      filter.created_date = { $lte: body.before };
      filter.id = { $nin: body.beforeIds };
    }
    const messages = await entities.TrainingMessage.filter(filter, '-created_date', 100);
    const selected = training.selected_question_id
      ? await entities.TrainingMessage.get(training.selected_question_id)
      : null;
    const { attachment_uri: selectedUri, ...selectedQuestion } = selected || {};
    return {
      training: publicTraining(training), identity,
      selectedQuestion: selected ? selectedQuestion : null,
      messages: messages.reverse().map(({ attachment_uri, ...message }) => message)
    };
  }
  if (trainingStatus(training) !== 'live') fail('Les échanges sont autorisés uniquement pendant la session.', 403);
  if (action === 'toggle') {
    if (!identity.isTrainer) fail('Action réservée au formateur.', 403);
    if (typeof body.enabled !== 'boolean') fail('État du switch invalide.');
    const updated = await entities.TrainingSession.update(training.id, { messages_enabled: body.enabled });
    return { training: publicTraining(updated) };
  }
  if (action === 'select') {
    if (!identity.isTrainer) fail('Action réservée au formateur.', 403);
    if (body.messageId) {
      const message = await getRecord(entities.TrainingMessage, body.messageId, 'Question introuvable.');
      if (message.training_id !== training.id || message.is_trainer || !message.text) fail('Choisissez une question d’un participant.');
    }
    const updated = await entities.TrainingSession.update(training.id, { selected_question_id: body.messageId || '' });
    return { training: publicTraining(updated) };
  }
  if (action === 'attachment') {
    const message = await getRecord(entities.TrainingMessage, body.messageId, 'Document introuvable.');
    if (message.training_id !== training.id || !message.attachment_uri) fail('Document introuvable.', 404);
    const seconds = Math.max(1, Math.min(300, Math.floor((Date.parse(training.ends_at) - Date.now()) / 1000)));
    return base44.asServiceRole.integrations.Core.CreateFileSignedUrl({ file_uri: message.attachment_uri, expires_in: seconds });
  }
  if (action === 'send') {
    if (!identity.isTrainer && !training.messages_enabled) fail('Le formateur a suspendu les messages des participants.', 403);
    const text = typeof body.text === 'string' ? body.text.trim() : '';
    if (text.length > 4000) fail('Message trop long (4 000 caractères maximum).');
    if (file && !identity.isTrainer) fail('Seul le formateur peut publier des fichiers.', 403);
    if (!text && !file) fail('Saisissez un message ou choisissez un fichier.');
    let attachment = {};
    if (file) {
      const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/mp4', 'video/webm', 'application/pdf', 'text/plain'];
      if (!allowed.includes(file.type) || file.size > 25 * 1024 * 1024 || file.size === 0) {
        fail('Fichier non pris en charge : PDF, texte, image ou vidéo MP4/WebM, 25 Mo maximum.');
      }
      const { file_uri } = await base44.asServiceRole.integrations.Core.UploadPrivateFile({ file });
      attachment = { attachment_uri: file_uri, attachment_name: file.name.slice(0, 180), attachment_type: file.type };
    }
    const current = await entities.TrainingSession.get(training.id);
    await authorize(entities, body, current);
    if (trainingStatus(current) !== 'live') fail('La session est terminée.', 403);
    if (!identity.isTrainer && !current.messages_enabled) fail('Le formateur a suspendu les messages.', 403);
    const message = await entities.TrainingMessage.create({
      training_id: training.id, author_id: identity.id, author_name: identity.name,
      is_trainer: identity.isTrainer, text, ...attachment,
      reply_to: identity.isTrainer ? current.selected_question_id || '' : ''
    });
    const { attachment_uri, ...safe } = message;
    return { message: safe };
  }
  fail('Action inconnue.');
}
