import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { handleTraining, TrainingError } from './service.js';

export default async function (req: Request): Promise<Response> {
  try {
    if (req.method !== 'POST') return Response.json({ error: 'Méthode non autorisée.' }, { status: 405 });
    const base44 = createClientFromRequest(req);
    let body;
    let file: File | undefined;
    if (req.headers.get('content-type')?.includes('multipart/form-data')) {
      const form = await req.formData();
      body = Object.fromEntries([...form.entries()].filter(([, value]) => typeof value === 'string'));
      const upload = form.get('file');
      if (upload instanceof File) file = upload;
    } else {
      try {
        body = await req.json();
      } catch {
        return Response.json({ error: 'Requête JSON invalide.' }, { status: 400 });
      }
    }
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
      return Response.json({ error: 'Requête invalide.' }, { status: 400 });
    }
    const result = await handleTraining(base44, body, file);
    return Response.json(result, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    if (error instanceof TrainingError) return Response.json({ error: error.message }, { status: error.status });
    console.error('Training request failed', error instanceof Error ? error.message : 'Unknown error');
    return Response.json({ error: 'Le service Formation est indisponible. Réessayez.' }, { status: 500 });
  }
}
