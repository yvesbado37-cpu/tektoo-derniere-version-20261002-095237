import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { verifyYvesAdmin } from '../../shared/verifyYvesAdmin.ts';
import { addCalendarMonth } from '../../shared/trainingRules.js';

export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { accountId, sessionToken } = body;
    const account = await verifyYvesAdmin(base44, accountId, sessionToken);
    if (!account) return Response.json({ error: 'Accès admin non autorisé.' }, { status: 401 });

    const action = body.action;

    if (action === 'list') {
      const technicians = await base44.asServiceRole.entities.Technician.list('-created_date', 500);
      return Response.json({ technicians });
    }

    if (action === 'setTrainer') {
      const { technicianId, isTrainer } = body;
      if (!technicianId) return Response.json({ error: 'Technicien requis.' }, { status: 400 });
      if (typeof isTrainer !== 'boolean') return Response.json({ error: 'État Formateur requis.' }, { status: 400 });
      const technician = await base44.asServiceRole.entities.Technician.get(technicianId);
      const now = new Date();
      const previousExpiry = Date.parse(technician.trainer_expires_at || '');
      const activated = technician.is_trainer && Number.isFinite(previousExpiry) && previousExpiry > now.getTime()
        ? new Date(previousExpiry)
        : now;
      const updated = await base44.asServiceRole.entities.Technician.update(technicianId, isTrainer === false ? {
        is_trainer: false, trainer_activated_at: '', trainer_expires_at: ''
      } : {
        is_trainer: true,
        trainer_activated_at: technician.is_trainer && previousExpiry > now.getTime()
          ? technician.trainer_activated_at
          : now.toISOString(),
        trainer_expires_at: addCalendarMonth(activated.toISOString())
      });
      return Response.json({ technician: updated });
    }

    if (action === 'setPro') {
      const { technicianId, plan, activationDate, isPro } = body;
      if (!technicianId) return Response.json({ error: 'Technicien requis.' }, { status: 400 });
      if (isPro === false) {
        const updated = await base44.asServiceRole.entities.Technician.update(technicianId, {
          is_pro: false, pro_plan: '', pro_activated_at: '', pro_expires_at: ''
        });
        return Response.json({ technician: updated });
      }
      if (!plan || !['monthly', 'annual'].includes(plan)) {
        return Response.json({ error: 'Plan requis : mensuel ou annuel.' }, { status: 400 });
      }
      const activated = activationDate ? new Date(activationDate) : new Date();
      if (isNaN(activated.getTime())) {
        return Response.json({ error: 'Date d\u2019activation invalide.' }, { status: 400 });
      }
      const days = plan === 'annual' ? 365 : 30;
      const expires = new Date(activated.getTime() + days * 86400000);
      const updated = await base44.asServiceRole.entities.Technician.update(technicianId, {
        is_pro: true,
        pro_plan: plan,
        pro_activated_at: activated.toISOString(),
        pro_expires_at: expires.toISOString()
      });
      return Response.json({ technician: updated });
    }

    return Response.json({ error: 'Action inconnue.' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: (error as Error).message }, { status: 500 });
  }
}