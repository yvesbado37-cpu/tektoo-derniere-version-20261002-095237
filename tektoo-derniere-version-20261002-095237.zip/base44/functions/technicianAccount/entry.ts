import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { sendWebPush } from './webPush.ts';

const PROFILE_FIELDS = [
  'name', 'nom', 'prenoms', 'trade', 'custom_trade', 'city', 'quartier', 'age',
  'whatsapp', 'description', 'experience', 'available', 'profile_photo',
  'illustration_1', 'illustration_2', 'illustration_3', 'illustration_4',
  'presentation_video', 'cv_url', 'pro_album_1', 'pro_album_2', 'pro_videos'
];

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join('');
}
function hexToBytes(hex: string): Uint8Array {
  const arr = new Uint8Array(hex.length / 2);
  for (let i = 0; i < arr.length; i++) arr[i] = parseInt(hex.substr(i * 2, 2), 16);
  return arr;
}
async function hashPassword(password: string, saltHex?: string): Promise<string> {
  const salt = saltHex ? hexToBytes(saltHex) : crypto.getRandomValues(new Uint8Array(16));
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' }, keyMaterial, 256);
  return bytesToHex(salt) + ':' + bytesToHex(new Uint8Array(bits));
}
async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const saltHex = stored.split(':')[0];
  const computed = await hashPassword(password, saltHex);
  return computed === stored;
}
function newToken(): string {
  return bytesToHex(crypto.getRandomValues(new Uint8Array(32)));
}
function normalizePhone(p: string): string {
  return (p || '').replace(/[^\d+]/g, '');
}
function sanitize(tech: any): any {
  const { password, session_token, ...safe } = tech;
  return safe;
}

export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const action = body.action;

    if (action === 'sendVerification') {
      const phone = normalizePhone(body.phone);
      if (!phone) return Response.json({ error: 'Numéro de téléphone requis.' }, { status: 400 });
      const existing = await base44.asServiceRole.entities.TechnicianAccount.filter({ phone });
      const fullyRegistered = existing.find(a => a.technician_id);
      if (fullyRegistered) {
        return Response.json({ error: 'Ce numéro est déjà inscrit. Connectez-vous.' }, { status: 409 });
      }
      const code = String(Math.floor(100000 + Math.random() * 900000));
      const expires = new Date(Date.now() + 15 * 60 * 1000).toISOString();
      const pending = existing.find(a => !a.technician_id);
      if (pending) {
        await base44.asServiceRole.entities.TechnicianAccount.update(pending.id, { verification_code: code, verification_expires: expires, code_verified: false });
      } else {
        await base44.asServiceRole.entities.TechnicianAccount.create({
          phone,
          verification_code: code,
          verification_expires: expires,
          code_verified: false
        });
      }
      const waPhone = phone.replace('+', '');
      const message = encodeURIComponent(`Votre code de vérification tektoo est : ${code}`);
      return Response.json({ sent: false, method: 'self_link', code, whatsappLink: `https://wa.me/${waPhone}?text=${message}` });
    }

    if (action === 'register') {
      const phone = normalizePhone(body.phone);
      if (!phone) return Response.json({ error: 'Numéro de téléphone requis.' }, { status: 400 });
      if (!body.password || String(body.password).length < 6) {
        return Response.json({ error: 'Mot de passe de 6 caractères minimum requis.' }, { status: 400 });
      }
      const verificationCode = String(body.verificationCode || '').trim();
      const found = await base44.asServiceRole.entities.TechnicianAccount.filter({ phone });
      const fullyRegistered = found.find(a => a.technician_id);
      if (fullyRegistered) {
        return Response.json({ error: 'Ce numéro est déjà inscrit. Connectez-vous.' }, { status: 409 });
      }
      const pending = found.find(a => !a.technician_id);
      if (!pending) {
        return Response.json({ error: 'Aucun code trouvé. Demandez un code de vérification.' }, { status: 400 });
      }
      if (!pending.code_verified) {
        if (!verificationCode) {
          return Response.json({ error: 'Code de vérification requis.' }, { status: 400 });
        }
        if (!pending.verification_code || pending.verification_code !== verificationCode) {
          return Response.json({ error: 'Code de vérification invalide.' }, { status: 400 });
        }
        if (pending.verification_expires && new Date(pending.verification_expires).getTime() < Date.now()) {
          return Response.json({ error: 'Code expiré. Demandez un nouveau code.' }, { status: 400 });
        }
      }
      const submittedProfile = body.profile || {};
      const profile: Record<string, unknown> = {};
      for (const key of PROFILE_FIELDS) {
        if (Object.prototype.hasOwnProperty.call(submittedProfile, key)) profile[key] = submittedProfile[key];
      }
      const technician = await base44.asServiceRole.entities.Technician.create({
        ...profile,
        is_pro: false,
        pro_plan: '',
        pro_activated_at: '',
        pro_expires_at: '',
        is_trainer: false,
        trainer_activated_at: '',
        trainer_expires_at: '',
        phone,
        whatsapp: profile.whatsapp || phone
      });
      const session_token = newToken();
      await base44.asServiceRole.entities.TechnicianAccount.update(pending.id, {
        technician_id: technician.id,
        password: await hashPassword(String(body.password)),
        session_token,
        verification_code: '',
        verification_expires: '',
        code_verified: false
      });
      return Response.json({ technician: sanitize(technician), accountId: pending.id, sessionToken: session_token });
    }

    if (action === 'login') {
      const phone = normalizePhone(body.phone);
      if (!phone || !body.password) {
        return Response.json({ error: 'Téléphone et mot de passe requis.' }, { status: 400 });
      }
      const found = await base44.asServiceRole.entities.TechnicianAccount.filter({ phone });
      const account = found.find(a => a.technician_id);
      if (!account) return Response.json({ error: 'Numéro ou mot de passe incorrect.' }, { status: 401 });
      const ok = await verifyPassword(String(body.password), account.password);
      if (!ok) return Response.json({ error: 'Numéro ou mot de passe incorrect.' }, { status: 401 });
      const session_token = newToken();
      await base44.asServiceRole.entities.TechnicianAccount.update(account.id, { session_token });
      const technician = await base44.asServiceRole.entities.Technician.get(account.technician_id);
      return Response.json({ technician: sanitize(technician), accountId: account.id, sessionToken: session_token });
    }

    if (action === 'update') {
      const { accountId, sessionToken, updates } = body;
      if (!accountId || !sessionToken) return Response.json({ error: 'Session invalide.' }, { status: 401 });
      let account;
      try {
        account = await base44.asServiceRole.entities.TechnicianAccount.get(accountId);
      } catch {
        return Response.json({ error: 'Session invalide ou expirée.' }, { status: 401 });
      }
      if (!account || account.session_token !== sessionToken) {
        return Response.json({ error: 'Session invalide ou expirée.' }, { status: 401 });
      }
      const allowed: Record<string, any> = {};
      for (const k of PROFILE_FIELDS) {
        if (k in (updates || {})) allowed[k] = updates[k];
      }
      const updated = await base44.asServiceRole.entities.Technician.update(account.technician_id, allowed);
      return Response.json({ technician: sanitize(updated) });
    }

    if (action === 'delete') {
      const { accountId, sessionToken } = body;
      if (!accountId || !sessionToken) return Response.json({ error: 'Session invalide.' }, { status: 401 });
      let account;
      try {
        account = await base44.asServiceRole.entities.TechnicianAccount.get(accountId);
      } catch {
        return Response.json({ error: 'Session invalide ou expirée.' }, { status: 401 });
      }
      if (!account || account.session_token !== sessionToken) {
        return Response.json({ error: 'Session invalide ou expirée.' }, { status: 401 });
      }
      await base44.asServiceRole.entities.Technician.delete(account.technician_id);
      await base44.asServiceRole.entities.TechnicianAccount.delete(account.id);
      return Response.json({ ok: true });
    }

    if (action === 'requestReset') {
      const phone = normalizePhone(body.phone);
      if (!phone) return Response.json({ error: 'Numéro de téléphone requis.' }, { status: 400 });
      const found = await base44.asServiceRole.entities.TechnicianAccount.filter({ phone });
      const account = found.find(a => a.technician_id);
      if (!account) return Response.json({ error: 'Aucun compte n’est associé à ce numéro.' }, { status: 404 });
      const code = String(Math.floor(100000 + Math.random() * 900000));
      const recoveryToken = newToken();
      const expires = new Date(Date.now() + 15 * 60 * 1000).toISOString();
      await base44.asServiceRole.entities.TechnicianAccount.update(account.id, { reset_code: code, reset_expires: expires, recovery_token: recoveryToken, code_verified: false });
      const waPhone = phone.replace('+', '');
      const link = `https://tektoo.org/recuperation/${recoveryToken}`;
      const textPart = encodeURIComponent(`tektoo - Récupération de mot de passe\n\nVotre code : ${code}\n\nLien de réinitialisation (envoyez d'abord ce message, puis cliquez sur le lien) :\n`);
      return Response.json({ sent: false, whatsappLink: `https://wa.me/${waPhone}?text=${textPart}${link}` });
    }

    if (action === 'resetPassword') {
      const phone = normalizePhone(body.phone);
      const code = String(body.code || '').trim();
      if (!phone || !body.newPassword || String(body.newPassword).length < 6) {
        return Response.json({ error: 'Numéro et nouveau mot de passe (6 caractères min.) requis.' }, { status: 400 });
      }
      let found = await base44.asServiceRole.entities.TechnicianAccount.filter({ phone });
      let account = found.find(a => a.technician_id);
      if (!account) {
        const digits = phone.replace(/[^\d]/g, '');
        found = await base44.asServiceRole.entities.TechnicianAccount.filter({ phone: `+${digits}` });
        account = found.find(a => a.technician_id);
      }
      if (!account) return Response.json({ error: 'Code invalide ou expiré.' }, { status: 400 });
      if (!account.code_verified) {
        if (!code) {
          return Response.json({ error: 'Code de récupération requis.' }, { status: 400 });
        }
        if (!account.reset_code || account.reset_code !== code) {
          return Response.json({ error: 'Code invalide ou expiré.' }, { status: 400 });
        }
        if (account.reset_expires && new Date(account.reset_expires).getTime() < Date.now()) {
          return Response.json({ error: 'Code expiré. Demandez un nouveau code.' }, { status: 400 });
        }
      }
      await base44.asServiceRole.entities.TechnicianAccount.update(account.id, {
        password: await hashPassword(String(body.newPassword)),
        reset_code: '',
        reset_expires: '',
        code_verified: false,
        session_token: newToken()
      });
      return Response.json({ ok: true });
    }

    if (action === 'validateRecoveryToken') {
      const token = String(body.token || '').trim();
      if (!token) return Response.json({ valid: false }, { status: 400 });
      const found = await base44.asServiceRole.entities.TechnicianAccount.filter({ recovery_token: token });
      const account = found.find(a => a.technician_id);
      if (!account) return Response.json({ valid: false });
      if (account.reset_expires && new Date(account.reset_expires).getTime() < Date.now()) {
        return Response.json({ valid: false, expired: true });
      }
      return Response.json({ valid: true, phone: account.phone });
    }

    if (action === 'resetPasswordWithToken') {
      const token = String(body.token || '').trim();
      const newPassword = String(body.newPassword || '');
      if (!token || newPassword.length < 6) {
        return Response.json({ error: 'Lien et nouveau mot de passe (6 caractères min.) requis.' }, { status: 400 });
      }
      const found = await base44.asServiceRole.entities.TechnicianAccount.filter({ recovery_token: token });
      const account = found.find(a => a.technician_id);
      if (!account) return Response.json({ error: 'Lien invalide ou expiré.' }, { status: 400 });
      if (account.reset_expires && new Date(account.reset_expires).getTime() < Date.now()) {
        return Response.json({ error: 'Lien expiré. Demandez un nouveau lien.' }, { status: 400 });
      }
      await base44.asServiceRole.entities.TechnicianAccount.update(account.id, {
        password: await hashPassword(newPassword),
        reset_code: '',
        reset_expires: '',
        recovery_token: '',
        code_verified: false,
        session_token: newToken()
      });
      return Response.json({ ok: true });
    }

    if (action === 'checkCodeVerified') {
      const phone = normalizePhone(body.phone);
      if (!phone) return Response.json({ verified: false });
      const found = await base44.asServiceRole.entities.TechnicianAccount.filter({ phone });
      const account = found[0];
      if (!account) return Response.json({ verified: false });
      return Response.json({ verified: !!account.code_verified });
    }

    if (action === 'updateLastActive') {
      const { accountId, sessionToken } = body;
      if (!accountId || !sessionToken) return Response.json({ error: 'Session invalide.' }, { status: 401 });
      let account;
      try {
        account = await base44.asServiceRole.entities.TechnicianAccount.get(accountId);
      } catch {
        return Response.json({ error: 'Session invalide ou expirée.' }, { status: 401 });
      }
      if (!account || account.session_token !== sessionToken) {
        return Response.json({ error: 'Session invalide ou expirée.' }, { status: 401 });
      }
      await base44.asServiceRole.entities.TechnicianAccount.update(account.id, { last_active: new Date().toISOString() });
      return Response.json({ ok: true });
    }

    if (action === 'checkRecipientStatus') {
      const { accountId, sessionToken, technician_id } = body;
      if (!accountId || !sessionToken || !technician_id) {
        return Response.json({ error: 'Paramètres manquants.' }, { status: 400 });
      }
      let callerAccount;
      try {
        callerAccount = await base44.asServiceRole.entities.TechnicianAccount.get(accountId);
      } catch {
        return Response.json({ error: 'Session invalide ou expirée.' }, { status: 401 });
      }
      if (!callerAccount || callerAccount.session_token !== sessionToken) {
        return Response.json({ error: 'Session invalide ou expirée.' }, { status: 401 });
      }
      let recipient;
      try {
        recipient = await base44.asServiceRole.entities.Technician.get(technician_id);
      } catch {
        return Response.json({ error: 'Destinataire introuvable.' }, { status: 404 });
      }
      const recipientAccounts = await base44.asServiceRole.entities.TechnicianAccount.filter({ technician_id });
      const recipientAccount = recipientAccounts[0];
      const now = Date.now();
      const lastActive = recipientAccount?.last_active ? new Date(recipientAccount.last_active).getTime() : 0;
      const online = lastActive > 0 && (now - lastActive) < 2 * 60 * 1000;
      return Response.json({
        online,
        phone: recipient?.phone || '',
        whatsapp: recipient?.whatsapp || recipient?.phone || ''
      });
    }

    if (action === 'notifyOffline') {
      const { accountId, sessionToken, technician_id, message_content, conversation_id, sender_name } = body;
      if (!accountId || !sessionToken || !technician_id) {
        return Response.json({ error: 'Paramètres manquants.' }, { status: 400 });
      }
      let callerAccount;
      try {
        callerAccount = await base44.asServiceRole.entities.TechnicianAccount.get(accountId);
      } catch {
        return Response.json({ error: 'Session invalide ou expirée.' }, { status: 401 });
      }
      if (!callerAccount || callerAccount.session_token !== sessionToken) {
        return Response.json({ error: 'Session invalide ou expirée.' }, { status: 401 });
      }
      let recipient;
      try {
        recipient = await base44.asServiceRole.entities.Technician.get(technician_id);
      } catch {
        return Response.json({ error: 'Destinataire introuvable.' }, { status: 404 });
      }
      const recipientAccounts = await base44.asServiceRole.entities.TechnicianAccount.filter({ technician_id });
      const recipientAccount = recipientAccounts[0];
      const now = Date.now();
      const lastActive = recipientAccount?.last_active ? new Date(recipientAccount.last_active).getTime() : 0;
      const online = lastActive > 0 && (now - lastActive) < 2 * 60 * 1000;
      if (online) {
        return Response.json({ sent: false, reason: 'recipient_online' });
      }
      try {
        const subscriptions = await base44.asServiceRole.entities.PushSubscription.filter({ technician_id });
        const pushTitle = sender_name ? `Nouveau message de ${sender_name}` : 'Nouveau message tektoo';
        const pushBody = message_content || "quelqu'un souhaite discuter avec toi sur tektoo";
        const pushUrl = conversation_id ? `/?open_conv=${encodeURIComponent(conversation_id)}` : '/mon-compte';
        const pushPayload = JSON.stringify({ title: pushTitle, body: pushBody, url: pushUrl, tag: conversation_id ? `tektoo_msg_${conversation_id}` : 'tektoo-message' });
        for (const sub of subscriptions) {
          await sendWebPush({ endpoint: sub.endpoint, p256dh_key: sub.p256dh_key, auth_key: sub.auth_key }, pushPayload);
        }
      } catch (e) {
        // Push failed, continue with WhatsApp
      }
      const phone = (recipient.whatsapp || recipient.phone || '').replace(/[^\d]/g, '');
      if (!phone) {
        return Response.json({ sent: false, reason: 'no_phone' });
      }
      const message = encodeURIComponent("quelqu'un souhaite discuter avec toi sur tektoo");
      return Response.json({ sent: false, reason: 'whatsapp_link', whatsappLink: `https://wa.me/${phone}?text=${message}` });
    }

    return Response.json({ error: 'Action inconnue.' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: (error as Error).message }, { status: 500 });
  }
}