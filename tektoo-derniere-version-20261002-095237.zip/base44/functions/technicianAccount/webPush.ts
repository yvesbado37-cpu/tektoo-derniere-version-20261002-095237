// VAPID key pair generated for tektoo web push notifications
const VAPID_PRIVATE_KEY = '{"kty":"EC","x":"ASwVCAF6jqLg2xMZstCnrY_1IP1o5EknFsMZfHh5Iq0","y":"rFtUz2eT5361AlPb4fks0DLeGcG3QXCjwwKIIfkdaSc","crv":"P-256","d":"8Lu1drsx9xMslW3I3kyprpn7yctWSnhjpceDmVUCJB4"}';

function b64urlDecode(str: string): Uint8Array {
  const padded = str.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - str.length % 4) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function b64urlEncode(bytes: Uint8Array): string {
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function hmac(key: Uint8Array, data: Uint8Array): Promise<Uint8Array> {
  const cryptoKey = await crypto.subtle.importKey('raw', key, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return new Uint8Array(await crypto.subtle.sign('HMAC', cryptoKey, data));
}

async function hkdfExtract(salt: Uint8Array, ikm: Uint8Array): Promise<Uint8Array> {
  const effectiveSalt = salt.length > 0 ? salt : new Uint8Array(32);
  return hmac(effectiveSalt, ikm);
}

async function hkdfExpand(prk: Uint8Array, info: Uint8Array, length: number): Promise<Uint8Array> {
  let t = new Uint8Array(0);
  let okm = new Uint8Array(0);
  let counter = 1;
  while (okm.length < length) {
    const input = new Uint8Array(t.length + info.length + 1);
    input.set(t, 0);
    input.set(info, t.length);
    input[input.length - 1] = counter;
    t = await hmac(prk, input);
    const newOkm = new Uint8Array(okm.length + t.length);
    newOkm.set(okm, 0);
    newOkm.set(t, okm.length);
    okm = newOkm;
    counter++;
  }
  return okm.slice(0, length);
}

function derToRaw(der: Uint8Array): Uint8Array {
  let offset = 2;
  if (der[offset] !== 0x02) throw new Error('Invalid DER r');
  offset++;
  const rLen = der[offset];
  offset++;
  const rBytes = der.slice(offset, offset + rLen);
  offset += rLen;
  if (der[offset] !== 0x02) throw new Error('Invalid DER s');
  offset++;
  const sLen = der[offset];
  offset++;
  const sBytes = der.slice(offset, offset + sLen);
  const raw = new Uint8Array(64);
  const rStripped = rBytes[0] === 0 ? rBytes.slice(1) : rBytes;
  raw.set(rStripped, 32 - rStripped.length);
  const sStripped = sBytes[0] === 0 ? sBytes.slice(1) : sBytes;
  raw.set(sStripped, 64 - sStripped.length);
  return raw;
}

async function createVapidJwt(aud: string, jwk: any): Promise<string> {
  const encoder = new TextEncoder();
  const header = b64urlEncode(encoder.encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const payload = b64urlEncode(encoder.encode(JSON.stringify({
    aud,
    exp: Math.floor(Date.now() / 1000) + 12 * 3600,
    sub: 'mailto:contact@tektoo.app'
  })));
  const signingInput = `${header}.${payload}`;
  const key = await crypto.subtle.importKey('jwk', jwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const derSig = new Uint8Array(await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, encoder.encode(signingInput)));
  return `${signingInput}.${b64urlEncode(derToRaw(derSig))}`;
}

async function encryptPayload(payload: string, p256dh: string, auth: string): Promise<Uint8Array> {
  const encoder = new TextEncoder();
  const p256dhBytes = b64urlDecode(p256dh);
  const authBytes = b64urlDecode(auth);
  const subscriberPubKey = await crypto.subtle.importKey('raw', p256dhBytes, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const ephemeral = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const ephemeralPub = new Uint8Array(await crypto.subtle.exportKey('raw', ephemeral.publicKey));
  const sharedSecret = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: subscriberPubKey }, ephemeral.privateKey, 256));
  const ikm = new Uint8Array(sharedSecret.length + authBytes.length);
  ikm.set(sharedSecret, 0);
  ikm.set(authBytes, sharedSecret.length);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const prk = await hkdfExtract(salt, ikm);
  const keyInfo = encoder.encode('Content-Encoding: aes128gcm\0');
  const okm = await hkdfExpand(prk, keyInfo, 28);
  const cek = okm.slice(0, 16);
  const nonce = okm.slice(16, 28);
  const cekKey = await crypto.subtle.importKey('raw', cek, { name: 'AES-GCM' }, false, ['encrypt']);
  const payloadBytes = encoder.encode(payload);
  const padded = new Uint8Array(payloadBytes.length + 1);
  padded.set(payloadBytes, 0);
  padded[payloadBytes.length] = 0x02;
  const encrypted = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv: nonce }, cekKey, padded));
  const rs = 4096;
  const rsBytes = new Uint8Array(4);
  rsBytes[0] = (rs >> 24) & 0xFF;
  rsBytes[1] = (rs >> 16) & 0xFF;
  rsBytes[2] = (rs >> 8) & 0xFF;
  rsBytes[3] = rs & 0xFF;
  const idlen = ephemeralPub.length;
  const body = new Uint8Array(16 + 4 + 1 + idlen + encrypted.length);
  body.set(salt, 0);
  body.set(rsBytes, 16);
  body[20] = idlen;
  body.set(ephemeralPub, 21);
  body.set(encrypted, 21 + idlen);
  return body;
}

export async function sendWebPush(sub: { endpoint: string; p256dh_key: string; auth_key: string }, payload: string): Promise<boolean> {
  try {
    const jwk = JSON.parse(VAPID_PRIVATE_KEY);
    const endpointUrl = new URL(sub.endpoint);
    const aud = `${endpointUrl.protocol}//${endpointUrl.host}`;
    const jwt = await createVapidJwt(aud, jwk);
    const xBytes = b64urlDecode(jwk.x);
    const yBytes = b64urlDecode(jwk.y);
    const pubKeyBytes = new Uint8Array(1 + xBytes.length + yBytes.length);
    pubKeyBytes[0] = 0x04;
    pubKeyBytes.set(xBytes, 1);
    pubKeyBytes.set(yBytes, 1 + xBytes.length);
    const vapidPublicKey = b64urlEncode(pubKeyBytes);
    const body = await encryptPayload(payload, sub.p256dh_key, sub.auth_key);
    const res = await fetch(sub.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/octet-stream',
        'Content-Encoding': 'aes128gcm',
        'TTL': '2419200',
        'Authorization': `vapid t=${jwt},k=${vapidPublicKey}`
      },
      body
    });
    return res.ok;
  } catch (e) {
    return false;
  }
}