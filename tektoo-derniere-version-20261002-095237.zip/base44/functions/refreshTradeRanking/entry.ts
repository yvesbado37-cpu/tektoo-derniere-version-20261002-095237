import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const svc = base44.asServiceRole;

    // 1. Fetch all technicians (paginate, 500 per page)
    const techMap: Record<string, string> = {};
    let offset = 0;
    let hasMore = true;
    while (hasMore) {
      const batch = await svc.entities.Technician.list('-created_date', 500, offset);
      for (const t of batch) {
        if (t.id && t.trade) techMap[t.id] = t.trade;
      }
      hasMore = batch.length === 500;
      offset += batch.length;
    }

    // 2. Fetch all profile views (paginate)
    const viewCounts: Record<string, number> = {};
    let vOffset = 0;
    let vHasMore = true;
    while (vHasMore) {
      const batch = await svc.entities.ProfileView.list('-created_date', 500, vOffset);
      for (const v of batch) {
        const trade = techMap[v.technician_id];
        if (trade) viewCounts[trade] = (viewCounts[trade] || 0) + 1;
      }
      vHasMore = batch.length === 500;
      vOffset += batch.length;
    }

    // 3. Build ranked list (all trades, even those with 0 views)
    const allTrades = ['electricite', 'mecanique', 'froid', 'peinture', 'plomberie', 'maconnerie', 'autres'];
    const ranked = allTrades
      .map(trade => ({ trade, view_count: viewCounts[trade] || 0 }))
      .sort((a, b) => b.view_count - a.view_count || a.trade.localeCompare(b.trade));

    // 4. Replace TradeRanking records
    await svc.entities.TradeRanking.deleteMany({});
    const records = ranked.map((r, i) => ({
      trade: r.trade,
      view_count: r.view_count,
      rank: i + 1
    }));
    if (records.length > 0) {
      await svc.entities.TradeRanking.bulkCreate(records);
    }

    return Response.json({ ok: true, ranking: ranked });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}