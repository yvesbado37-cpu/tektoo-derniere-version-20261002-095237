import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';

export default async function (req: Request): Promise<Response> {
  // GET: Meta webhook verification
  if (req.method === 'GET') {
    const url = new URL(req.url);
    const mode = url.searchParams.get('hub.mode');
    const token = url.searchParams.get('hub.verify_token');
    const challenge = url.searchParams.get('hub.challenge');
    const verifyToken = secrets.get('WHATSAPP_WEBHOOK_VERIFY_TOKEN');
    if (mode === 'subscribe' && token && verifyToken && token === verifyToken) {
      return new Response(challenge || '', { status: 200, headers: { 'Content-Type': 'text/plain' } });
    }
    return new Response('Forbidden', { status: 403 });
  }

  // POST: Incoming WhatsApp messages
  if (req.method === 'POST') {
    try {
      const base44 = createClientFromRequest(req);
      const body = await req.json();

      const entries = body?.entry || [];
      for (const entry of entries) {
        const changes = entry?.changes || [];
        for (const change of changes) {
          const messages = change?.value?.messages;
          if (!messages) continue;
          for (const msg of messages) {
            const from = msg.from;
            const text = msg.text?.body || '';
            if (!from || !text) continue;

            // Extract 6-digit code from message
            const codeMatch = text.match(/\b(\d{6})\b/);
            if (!codeMatch) continue;
            const code = codeMatch[1];

            // WhatsApp sends phone without "+", our DB stores with "+"
            const normalizedPhone = '+' + from;
            const accounts = await base44.asServiceRole.entities.TechnicianAccount.filter({ phone: normalizedPhone });
            const account = accounts[0];
            if (!account) continue;

            let verified = false;
            if (account.verification_code && account.verification_code === code) verified = true;
            if (account.reset_code && account.reset_code === code) verified = true;

            if (verified) {
              await base44.asServiceRole.entities.TechnicianAccount.update(account.id, { code_verified: true });
            }
          }
        }
      }

      return Response.json({ ok: true });
    } catch (error) {
      return Response.json({ error: (error as Error).message }, { status: 500 });
    }
  }

  return new Response('Method not allowed', { status: 405 });
}