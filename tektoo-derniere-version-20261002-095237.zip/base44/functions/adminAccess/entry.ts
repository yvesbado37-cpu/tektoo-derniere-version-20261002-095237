import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { hashPassword, verifyPassword } from '../../shared/passwordHash.ts';
import { verifyYvesAdmin } from '../../shared/verifyYvesAdmin.ts';

export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const action = body.action;
    const { accountId, sessionToken } = body;

    const account = await verifyYvesAdmin(base44, accountId, sessionToken);
    if (!account) return Response.json({ error: 'Accès admin non autorisé.' }, { status: 401 });

    if (action === 'hasAccess') {
      return Response.json({ hasAdminPassword: !!account.admin_password });
    }

    if (action === 'verify') {
      const adminPassword = String(body.adminPassword || '');
      if (!adminPassword) return Response.json({ error: 'Mot de passe admin requis.' }, { status: 400 });
      if (!account.admin_password) return Response.json({ error: 'Aucun accès admin configuré pour ce compte.' }, { status: 403 });
      const ok = await verifyPassword(adminPassword, account.admin_password);
      if (!ok) return Response.json({ error: 'Mot de passe admin incorrect.' }, { status: 401 });
      return Response.json({ verified: true });
    }

    if (action === 'setPassword') {
      const adminPassword = String(body.adminPassword || '');
      if (adminPassword.length < 6) {
        return Response.json({ error: 'Mot de passe admin de 6 caractères minimum.' }, { status: 400 });
      }
      if (!account.admin_password) {
        const hash = await hashPassword(adminPassword);
        await base44.asServiceRole.entities.TechnicianAccount.update(account.id, { admin_password: hash });
        return Response.json({ ok: true, created: true });
      }
      const currentAdminPassword = String(body.currentAdminPassword || '');
      const ok = await verifyPassword(currentAdminPassword, account.admin_password);
      if (!ok) return Response.json({ error: 'Mot de passe admin actuel incorrect.' }, { status: 401 });
      const hash = await hashPassword(adminPassword);
      await base44.asServiceRole.entities.TechnicianAccount.update(account.id, { admin_password: hash });
      return Response.json({ ok: true });
    }

    // Lien magique d'accès admin livré via WhatsApp (wa.me, sans clé API).
    if (action === 'generateMagicLink') {
      const token = crypto.randomUUID();
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      const expires = new Date(Date.now() + 10 * 60 * 1000).toISOString();
      await base44.asServiceRole.entities.TechnicianAccount.update(account.id, {
        admin_magic_token: token, admin_magic_code: code, admin_magic_expires: expires
      });
      return Response.json({ token, code });
    }

    if (action === 'verifyMagic') {
      const token = String(body.token || '');
      const code = String(body.code || '');
      if (!token) return Response.json({ error: 'Lien invalide.' }, { status: 400 });
      if (!account.admin_magic_token || account.admin_magic_token !== token) {
        return Response.json({ error: 'Lien invalide ou expiré.' }, { status: 401 });
      }
      if (code && account.admin_magic_code && account.admin_magic_code !== code) {
        return Response.json({ error: 'Code de vérification incorrect.' }, { status: 401 });
      }
      if (!account.admin_magic_expires || new Date(account.admin_magic_expires).getTime() < Date.now()) {
        return Response.json({ error: 'Lien expiré. Rechargez la page pour en générer un nouveau.' }, { status: 401 });
      }
      await base44.asServiceRole.entities.TechnicianAccount.update(account.id, { admin_magic_token: '', admin_magic_code: '' });
      return Response.json({ verified: true });
    }

    return Response.json({ error: 'Action inconnue.' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: (error as Error).message }, { status: 500 });
  }
}