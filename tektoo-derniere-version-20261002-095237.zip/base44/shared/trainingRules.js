export const MAX_TRAINING_PARTICIPANTS = 100;

export function isTrainerActive(technician, now = Date.now()) {
  return Boolean(technician?.is_trainer
    && Date.parse(technician.trainer_activated_at) <= now
    && Date.parse(technician.trainer_expires_at) > now);
}

export function addCalendarMonth(isoDate) {
  const date = new Date(isoDate);
  if (!Number.isFinite(date.getTime())) throw new Error('Date invalide.');
  const day = date.getUTCDate();
  date.setUTCDate(1);
  date.setUTCMonth(date.getUTCMonth() + 1);
  const lastDay = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + 1, 0)).getUTCDate();
  date.setUTCDate(Math.min(day, lastDay));
  return date.toISOString();
}

export function trainingStatus(training, now = Date.now()) {
  if (training?.cancelled) return 'cancelled';
  if (Date.parse(training?.ends_at) <= now) return 'ended';
  if (Date.parse(training?.starts_at) > now) return 'scheduled';
  if (Date.parse(training?.starts_at) <= now && Date.parse(training?.ends_at) > now) return 'live';
  return 'invalid';
}

export function validateTraining(input, technician, now = Date.now()) {
  const title = String(input.title ?? '').trim();
  const duration = Number(input.durationHours);
  const count = Number(input.participantCount);
  const start = Date.parse(input.startsAt);
  if (!title || title.length > 160) throw new Error('Titre requis (160 caractères maximum).');
  if (!Number.isFinite(start) || start <= now) throw new Error('Choisissez une date et une heure de début futures.');
  if (!Number.isFinite(duration) || duration <= 0) throw new Error('La durée en heures doit être positive.');
  if (!Number.isInteger(count) || count < 1 || count > MAX_TRAINING_PARTICIPANTS) {
    throw new Error(`Choisissez entre 1 et ${MAX_TRAINING_PARTICIPANTS} participants.`);
  }
  const end = start + duration * 3600000;
  if (!Number.isFinite(end) || end > Date.parse(technician.trainer_expires_at)) {
    throw new Error('La formation doit se terminer avant l’expiration de votre accès Formateur. Demandez un renouvellement à Admin Pro.');
  }
  return {
    title,
    starts_at: new Date(start).toISOString(),
    ends_at: new Date(end).toISOString(),
    duration_hours: duration,
    participant_count: count
  };
}
