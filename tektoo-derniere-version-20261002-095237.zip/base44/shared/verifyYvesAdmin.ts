// Identifie le compte technicien de l'administrateur unique (Yves Bado).
// L'accès admin Pro est réservé à ce compte, vérifié via sa session technicien.
export const YVES_TECHNICIAN_ID = '6aaa799537cfecc045c07485';
export const ADMIN_PHONE = '22672330796';

// Vérifie la session technicien fournie et renvoie le compte si elle appartient à Yves.
export async function verifyYvesAdmin(base44: any, accountId: string, sessionToken: string) {
  if (!accountId || !sessionToken) return null;
  let account;
  try {
    account = await base44.asServiceRole.entities.TechnicianAccount.get(accountId);
  } catch {
    return null;
  }
  if (!account || account.session_token !== sessionToken) return null;
  if (account.technician_id !== YVES_TECHNICIAN_ID) return null;
  return account;
}