# Base44 Project

Use this repository to run and edit the app locally, then publish changes back through Base44.

Any change pushed to the repo will also be reflected in the Base44 Builder.

## Prerequisites

1. Clone the repository using the project's Git URL.
2. Navigate to the project directory.
3. Install dependencies: `npm install`.
4. Install the Base44 CLI: `npm install -g base44@latest`.
5. Install [Deno](https://docs.deno.com/runtime/getting_started/installation/) — the local Base44 backend runs on it.

Run `base44 --help` (or see the [CLI reference](https://docs.base44.com/developers/references/cli/commands/introduction)) for the full command surface.

## Run Locally

Three commands, from the project root:

```bash
base44 login   # one-time per machine
base44 link    # one-time per clone
base44 dev     # local backend + frontend together
```

Open the frontend URL that `base44 dev` prints (typically `http://localhost:5173`).

Notes:

- **Every fresh clone needs `base44 link`.** It writes `base44/.app.jsonc` (the app-id pointer), which is deliberately gitignored. Your app id is in the Builder URL (`app.base44.com/apps/<id>/...`); `base44 link --help` shows the non-interactive flags.
- **`base44 dev` runs the frontend for you** (via `site.serveCommand` in this repo's `base44/config.jsonc`) — never run `npm run dev` yourself: alone it serves a UI with no backend behind it (`[base44] Proxy not enabled`, every `/api` call fails), and alongside `base44 dev` the second Vite silently takes the next port and you end up looking at the wrong one.
- **The app must be published at least once for the UI to load under `base44 dev`.** The frontend boots by fetching app settings from the hosted app; before the first publish that fails and every page redirects to login. The local API works regardless.
- Entities, functions, and auth run locally — entity data is **in-memory only**, wiped when `base44 dev` restarts. Everything else (Core integrations, OAuth login) is forwarded to your deployed app. Full breakdown: [Local development overview](https://docs.base44.com/developers/backend/overview/local-dev/local-development-overview).

## Frontend Only, Hosted Backend

To work on just the frontend against your app's live hosted backend:

```bash
base44 dev --remote
```

⚠️ In this mode writes go to your app's **production data** — plain `base44 dev` keeps everything local.

## Publish Your Changes

After pushing your changes to git, open the Base44 dashboard and publish the app:

```bash
base44 dashboard open
```

This repo syncs to Base44 through git, so publish from the dashboard rather than `base44 deploy` — a CLI deploy ships your local tree directly, bypassing the sync, and the deployed state silently diverges from the repo.

## Formateurs et formations

- Admin Pro attribue et révoque séparément les droits Pro et Formateur. Le droit Formateur dure un mois calendaire ; un renouvellement ajoute un mois à l’échéance encore active, sinon repart de la date actuelle.
- Les profils Formateur actifs portent un thème et un badge verts. Leur espace est accessible depuis Mon compte et `/espace-formateur`.
- `/formation` liste publiquement les formations à venir ou en cours des formateurs actifs. Les visiteurs peuvent rejoindre sans compte tektoo avec les identifiants de leur formation.
- Le formateur définit un titre, une date/heure locale, une durée continue en heures et de 1 à 100 participants. La fin doit précéder l’expiration de son accès Formateur.
- Avant le début, le bouton de génération fournit exactement une paire identifiant/mot de passe par place et télécharge le PDF. Les mots de passe ne sont stockés que sous forme d’empreintes : après avoir quitté la page, un nouveau PDF nécessite de remplacer les accès, ce qui invalide les précédents. Pendant la session, une reconnexion avec la même place remplace sa connexion précédente.
- Les accès participants et les échanges sont contrôlés côté serveur entre l’heure de début (incluse) et la fin (exclue). Une annulation ou révocation Formateur ferme également l’accès. Le formateur peut consulter son historique tant que son droit Formateur est actif.
- Les participants publient du texte uniquement. Le formateur peut suspendre/reprendre leurs messages avec le switch, sélectionner une question et publier des réponses liées à cette question.
- Les fichiers du formateur sont privés (PDF, texte, JPEG/PNG/WebP/GIF, MP4/WebM ; 25 Mo maximum). Des liens signés permettent leur lecture pendant la session, pour au plus cinq minutes et jamais après la fin prévue. Un fichier déjà téléchargé ne peut pas être retiré de l’appareil du participant.
- La discussion se synchronise par requêtes serveur toutes les trois secondes, sans chevauchement des rafraîchissements automatiques. Ce n’est pas une intégration WhatsApp. La liste publique se rafraîchit toutes les quinze secondes.

**Publication nécessaire :** publier les trois nouvelles entités `TrainingSession`, `TrainingAccess`, `TrainingMessage`, la fonction `training`, les modifications de `adminPro` / `technicianAccount` et le schéma `Technician` avec le frontend via le workflow Git / Builder décrit plus haut. Les entités Formation sont fermées à l’API directe ; tous les accès passent par la fonction serveur. Les modifications directes de `Technician` sont également interdites : inscription et édition utilisent déjà `technicianAccount`, les promotions passent uniquement par `adminPro`.

Tests ciblés : `npm test -- src/lib/training.test.js`. Ils couvrent le calendrier mensuel, les limites temporelles, la capacité, les autorisations, la génération exacte des accès, leur remplacement, l’expiration, les fichiers privés et le switch.

La visibilité de l’app Base44 doit être publique pour que les visiteurs sans compte puissent atteindre Formation. Ces visiteurs n’ont accès à aucune discussion sans identifiants de session.

## Docs & Support

GitHub integration: [https://docs.base44.com/developers/app-code/local-development/github](https://docs.base44.com/developers/app-code/local-development/github)

Local development: [https://docs.base44.com/developers/backend/overview/local-dev/local-development-overview](https://docs.base44.com/developers/backend/overview/local-dev/local-development-overview)

Support: [https://app.base44.com/support](https://app.base44.com/support)
