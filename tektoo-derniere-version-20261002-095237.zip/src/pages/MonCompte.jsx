import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Loader2, Save, Trash2, Upload, X, Eye, Star, ShieldCheck, ArrowUpRight, GraduationCap } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getSession, clearSession } from '@/lib/technicianSession';
import { useAuth } from '@/lib/AuthContext';
import { trades, quartiers, quartiersBobo } from '@/components/directory/catalog';
import VideoInput from '@/components/directory/VideoInput';
import PdfInput from '@/components/directory/PdfInput';
import ProMediaSection from '@/components/directory/ProMediaSection';
import { isProActive, proDaysLeft, formatDate } from '@/lib/proStatus';
import { companionApps } from '@/lib/companionApps';
import { CompanionAppLauncher } from '@/components/companion/CompanionAppWorkspace';
import { isTrainerActive, trainingDateLabel } from '@/lib/training';

function PhotoInput({ label, value, onChange }) {
  const [busy, setBusy] = useState(false);
  const handle = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      onChange(file_url);
    } finally { setBusy(false); }
  };
  return (
    <label>
      {label}
      <div className="relative flex h-28 items-center justify-center overflow-hidden rounded-xl border border-dashed border-[#D3CCBE] bg-white shadow-sm">
        {value ? (
          <>
            <img src={value} alt={label} className="absolute inset-0 h-full w-full object-cover"/>
            <button type="button" onClick={(e) => { e.preventDefault(); onChange(''); }} className="absolute right-2 top-2 bg-[#F3EFE7]/90 p-1"><X size={14}/></button>
          </>
        ) : (
          <span className="flex flex-col items-center gap-1 text-xs text-slate-500">
            {busy ? <Loader2 size={18} className="animate-spin"/> : <Upload size={18}/>}
            {busy ? 'Chargement…' : 'Téléverser'}
          </span>
        )}
        <input type="file" accept="image/*" onChange={handle} className="absolute inset-0 cursor-pointer opacity-0" disabled={busy}/>
      </div>
    </label>
  );
}

export default function MonCompte() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const session = getSession();
  const YVES_TECHNICIAN_ID = '6aaa799537cfecc045c07485';
  const isYvesAdmin = session?.technicianId === YVES_TECHNICIAN_ID || user?.id === '6aa99896f8c49e0cebb09438' || user?.email === 'yvesbado37@gmail.com';
  const [t, setT] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [views, setViews] = useState(0);

  useEffect(() => {
    if (!session) { setLoading(false); return; }
    base44.entities.Technician.get(session.technicianId)
      .then(setT)
      .catch(() => {})
      .finally(() => setLoading(false));
    base44.entities.ProfileView.filter({ technician_id: session.technicianId })
      .then(list => {
        const start = new Date(); start.setHours(0, 0, 0, 0);
        setViews(list.filter(v => new Date(v.created_date) >= start).length);
      })
      .catch(() => {});
  }, []);

  if (loading) {
    return <div className="flex h-full items-center justify-center text-sm text-slate-500"><Loader2 size={22} className="animate-spin"/></div>;
  }
  if (!session) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 px-5 text-center text-slate-500">
        <h3 className="text-base font-semibold text-slate-900">Vous n'êtes pas connecté.</h3>
        <button className="text-[#3A8E9C] underline" onClick={() => navigate('/connexion')}>Se connecter à mon compte</button>
      </div>
    );
  }

  const field = (key) => ({ value: t[key] ?? '', onChange: (e) => { setT({ ...t, [key]: e.target.value }); setSaved(false); } });

  const save = async (e) => {
    e.preventDefault();
    setBusy(true); setError(''); setSaved(false);
    try {
      const res = await base44.functions.invoke('technicianAccount', {
        action: 'update',
        accountId: session.accountId,
        sessionToken: session.sessionToken,
        updates: {
          name: t.name, nom: t.nom, prenoms: t.prenoms, trade: t.trade,
          custom_trade: t.trade === 'autres' ? t.custom_trade : '',
          city: t.city, quartier: t.quartier, age: t.age ? Number(t.age) : undefined,
          whatsapp: t.whatsapp, description: t.description,
          experience: Number(t.experience), available: t.available,
          profile_photo: t.profile_photo, illustration_1: t.illustration_1, illustration_2: t.illustration_2, illustration_3: t.illustration_3, illustration_4: t.illustration_4,
          presentation_video: t.presentation_video, cv_url: t.cv_url,
          pro_album_1: t.pro_album_1 || [], pro_album_2: t.pro_album_2 || [], pro_videos: t.pro_videos || []
        }
      });
      setT(res.data.technician);
      setSaved(true);
    } catch (err) {
      const status = err?.response?.status || err?.status || 0;
      const msg = err?.response?.data?.error || err?.data?.error || err?.message || '';
      if (status === 401 && /session invalide/i.test(msg)) {
        clearSession();
        navigate('/connexion');
        return;
      }
      setError(msg || 'Échec de la mise à jour. Vérifiez votre connexion et réessayez.');
    } finally { setBusy(false); }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await base44.functions.invoke('technicianAccount', {
        action: 'delete',
        accountId: session.accountId,
        sessionToken: session.sessionToken
      });
      clearSession();
      navigate('/');
    } catch (err) {
      setError(err?.response?.data?.error || 'Suppression impossible.');
      setBusy(false);
    }
  };

  return (
    <div className="scroll-pane flex h-full flex-col overflow-y-auto px-5 py-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="eyebrow text-[#3A8E9C]">MON COMPTE</div>
          <h1 className="mt-2 text-2xl font-semibold tracking-tight text-slate-900">{t?.name}</h1>
          {t?.is_trainer && (
            <div className="mt-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">
              <span className="inline-flex items-center gap-2 font-semibold"><GraduationCap size={16} />{isTrainerActive(t) ? 'Compte Formateur' : 'Accès Formateur expiré'}</span>
              <p className="mt-1 text-xs">Échéance : {trainingDateLabel(t.trainer_expires_at)} · Renouvellement par Admin Pro uniquement.</p>
              {isTrainerActive(t) && <Link to="/espace-formateur" className="mt-2 inline-block rounded-full bg-emerald-700 px-4 py-2 text-xs font-semibold text-white">Ouvrir mon espace Formateur</Link>}
            </div>
          )}
          {isProActive(t) && <span className="mt-1 inline-flex items-center gap-1.5 rounded-full bg-[#3A8E9C] px-3 py-1 text-xs font-semibold text-white"><Star size={13} />Compte Pro</span>}
          {t?.is_pro && !isProActive(t) && <span className="mt-1 inline-flex items-center gap-1.5 rounded-full bg-amber-500/15 px-3 py-1 text-xs font-semibold text-amber-600"><Star size={13} />Pro expiré</span>}
          {isProActive(t) && (
            <div className="mt-3 flex flex-wrap gap-2">
              {companionApps.map((app) => (
                <CompanionAppLauncher
                  key={`top-${app.slug}`}
                  app={app}
                  technician={t}
                  renderTrigger={({ open }) => (
                    <button type="button" onClick={open} className="inline-flex items-center gap-2 rounded-full border border-[#3A8E9C]/20 bg-white px-3 py-2 text-xs font-semibold text-[#3A8E9C] shadow-sm transition hover:border-[#3A8E9C] hover:bg-[#F3EFE7]">
                      <app.icon size={14} strokeWidth={2} />
                      {app.name}
                    </button>
                  )}
                />
              ))}
            </div>
          )}
        </div>
        {isYvesAdmin && (
          <Link to="/admin-unlock" className="flex items-center gap-1.5 rounded-full border border-[#3A8E9C]/30 bg-[#3A8E9C]/5 px-3 py-2 text-xs font-semibold text-[#3A8E9C] transition-colors hover:bg-[#3A8E9C]/10">
            <ShieldCheck size={14} strokeWidth={2.2} /> Admin Pro
          </Link>
        )}
      </div>

      {t?.is_pro && (
        <div className={`mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 rounded-2xl border px-4 py-3 text-xs ${isProActive(t) ? 'border-[#3A8E9C]/30 bg-[#3A8E9C]/5' : 'border-amber-500/30 bg-amber-500/10'}`}>
          <span className="font-semibold text-slate-700">Formule : {t.pro_plan === 'annual' ? 'Annuelle' : 'Mensuelle'}</span>
          <span className="text-slate-500">Activé le {formatDate(t.pro_activated_at)}</span>
          <span className={isProActive(t) ? 'text-slate-700' : 'text-amber-600 font-semibold'}>Échéance : {formatDate(t.pro_expires_at)}</span>
          {isProActive(t) && proDaysLeft(t) != null && <span className="text-[#3A8E9C] font-semibold">{proDaysLeft(t)} j restants</span>}
          {!isProActive(t) && <span className="text-amber-600 font-semibold">Avantages Pro suspendus — remise à niveau requise.</span>}
        </div>
      )}

      <div className="glass mt-4 flex items-center gap-3 rounded-2xl px-4 py-3">
        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#3A8E9C]/10 text-[#3A8E9C]"><Eye size={18}/></span>
        <div>
          <div className="text-2xl font-semibold leading-none text-slate-900">{views}</div>
          <div className="text-xs text-slate-500">votre profil a été consulté par {views} {views > 1 ? 'personnes' : 'personne'} aujourd'hui.</div>
        </div>
      </div>

      <form onSubmit={save} className="mt-6 grid gap-4">
        <div className="form-grid">
          <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Domaine
            <select {...field('trade')} className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm">{trades.map((tr) => <option key={tr.id} value={tr.id}>{tr.label}</option>)}</select>
          </label>
          <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Ville
            <select {...field('city')} className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"><option value="Ouagadougou">Ouagadougou</option><option value="Bobo-Dioulasso">Bobo-Dioulasso</option><option value="Autre">Autre ville</option></select>
          </label>
        </div>
        {t.trade === 'autres' && (
          <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Précisez le domaine
            <input {...field('custom_trade')} className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
          </label>
        )}
        <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Quartier
          {t.city === 'Ouagadougou' ? (
            <select {...field('quartier')} className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"><option value="">Sélectionnez…</option>{quartiers.map((q) => <option key={q}>{q}</option>)}</select>
          ) : t.city === 'Bobo-Dioulasso' ? (
            <select {...field('quartier')} className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"><option value="">Sélectionnez…</option>{quartiersBobo.map((q) => <option key={q}>{q}</option>)}</select>
          ) : (
            <input {...field('quartier')} className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
          )}
        </label>
        <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Numéro WhatsApp
          <input type="tel" {...field('whatsapp')} className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
        </label>
        <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Présentation
          <textarea rows={3} {...field('description')} className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
        </label>
        <div className="form-grid">
          <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Années d'expérience
            <input type="number" min="0" max="70" {...field('experience')} className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
          </label>
          <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Âge
            <input type="number" min="18" max="100" {...field('age')} className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
          </label>
        </div>
        <div className="form-grid">
          <PhotoInput label="Photo de profil" value={t.profile_photo || ''} onChange={(v) => { setT({ ...t, profile_photo: v }); setSaved(false); }}/>
          <PhotoInput label="Illustration 1" value={t.illustration_1 || ''} onChange={(v) => { setT({ ...t, illustration_1: v }); setSaved(false); }}/>
        </div>
        <div className="form-grid">
          <PhotoInput label="Illustration 2" value={t.illustration_2 || ''} onChange={(v) => { setT({ ...t, illustration_2: v }); setSaved(false); }}/>
          <PhotoInput label="Illustration 3" value={t.illustration_3 || ''} onChange={(v) => { setT({ ...t, illustration_3: v }); setSaved(false); }}/>
        </div>
        <PhotoInput label="Illustration 4" value={t.illustration_4 || ''} onChange={(v) => { setT({ ...t, illustration_4: v }); setSaved(false); }}/>
        <VideoInput label="Vidéo de présentation (30s max)" value={t.presentation_video || ''} onChange={(v) => { setT({ ...t, presentation_video: v }); setSaved(false); }}/>
        <PdfInput label="CV (PDF, facultatif)" value={t.cv_url || ''} onChange={(v) => { setT({ ...t, cv_url: v }); setSaved(false); }}/>
        {isProActive(t) && <ProMediaSection t={t} onChange={(patch) => { setT(prev => ({ ...prev, ...patch })); setSaved(false); }}/>}
        <label className="join-form checkbox-label text-slate-700">
          <input type="checkbox" checked={!!t.available} onChange={(e) => { setT({ ...t, available: e.target.checked }); setSaved(false); }}/>
          Disponible pour de nouvelles demandes
        </label>
        {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
        {saved && <p className="text-sm text-emerald-600">Profil mis à jour.</p>}
        <button type="submit" disabled={busy} className="flex items-center justify-center gap-2 rounded-full bg-[#3A8E9C] px-5 py-3 text-sm font-semibold text-white disabled:opacity-50 hover:bg-[#2E7B88] transition-colors">
          {busy ? <><Loader2 size={17} className="animate-spin"/>Enregistrement…</> : <><Save size={17}/>Enregistrer les modifications</>}
        </button>
      </form>

      {isProActive(t) && (
        <div className="mt-8">
          <div className="mb-3 flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-700">Solutions Pro</span>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {companionApps.map((app) => (
              <CompanionAppLauncher
                key={app.slug}
                app={app}
                technician={t}
                renderTrigger={({ open }) => (
                  <button
                    type="button"
                    onClick={open}
                    className="glass glass-hover block rounded-2xl p-4 text-left"
                  >
                    <div className="flex items-start gap-3">
                      <div className="tech-card-icon">
                        <app.icon size={20} strokeWidth={1.8} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <div className="text-sm font-bold text-slate-900">{app.name}</div>
                          <ArrowUpRight size={15} className="shrink-0 text-[#3A8E9C]" />
                        </div>
                        <div className="mt-1 text-xs font-semibold text-[#3A8E9C]">{app.tagline}</div>
                        <p className="mt-2 text-xs leading-relaxed text-slate-600">{app.description}</p>
                        <div className="mt-3 flex flex-wrap gap-2">
                          {app.bullets.map((bullet) => (
                            <span key={bullet} className="rounded-full bg-white/80 px-2.5 py-1 text-[10px] font-semibold text-slate-700">
                              {bullet}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </button>
                )}
              />
            ))}
          </div>
        </div>
      )}

      <div className="mt-8 border-t border-[#D3CCBE] pt-6">
        {!confirmDelete ? (
          <button onClick={() => setConfirmDelete(true)} className="flex items-center gap-2 text-sm font-semibold text-red-600"><Trash2 size={16}/>Supprimer mon compte</button>
        ) : (
          <div className="grid gap-3 border border-red-500/30 bg-red-500/10 p-4 rounded-2xl">
            <p className="text-sm text-red-600">Votre profil et votre compte seront définitivement supprimés. Cette action est irréversible.</p>
            <div className="flex gap-2">
              <button onClick={remove} disabled={busy} className="flex items-center justify-center gap-2 rounded-full bg-red-500 px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-50">
                {busy ? <Loader2 size={16} className="animate-spin"/> : <Trash2 size={16}/>}Confirmer la suppression
              </button>
              <button onClick={() => setConfirmDelete(false)} className="rounded-full border border-[#D3CCBE] px-4 py-2.5 text-sm font-semibold text-slate-700">Annuler</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}