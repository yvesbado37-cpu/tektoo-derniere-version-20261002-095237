import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Loader2, KeyRound, ArrowUpRight, CheckCircle2, AlertCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function Recuperation() {
  const { token } = useParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState('checking');
  const [newPassword, setNewPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const res = await base44.functions.invoke('technicianAccount', { action: 'validateRecoveryToken', token });
        setStatus(res.data.valid ? 'valid' : 'invalid');
      } catch {
        setStatus('invalid');
      }
    })();
  }, [token]);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (newPassword !== confirm) { setError('Les mots de passe ne correspondent pas.'); return; }
    if (newPassword.length < 6) { setError('6 caractères minimum.'); return; }
    setBusy(true);
    try {
      await base44.functions.invoke('technicianAccount', { action: 'resetPasswordWithToken', token, newPassword });
      setStatus('done');
    } catch (err) {
      setError(err?.response?.data?.error || 'Réinitialisation impossible.');
    } finally { setBusy(false); }
  };

  if (status === 'checking') {
    return (
      <div className="scroll-pane flex h-full flex-col items-center justify-center gap-4 px-5 py-8">
        <Loader2 size={32} className="animate-spin text-[#3A8E9C]"/>
        <p className="text-sm text-slate-500">Vérification du lien…</p>
      </div>
    );
  }

  if (status === 'invalid') {
    return (
      <div className="scroll-pane flex h-full flex-col items-center justify-center gap-4 px-5 py-8 text-center">
        <AlertCircle size={44} className="text-red-600"/>
        <h1 className="text-xl font-semibold text-slate-900">Lien invalide ou expiré</h1>
        <p className="max-w-xs text-sm text-slate-500">Ce lien de récupération n'est plus valide. Demandez un nouveau lien.</p>
        <Link to="/mot-de-passe-oublie" className="primary-button">Demander un nouveau lien <ArrowUpRight size={16}/></Link>
      </div>
    );
  }

  if (status === 'done') {
    return (
      <div className="scroll-pane flex h-full flex-col items-center justify-center gap-4 px-5 py-8 text-center">
        <CheckCircle2 size={44} className="text-emerald-600"/>
        <h1 className="text-xl font-semibold text-slate-900">Mot de passe réinitialisé</h1>
        <p className="max-w-xs text-sm text-slate-500">Vous pouvez vous connecter avec votre nouveau mot de passe.</p>
        <button className="primary-button" onClick={() => navigate('/connexion')}>Aller à la connexion <ArrowUpRight size={16}/></button>
      </div>
    );
  }

  return (
    <div className="scroll-pane flex h-full flex-col overflow-y-auto px-5 py-6">
      <div className="eyebrow text-[#3A8E9C]">RÉCUPÉRATION</div>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-900">Nouveau mot de passe</h1>
      <p className="mt-2 text-sm text-slate-500">Définissez votre nouveau mot de passe pour votre compte tektoo.</p>

      <form onSubmit={submit} className="mt-6 grid gap-4">
        <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Nouveau mot de passe
          <input required type="password" minLength={6} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="6 caractères minimum" className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
        </label>
        <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Confirmer le mot de passe
          <input required type="password" minLength={6} value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="Saisissez à nouveau" className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
        </label>
        {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
        <button type="submit" disabled={busy} className="primary-button">
          {busy ? <><Loader2 size={17} className="animate-spin"/>Réinitialisation…</> : <><KeyRound size={17}/>Réinitialiser mon mot de passe</>}
        </button>
      </form>
    </div>
  );
}