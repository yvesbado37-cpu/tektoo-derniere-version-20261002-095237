import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Loader2, LogIn, ArrowUpRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { setSession } from '@/lib/technicianSession';

export default function Connexion() {
  const navigate = useNavigate();
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      const res = await base44.functions.invoke('technicianAccount', {
        action: 'login',
        phone,
        password
      });
      setSession({
        technicianId: res.data.technician.id,
        accountId: res.data.accountId,
        sessionToken: res.data.sessionToken
      });
      navigate('/explorer');
    } catch (err) {
      setError(err?.response?.data?.error || 'Connexion impossible. Vérifiez vos identifiants.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="scroll-pane flex h-full flex-col overflow-y-auto px-5 py-6">
      <div className="eyebrow text-[#3A8E9C]">ESPACE PROFESSIONNEL</div>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-900">Connexion</h1>
      <p className="mt-2 text-sm text-slate-500">Accédez à votre profil pour le modifier ou le supprimer.</p>
      <form onSubmit={submit} className="mt-6 grid gap-4">
        <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Numéro de téléphone
          <input required type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+226 XX XX XX XX" className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
        </label>
        <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Mot de passe
          <input required type="password" minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Votre mot de passe" className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
        </label>
        {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
        <button type="submit" disabled={busy} className="flex items-center justify-center gap-2 rounded-full bg-[#3A8E9C] px-5 py-3 text-sm font-semibold text-white disabled:opacity-50 hover:bg-[#2E7B88] transition-colors">
          {busy ? <><Loader2 size={17} className="animate-spin"/>Connexion…</> : <><LogIn size={17}/>Se connecter</>}
        </button>
      </form>
      <p className="mt-6 text-sm text-slate-500">Pas encore inscrit ? <Link to="/inscription" className="text-[#3A8E9C] underline">Créer mon profil <ArrowUpRight size={14} className="inline"/></Link></p>
      <p className="mt-2 text-sm text-slate-500"><Link to="/mot-de-passe-oublie" className="text-[#3A8E9C] underline">Mot de passe oublié ?</Link></p>
    </div>
  );
}