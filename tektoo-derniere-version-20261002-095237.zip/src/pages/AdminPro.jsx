import React, { useEffect, useState } from 'react';
import { Loader2, Search, Star, ShieldCheck, Calendar, X, GraduationCap } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { tradeLabel } from '@/components/directory/catalog';
import { isProActive, proDaysLeft, formatDate } from '@/lib/proStatus';
import { getSession } from '@/lib/technicianSession';
import { isTrainerActive } from '@/lib/training';

const PLAN_LABEL = { monthly: 'Mensuel', annual: 'Annuel' };

export default function AdminPro() {
  const session = getSession();
  const [techs, setTechs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState('');
  // form par technicien : { plan, activationDate }
  const [forms, setForms] = useState({});

  const load = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('adminPro', { action: 'list', accountId: session.accountId, sessionToken: session.sessionToken });
      setTechs(res.data.technicians);
    } catch (e) {
      setError(e?.response?.data?.error || 'Chargement impossible.');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const formOf = (t) => forms[t.id] || { plan: 'monthly', activationDate: new Date().toISOString().slice(0, 10) };
  const setForm = (id, patch) => setForms(prev => ({ ...prev, [id]: { ...formOf({ id }), ...patch } }));

  const activate = async (t) => {
    const f = formOf(t);
    setBusyId(t.id);
    try {
      const res = await base44.functions.invoke('adminPro', {
        action: 'setPro', technicianId: t.id, plan: f.plan, activationDate: f.activationDate,
        accountId: session.accountId, sessionToken: session.sessionToken
      });
      setTechs(prev => prev.map(x => x.id === t.id ? res.data.technician : x));
    } catch (e) {
      setError(e?.response?.data?.error || 'Échec de la mise à niveau.');
    } finally { setBusyId(null); }
  };

  const revoke = async (t) => {
    setBusyId(t.id);
    try {
      const res = await base44.functions.invoke('adminPro', { action: 'setPro', technicianId: t.id, isPro: false, accountId: session.accountId, sessionToken: session.sessionToken });
      setTechs(prev => prev.map(x => x.id === t.id ? res.data.technician : x));
    } catch (e) {
      setError(e?.response?.data?.error || 'Échec de la révocation.');
    } finally { setBusyId(null); }
  };

  const setTrainer = async (t, enabled) => {
    if (!enabled && !window.confirm('Révoquer l’accès Formateur et fermer ses groupes aux participants ?')) return;
    setBusyId(t.id); setError('');
    try {
      const res = await base44.functions.invoke('adminPro', {
        action: 'setTrainer', technicianId: t.id, isTrainer: enabled,
        accountId: session.accountId, sessionToken: session.sessionToken
      });
      setTechs((previous) => previous.map((item) => item.id === t.id ? res.data.technician : item));
    } catch (err) {
      setError(err?.response?.data?.error || 'Échec de la mise à niveau Formateur.');
    } finally { setBusyId(null); }
  };

  const filtered = techs.filter(t => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return (t.name || '').toLowerCase().includes(q) || (t.phone || '').toLowerCase().includes(q) || (t.city || '').toLowerCase().includes(q);
  });

  return (
    <div className="scroll-pane flex h-full flex-col overflow-y-auto px-5 py-6">
      <div className="flex items-center gap-2">
        <ShieldCheck size={22} className="text-[#3A8E9C]" />
        <div>
          <div className="eyebrow text-[#3A8E9C]">ADMINISTRATION</div>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">Mise à niveau Pro et Formateur</h1>
        </div>
      </div>
      <p className="mt-2 text-sm text-slate-500">Choisissez une formule (mensuelle ou annuelle) et la date d'activation. L'échéance est calculée automatiquement ; les avantages Pro sont suspendus à l'expiration, sauf remise à niveau.</p>
      <p className="mt-2 text-sm text-emerald-700">Vous seul pouvez attribuer ou renouveler le droit Formateur, pour un mois calendaire. Un renouvellement ajoute un mois à l’échéance active. Les droits Pro restent indépendants.</p>

      <div className="mt-4 flex items-center gap-2 border border-[#D3CCBE] bg-[#F3EFE7] px-3 py-2">
        <Search size={16} className="text-[#3A8E9C]" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher par nom, téléphone, ville…" className="w-full bg-transparent text-sm outline-none placeholder:text-slate-500" />
      </div>

      {error && (
        <div className="mt-3 flex items-center justify-between gap-2 border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-600">
          <span>{error}</span>
          <button onClick={() => setError('')} aria-label="Fermer"><X size={14} /></button>
        </div>
      )}

      {loading ? (
        <div className="flex h-40 items-center justify-center text-slate-500"><Loader2 size={22} className="animate-spin" /></div>
      ) : (
        <div className="mt-4 grid gap-3">
          {filtered.map(t => {
            const active = isProActive(t);
            const days = proDaysLeft(t);
            const expired = t.is_pro && !active;
            const f = formOf(t);
            return (
              <div key={t.id} className="border border-[#D3CCBE] bg-[#F3EFE7] p-3">
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#3A8E9C]/15 text-xs font-semibold text-[#3A8E9C]">
                    {t.profile_photo ? <img src={t.profile_photo} alt="" className="h-full w-full object-cover" /> : (t.name || '?').slice(0, 1).toUpperCase()}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-semibold text-slate-900">{t.name}</div>
                    <div className="truncate text-xs text-slate-500">{tradeLabel(t)} · {t.city || '—'} · {t.phone}</div>
                  </div>
                  <span className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${active ? 'bg-[#3A8E9C] text-white' : expired ? 'bg-amber-500/15 text-amber-600' : 'bg-[#E9E3D7] text-slate-500'}`}>
                    {active ? 'Pro actif' : expired ? 'Expiré' : 'Inactif'}
                  </span>
                </div>

                {(t.is_pro || active || expired) && t.pro_activated_at && (
                  <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
                    <span>Formule : <b className="text-slate-700">{PLAN_LABEL[t.pro_plan] || '—'}</b></span>
                    <span className="flex items-center gap-1"><Calendar size={12} />Activé le {formatDate(t.pro_activated_at)}</span>
                    <span>Échéance : <b className={active ? 'text-slate-700' : 'text-amber-600'}>{formatDate(t.pro_expires_at)}</b></span>
                    {active && days != null && <span className="text-[#3A8E9C]">{days} j restants</span>}
                  </div>
                )}

                <div className="mt-3 flex flex-wrap items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 p-3">
                  <span className="flex-1 text-xs text-emerald-800">
                    <b>{isTrainerActive(t) ? 'Formateur actif' : t.is_trainer ? 'Formateur expiré' : 'Non Formateur'}</b>
                    {t.trainer_expires_at && <span className="block mt-1">Échéance : {formatDate(t.trainer_expires_at)}</span>}
                  </span>
                  <button onClick={() => setTrainer(t, true)} disabled={busyId === t.id} className="flex items-center gap-2 rounded-full bg-emerald-700 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50"><GraduationCap size={15} />{isTrainerActive(t) ? 'Renouveler Formateur (+1 mois)' : 'Activer Formateur (1 mois)'}</button>
                  {t.is_trainer && <button onClick={() => setTrainer(t, false)} disabled={busyId === t.id} className="text-xs font-semibold text-red-600 underline">Révoquer Formateur</button>}
                </div>
                <div className="mt-3 flex flex-wrap items-end gap-2 border-t border-[#D3CCBE] pt-3">
                  <label className="grid gap-1 text-xs font-semibold text-slate-600">
                    Formule
                    <select value={f.plan} onChange={e => setForm(t.id, { plan: e.target.value })} className="rounded-lg border border-[#D3CCBE] bg-white px-2 py-2 text-sm font-normal text-slate-900 outline-none focus:border-[#3A8E9C]">
                      <option value="monthly">Mensuel (30 j)</option>
                      <option value="annual">Annuel (365 j)</option>
                    </select>
                  </label>
                  <label className="grid gap-1 text-xs font-semibold text-slate-600">
                    Date d'activation
                    <input type="date" value={f.activationDate} onChange={e => setForm(t.id, { activationDate: e.target.value })} className="rounded-lg border border-[#D3CCBE] bg-white px-2 py-2 text-sm font-normal text-slate-900 outline-none focus:border-[#3A8E9C]" />
                  </label>
                  <button onClick={() => activate(t)} disabled={busyId === t.id} className="flex items-center gap-1.5 rounded-full bg-[#3A8E9C] px-4 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-[#2E7B88] disabled:opacity-50">
                    {busyId === t.id ? <Loader2 size={14} className="animate-spin" /> : <Star size={14} fill="currentColor" />}
                    {active ? 'Renouveler' : 'Mettre à niveau'}
                  </button>
                  {t.is_pro && (
                    <button onClick={() => revoke(t)} disabled={busyId === t.id} className="flex items-center gap-1.5 rounded-full border border-red-500/40 px-3 py-2.5 text-xs font-semibold text-red-600 transition-colors hover:bg-red-500/10 disabled:opacity-50">
                      <X size={14} />Révoquer
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && <p className="py-8 text-center text-sm text-slate-500">Aucun technicien.</p>}
        </div>
      )}
    </div>
  );
}