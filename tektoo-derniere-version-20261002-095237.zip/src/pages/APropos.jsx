import React from 'react';
import { ArrowUpRight, MessageCircle } from 'lucide-react';
import { companionApps, TEKTOO_WHATSAPP_NUMBER } from '@/lib/companionApps';

export default function APropos() {
  return (
    <div className="scroll-pane flex h-full flex-col overflow-y-auto px-5 py-6">
      <div className="micro mb-3 text-slate-500">À PROPOS</div>
      <h1 className="text-[2.1rem] font-semibold leading-[1.05] tracking-[-0.04em] text-slate-900">tektoo<span className="text-[#3A8E9C]">.</span></h1>
      <p className="mt-4 text-sm leading-relaxed text-slate-500">
        tektoo est un annuaire en ligne de professionnels burkinabés qui met en relation les compétences pratiques des techniciens et les problèmes techniques du quotidien.
      </p>

      <div className="mt-6 grid gap-3">
        {companionApps.map((app) => (
          <div key={app.slug} className="glass rounded-2xl p-5">
            <div className="flex items-start gap-3">
              <span className="tech-card-icon">
                <app.icon size={18} strokeWidth={1.9} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="text-base font-semibold text-slate-900">{app.name}</div>
                <p className="mt-1 text-sm leading-relaxed text-slate-500">{app.description}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {app.bullets.map((bullet) => (
                    <span key={bullet} className="rounded-full bg-white/80 px-2.5 py-1 text-[10px] font-semibold text-slate-700">
                      {bullet}
                    </span>
                  ))}
                </div>
                <p className="mt-4 text-xs font-semibold text-slate-500">Disponible pour les comptes Pro actifs dans Mon Compte.</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="glass mt-6 rounded-2xl p-5">
        <h2 className="profile-heading text-slate-900">Une suggestion ?</h2>
        <p className="text-sm leading-relaxed text-slate-500">Pour faire des suggestions, laissez un message WhatsApp à l'équipe tektoo.</p>
        <a
          className="whatsapp-button mt-4"
          target="_blank"
          rel="noreferrer"
          href={`https://wa.me/${TEKTOO_WHATSAPP_NUMBER}?text=${encodeURIComponent("Bonjour tektoo, j'ai une suggestion à vous partager.")}`}
        >
          <MessageCircle size={17}/> Écrire sur WhatsApp <ArrowUpRight size={16}/>
        </a>
      </div>
    </div>
  );
}