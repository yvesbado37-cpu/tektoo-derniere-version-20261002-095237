import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowUpRight, Search } from 'lucide-react';
import { trades } from '@/components/directory/catalog';
export default function Domaines() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  return (
    <div className="flex h-full flex-col px-5 py-5">
      <form onSubmit={e=>{e.preventDefault(); if(query.trim()) navigate(`/explorer?q=${encodeURIComponent(query.trim())}`);}} className="flex items-center gap-2 border border-[#D3CCBE] bg-[#F3EFE7] px-3 py-2">
        <Search size={15} className="text-[#3A8E9C]"/>
        <input aria-label="Rechercher un domaine précis" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Rechercher un domaine précis…" className="w-full bg-transparent text-sm text-slate-900 outline-none placeholder:text-slate-400"/>
      </form>
      <h2 className="mt-4 text-3xl font-semibold tracking-tight text-slate-900">Choisissez votre <span className="text-[#3A8E9C]">domaine.</span></h2>
      <p className="mt-2 text-sm text-slate-400">Explorez les professionnels disponibles dans chaque métier.</p>
      <div className="mt-5 grid flex-1 grid-cols-2 gap-3">
        {trades.map((t, i) => (
          <Link key={t.id} to={`/explorer?trade=${t.id}`} className="glass glass-hover flex flex-col rounded-2xl p-4">
            <div className="flex justify-between"><div className="tech-card-icon"><t.icon size={20} strokeWidth={1.5}/></div><span className="micro text-slate-400">0{i+1}</span></div>
            <div className="mt-auto pt-4"><h3 className="text-base font-semibold leading-tight text-slate-900">{t.label}</h3><p className="mt-1 text-sm text-slate-400">{t.caption}</p></div>
            <div className="mt-3 flex items-center gap-1 text-sm font-semibold text-[#3A8E9C]">Explorer <ArrowUpRight size={13}/></div>
          </Link>
        ))}
      </div>
    </div>
  );
}