import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Phone, MessageCircle, ArrowLeft, ArrowUpRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { tradeLabel } from '@/components/directory/catalog';
import Reviews from '@/components/directory/Reviews';
import ReportProfile from '@/components/directory/ReportProfile';
import ChatPanel from '@/components/directory/ChatPanel';
import ProfileCards from '@/components/directory/ProfileCards';
import { getSession } from '@/lib/technicianSession';
import { proTheme, profileBadge } from '@/lib/proTheme';

export default function TechnicianDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [agreed, setAgreed] = useState(false);

  const { data: t, isLoading: loading } = useQuery({
    queryKey: ['technician', id],
    queryFn: () => base44.entities.Technician.get(id),
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    if (!id) return;
    const session = getSession();
    if (session && session.technicianId === id) return;
    base44.entities.ProfileView.create({ technician_id: id }).catch(() => {});
  }, [id]);

  const phone = t?.phone?.replace(/[^\d+]/g, '');
  const goBack = () => navigate('/explorer');
  const pro = proTheme(t);
  const accent = pro?.primary;

  return (
    <div className={`flex h-full flex-col ${profileBadge(t) === 'Formateur' ? 'trainer-profile' : ''}`}>
      <div className="flex items-center gap-3 border-b bg-[#F3EFE7] px-3 py-2" style={{ borderColor: pro?.border || '#D3CCBE' }}>
        <button onClick={goBack} className="flex h-11 w-11 items-center justify-center text-slate-500" aria-label="Retour" style={accent ? { color: accent } : undefined}><ArrowLeft size={22} /></button>
        <span className="micro text-slate-500">PROFIL TECHNICIEN</span>
        {pro && <span className="ml-auto inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white" style={{ backgroundColor: accent }}>{profileBadge(t)}</span>}
      </div>
      <div className="scroll-pane min-h-0 flex-1 overflow-y-auto px-5 py-5">
        {loading ? (
          <div className="flex h-full items-center justify-center text-sm text-slate-500">Chargement…</div>
        ) : !t ? (
          <div className="flex h-full flex-col items-center justify-center gap-2 text-center text-slate-500">
            <h3 className="text-base font-semibold text-slate-900">Profil introuvable.</h3>
            <button className="text-[#3A8E9C] underline" onClick={() => navigate('/explorer')}>Retour à l'annuaire</button>
          </div>
        ) : (
          <>
            <div className="eyebrow text-[#3A8E9C]" style={accent ? { color: accent } : undefined}>{tradeLabel(t)} / {t.demo ? 'PROFIL DE DÉMONSTRATION' : 'PROFIL DÉCLARÉ'}</div>
            <ProfileCards t={t} />
            <Reviews technicianId={t.id} />
            <div className="contact-panel mt-5 rounded-2xl" style={pro ? { borderColor: pro.border, backgroundColor: pro.tint } : undefined}>
              <h3 className="profile-heading text-slate-900">Contacter le pro en cochant l'agrément.</h3>
              <p>Validez l'agrément ci-dessous pour afficher les coordonnées du professionnel.</p>
              {t.demo ? (
                <div className="demo-contact">Ce profil est fictif et ne peut pas être contacté.<button className="primary-button mt-4" onClick={() => navigate('/inscription')}>Inscrire mon activité <ArrowUpRight size={16} /></button></div>
              ) : (
                <>
                  <label className="flex flex-row items-start gap-2 leading-relaxed mt-4">
                    <input type="checkbox" checked={agreed} onChange={e => setAgreed(e.target.checked)} className="mt-0.5 h-4 w-4 flex-shrink-0" />
                    <span className="text-sm text-slate-500">J'accepte que tektoo est un annuaire de mise en relation et décline toute responsabilité quant aux prestations, tarifs et comportements des techniciens. L'entière responsabilité des services fournis incombe au professionnel et à moi-même.</span>
                  </label>
                  {agreed && <div className="contact-actions"><a className="whatsapp-button" target="_blank" rel="noreferrer" href={`https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(`Bonjour ${t.name}, je vous ai trouvé sur tektoo. J'aimerais vous contacter pour une intervention.`)}`}><MessageCircle size={17} />Discuter sur WhatsApp</a><a className={pro ? 'primary-button-pro' : 'primary-button'} href={`tel:${phone}`}><Phone size={17} />Appeler</a></div>}
                  {agreed && <span className="block mt-3 text-sm text-slate-700">{t.phone}</span>}
                  {agreed && getSession()?.technicianId !== t.id && (
                    <ChatPanel technicianId={t.id} technicianName={t.name} />
                  )}
                </>
              )}
            </div>
            {!t.demo && <ReportProfile technicianId={t.id} />}
            <p className="mt-4 text-sm text-slate-500">Informations déclarées, non vérifiées par tektoo. Disponibilité à confirmer directement auprès du professionnel.</p>
          </>
        )}
      </div>
    </div>
  );
}