import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MessageSquare, Plus, Loader2, X, ArrowUpRight, Lock } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getSession } from '@/lib/technicianSession';

function timeAgo(date) {
  const d = new Date(date).getTime();
  const s = Math.floor((Date.now() - d) / 1000);
  if (s < 60) return 'à l\'instant';
  if (s < 3600) return `il y a ${Math.floor(s / 60)} min`;
  if (s < 86400) return `il y a ${Math.floor(s / 3600)} h`;
  return `il y a ${Math.floor(s / 86400)} j`;
}

export default function Forum() {
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [authorName, setAuthorName] = useState('');
  const [topics, setTopics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const s = getSession();
    setSession(s);
    if (s) {
      base44.entities.Technician.get(s.technicianId)
        .then(t => setAuthorName(t.name || `${t.nom || ''} ${t.prenoms || ''}`.trim() || 'Technicien'))
        .catch(() => setAuthorName('Technicien'));
    }
  }, []);

  const loadTopics = () => base44.entities.ForumTopic.list('-created_date', 100).then(setTopics).finally(() => setLoading(false));

  useEffect(() => {
    loadTopics();
    const unsub = base44.entities.ForumTopic.subscribe(() => loadTopics());
    return unsub;
  }, []);

  const createTopic = async (e) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;
    setBusy(true);
    try {
      await base44.entities.ForumTopic.create({
        title: title.trim(),
        content: content.trim(),
        author_name: authorName,
        author_id: session.technicianId
      });
      setTitle(''); setContent(''); setShowForm(false);
    } finally { setBusy(false); }
  };

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-[#D3CCBE] px-5 pt-5 pb-4">
        <div className="section-kicker"><span>FORUM</span><span className="directory-count">{topics.length.toString().padStart(2, '0')} SUJETS</span></div>
        <h2 className="mt-3 text-2xl font-semibold tracking-tight text-slate-900">Échangez entre <span className="text-[#3A8E9C]">techniciens.</span></h2>
        <p className="mt-2 text-sm text-slate-500">Posez vos questions, partagez vos expériences et répondez en temps réel.</p>
        {session ? (
          <button onClick={() => setShowForm(v => !v)} className="mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-[#3A8E9C] px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#2E7B88]">
            <Plus size={16} strokeWidth={2.4}/> {showForm ? 'Annuler' : 'Créer un sujet'}
          </button>
        ) : (
          <div className="glass mt-3 flex items-center gap-2 rounded-2xl px-4 py-3 text-sm text-slate-500">
            <Lock size={15}/>
            <span>Connectez-vous pour créer un sujet.</span>
            <Link to="/connexion" className="ml-auto font-semibold text-[#3A8E9C] underline">Connexion</Link>
          </div>
        )}
      </div>

      {showForm && session && (
        <form onSubmit={createTopic} className="border-b border-[#D3CCBE] bg-[#F3EFE7] px-5 py-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-900">Nouveau sujet</h3>
            <button type="button" onClick={() => setShowForm(false)} aria-label="Fermer" className="text-slate-500"><X size={18}/></button>
          </div>
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Titre du sujet" className="mt-3 w-full rounded-lg border border-[#D3CCBE] bg-[#E9E3D7] px-3 py-3 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]"/>
          <textarea value={content} onChange={e => setContent(e.target.value)} placeholder="Décrivez votre sujet…" rows={4} className="mt-3 w-full resize-none rounded-lg border border-[#D3CCBE] bg-[#E9E3D7] px-3 py-3 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]"/>
          <button type="submit" disabled={busy} className="mt-3 flex items-center justify-center gap-2 rounded-full bg-[#3A8E9C] px-5 py-2.5 text-sm font-semibold text-white disabled:opacity-50 hover:bg-[#2E7B88]">
            {busy ? <><Loader2 size={16} className="animate-spin"/>Publication…</> : <>Publier le sujet</>}
          </button>
        </form>
      )}

      <div className="scroll-pane min-h-0 flex-1 overflow-y-auto px-5 py-4">
        {loading ? <div className="flex h-full items-center justify-center text-sm text-slate-500">Chargement…</div>
        : topics.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-2 text-center text-slate-500">
            <MessageSquare size={26}/>
            <h3 className="text-base font-semibold text-slate-900">Aucun sujet pour l'instant.</h3>
            <p>Soyez le premier à lancer la discussion.</p>
          </div>
        ) : (
          <div className="grid gap-3">
            {topics.map(t => (
              <button key={t.id} onClick={() => navigate(`/forum/${t.id}`)} className="glass glass-hover rounded-2xl p-4 text-left">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-base font-semibold leading-tight text-slate-900">{t.title}</h3>
                  <ArrowUpRight size={16} className="shrink-0 text-[#3A8E9C]"/>
                </div>
                <p className="mt-2 line-clamp-2 text-sm text-slate-500">{t.content}</p>
                <div className="mt-3 flex items-center justify-between border-t border-[#D3CCBE] pt-2 font-mono text-xs uppercase tracking-wide text-slate-500">
                  <span>{t.author_name || 'Anonyme'}</span>
                  <span>{timeAgo(t.created_date)}</span>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}