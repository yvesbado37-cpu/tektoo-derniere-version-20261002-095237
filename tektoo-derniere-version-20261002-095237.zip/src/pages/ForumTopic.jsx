import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Send, Loader2, Lock, MessageSquare } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getSession } from '@/lib/technicianSession';

function timeAgo(date) {
  const d = new Date(date).getTime();
  const s = Math.floor((Date.now() - d) / 1000);
  if (s < 60) return 'à l\'instant';
  if (s < 3600) return `il y a ${Math.floor(s / 60)} min`;
  if (s < 86400) return `il y a ${Math.floor(s / 3600)} h`;
  return `il y a ${Math.floor(s / 86400)} j`;
}

export default function ForumTopic() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [topic, setTopic] = useState(null);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState(null);
  const [authorName, setAuthorName] = useState('');
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    const s = getSession();
    setSession(s);
    if (s) {
      base44.entities.Technician.get(s.technicianId)
        .then(t => setAuthorName(t.name || `${t.nom || ''} ${t.prenoms || ''}`.trim() || 'Technicien'))
        .catch(() => setAuthorName('Technicien'));
    }
  }, []);

  useEffect(() => {
    base44.entities.ForumTopic.get(id).then(setTopic).catch(() => setTopic(null));
  }, [id]);

  const loadMessages = () => base44.entities.ForumMessage.filter({ topic_id: id }, 'created_date', 200).then(setMessages).finally(() => setLoading(false));

  useEffect(() => {
    loadMessages();
    const unsub = base44.entities.ForumMessage.subscribe(() => loadMessages());
    return unsub;
  }, [id]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const send = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    setBusy(true);
    try {
      await base44.entities.ForumMessage.create({
        topic_id: id,
        content: text.trim(),
        author_name: authorName,
        author_id: session.technicianId
      });
      setText('');
    } finally { setBusy(false); }
  };

  if (loading && !topic) return <div className="flex h-full items-center justify-center text-sm text-slate-500">Chargement…</div>;
  if (!topic) return (
    <div className="flex h-full flex-col items-center justify-center gap-3 px-5 text-center text-slate-500">
      <MessageSquare size={26}/>
      <h3 className="text-base font-semibold text-slate-900">Sujet introuvable.</h3>
      <button onClick={() => navigate('/forum')} className="text-[#3A8E9C] underline">Retour au forum</button>
    </div>
  );

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-[#D3CCBE] px-5 pt-4 pb-4">
        <button onClick={() => navigate('/forum')} className="flex items-center gap-1.5 text-sm font-semibold text-[#3A8E9C]"><ArrowLeft size={16}/> Retour</button>
        <h2 className="mt-2 text-xl font-semibold leading-tight text-slate-900">{topic.title}</h2>
        <p className="mt-2 text-sm text-slate-500">{topic.content}</p>
        <div className="mt-3 flex items-center justify-between border-t border-[#D3CCBE] pt-2 font-mono text-xs uppercase tracking-wide text-slate-500">
          <span>{topic.author_name || 'Anonyme'}</span>
          <span>{timeAgo(topic.created_date)}</span>
        </div>
      </div>

      <div ref={scrollRef} className="scroll-pane min-h-0 flex-1 overflow-y-auto px-5 py-4">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-2 text-center text-slate-500">
            <MessageSquare size={24}/>
            <p className="text-sm">Soyez le premier à répondre.</p>
          </div>
        ) : (
          <div className="grid gap-3">
            {messages.map(m => {
              const mine = session && m.author_id === session.technicianId;
              return (
                <div key={m.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] rounded-2xl border px-3 py-2.5 ${mine ? 'border-[#3A8E9C] bg-[#3A8E9C] text-white' : 'border-[#D3CCBE] bg-[#F3EFE7]'}`}>
                    {!mine && <div className="mb-1 text-xs font-semibold text-[#3A8E9C]">{m.author_name || 'Anonyme'}</div>}
                    <p className="text-sm leading-relaxed text-slate-900">{m.content}</p>
                    <div className={`mt-1 text-right text-[10px] ${mine ? 'text-cyan-200' : 'text-slate-500'}`}>{timeAgo(m.created_date)}</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="border-t border-[#D3CCBE] bg-[#F3EFE7] px-5 py-3">
        {session ? (
          <form onSubmit={send} className="flex items-center gap-2">
            <input value={text} onChange={e => setText(e.target.value)} placeholder="Écrivez votre message…" className="w-full rounded-full border border-[#D3CCBE] bg-[#E9E3D7] px-4 py-2.5 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]"/>
            <button type="submit" disabled={busy || !text.trim()} aria-label="Envoyer" className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#3A8E9C] text-white disabled:opacity-50 hover:bg-[#2E7B88]">
              {busy ? <Loader2 size={18} className="animate-spin"/> : <Send size={18}/>}
            </button>
          </form>
        ) : (
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Lock size={15}/>
            <span>Connectez-vous pour participer.</span>
            <Link to="/connexion" className="ml-auto font-semibold text-[#3A8E9C] underline">Connexion</Link>
          </div>
        )}
      </div>
    </div>
  );
}