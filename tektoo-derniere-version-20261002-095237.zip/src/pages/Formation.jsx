import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { GraduationCap, Loader2, Search } from 'lucide-react';
import { trainingDateLabel, trainingErrorMessage, trainingRequest, trainingStatus, trainingStatusLabel } from '@/lib/training';

export default function Formation() {
  const [trainings, setTrainings] = useState(/** @type {import('@/lib/training').Training[]} */ ([]));
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');

  useEffect(() => {
    let active = true;
    let timer;
    const refresh = async () => {
      try {
        const result = await trainingRequest('list');
        if (active) { setTrainings(result.trainings); setError(''); }
      } catch (err) {
        if (active) setError(trainingErrorMessage(err));
      } finally {
        if (active) { setLoading(false); timer = setTimeout(refresh, 15000); }
      }
    };
    refresh();
    return () => { active = false; clearTimeout(timer); };
  }, []);

  const filtered = trainings.filter((training) =>
    ['scheduled', 'live'].includes(trainingStatus(training))
    && `${training.title} ${training.trainer_name}`.toLowerCase().includes(query.trim().toLowerCase()));
  return (
    <div className="scroll-pane h-full overflow-y-auto px-5 py-6">
      <div className="flex items-center gap-3 text-emerald-700">
        <GraduationCap size={28} />
        <h1 className="text-2xl font-semibold">Formation</h1>
      </div>
      <p className="mt-2 text-sm text-slate-600">Découvrez les formations en cours et à venir. Aucun compte tektoo n’est nécessaire : entrez avec les accès remis par votre formateur à l’heure de début.</p>
      <Link to="/espace-formateur" className="mt-3 inline-block text-sm font-semibold text-emerald-700 underline">Mon espace Formateur</Link>
      <label className="mt-5 flex items-center gap-2 rounded-xl border border-[#D3CCBE] bg-white p-3">
        <Search size={18} className="text-emerald-700" />
        <span className="sr-only">Rechercher une formation ou un formateur</span>
        <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Titre ou nom du formateur…" className="w-full bg-transparent text-sm outline-none" />
      </label>
      {error && <p role="alert" className="mt-4 text-sm text-red-600">{error}</p>}
      {loading ? <Loader2 className="mx-auto mt-8 animate-spin text-emerald-600" /> : (
        <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {!filtered.length && !error && <p className="text-sm text-slate-500">Aucune formation ne correspond à votre recherche.</p>}
          {filtered.map((training) => (
            <Link key={training.id} to={`/formation/${training.id}`} className="rounded-2xl border border-emerald-200 bg-white p-5 shadow-sm transition hover:border-emerald-600">
              <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">{trainingStatusLabel(trainingStatus(training))}</span>
              <h2 className="mt-3 text-lg font-semibold text-slate-900">{training.title}</h2>
              <p className="mt-1 text-sm text-emerald-700">{training.trainer_name} · Formateur</p>
              <p className="mt-3 text-sm text-slate-600">{trainingDateLabel(training.starts_at)}</p>
              <p className="mt-1 text-xs text-slate-500">{training.duration_hours} h · {training.participant_count} participants</p>
              <span className="mt-4 inline-block text-sm font-semibold text-emerald-700">Voir la formation →</span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
