import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowUpRight, Check, UserPlus, Zap, MapPin } from 'lucide-react';
import { trades } from '@/components/directory/catalog';

export default function Home() {
  const navigate = useNavigate();
  const mainTrades = trades.filter(t => t.id !== 'autres');

  return (
    <div className="tech-bg scroll-pane flex h-full flex-col overflow-y-auto">
      <div className="relative px-5 pt-8 pb-6">
        <div className="flex items-center gap-2 mb-4">
          <span className="pulse-dot inline-block h-2 w-2 rounded-full bg-[#3A8E9C]" />
          <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#3A8E9C]">L'annuaire technique ultime</span>
        </div>

        <h1 className="text-[2.4rem] font-black leading-[1.02] tracking-[-0.04em] text-slate-900">
          Le bon <span className="gradient-text">technicien</span>.<br />
          Au bon endroit.<br />
          <span className="gradient-text">Tout simplement.</span>
        </h1>

        <p className="mt-4 text-sm leading-relaxed text-slate-700 max-w-[320px]">
          Trouvez le professionnel qu'il vous faut et contactez-le directement. Sans intermédiaire, sans frais.
        </p>

        <div className="mt-5 grid grid-cols-2 gap-3">
          <Link to="/explorer" className="gradient-btn tech-glow flex items-center justify-center gap-2 rounded-full px-4 py-3 text-sm font-bold text-white">
            <span>Explorer</span><ArrowUpRight size={16} />
          </Link>
          <Link to="/inscription" className="glass glass-hover flex items-center justify-center gap-2 rounded-full px-4 py-3 text-sm font-bold text-[#3A8E9C]">
            <UserPlus size={16} strokeWidth={2.2} /><span>Créer mon profil</span>
          </Link>
        </div>

        <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 text-xs font-semibold text-slate-700">
          <span className="flex items-center gap-1.5"><Check size={12} className="text-[#3A8E9C]" /> Contact direct</span>
          <span className="flex items-center gap-1.5"><Check size={12} className="text-[#3A8E9C]" /> Sans intermédiaire</span>
          <span className="flex items-center gap-1.5"><Check size={12} className="text-[#3A8E9C]" /> Accès gratuit</span>
        </div>
      </div>

      <div className="relative px-5 pb-6">
        <div className="flex items-center gap-2 mb-3">
          <Zap size={14} className="text-[#3A8E9C]" />
          <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-700">Domaines d'expertise</span>
        </div>
        <div className="grid grid-cols-2 gap-2.5">
          {mainTrades.map(t => (
            <button
              key={t.id}
              onClick={() => navigate(`/explorer?trade=${t.id}`)}
              className="glass glass-hover group flex flex-col gap-3 rounded-2xl p-4 text-left"
            >
              <div className="tech-card-icon group-hover:scale-110 transition-transform">
                <t.icon size={20} strokeWidth={1.8} />
              </div>
              <div>
                <div className="text-sm font-bold leading-tight text-slate-900">{t.label}</div>
                <div className="mt-0.5 text-[10px] font-semibold text-slate-600">Voir les pros →</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="relative px-5 pb-8">
        <div className="grid gap-2.5">
          <div className="glass glass-hover flex items-center gap-3 rounded-2xl p-4">
            <div className="tech-card-icon"><MapPin size={18} /></div>
            <div>
              <div className="text-sm font-bold text-slate-900">Proche de vous</div>
              <div className="text-[11px] font-semibold text-slate-600">Techniciens dans votre ville, votre quartier</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}