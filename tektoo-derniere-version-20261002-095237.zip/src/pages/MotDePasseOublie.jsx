import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Loader2, KeyRound } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function MotDePasseOublie() {
  const navigate = useNavigate();
  const [phone, setPhone] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const requestReset = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      const res = await base44.functions.invoke('technicianAccount', { action: 'requestReset', phone });
      if (res.data.sent) {
        navigate(`/entrez-code?phone=${encodeURIComponent(phone)}`);
      } else if (res.data.whatsappLink) {
        navigate(`/entrez-code?phone=${encodeURIComponent(phone)}`, { state: { whatsappLink: res.data.whatsappLink } });
      } else {
        setError('Envoi impossible. Réessayez.');
      }
    } catch (err) {
      setError(err?.response?.data?.error || 'Demande impossible. Vérifiez le numéro.');
    } finally { setBusy(false); }
  };

  return (
    <div className="scroll-pane flex h-full flex-col overflow-y-auto px-5 py-6">
      <div className="eyebrow text-[#3A8E9C]">RÉCUPÉRATION</div>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-900">Mot de passe oublié</h1>

      <form onSubmit={requestReset} className="mt-6 grid gap-4">
        <p className="text-sm text-slate-500">Saisissez le numéro enregistré sur votre compte pour recevoir un code de récupération par WhatsApp.</p>
        <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Numéro de téléphone
          <input required type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+226 XX XX XX XX" className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
        </label>
        {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
        <button type="submit" disabled={busy} className="primary-button">
          {busy ? <><Loader2 size={17} className="animate-spin"/>Envoi…</> : <><KeyRound size={17}/>Envoyer le code par WhatsApp</>}
        </button>
      </form>

      <p className="mt-6 text-sm text-slate-500"><Link to="/connexion" className="text-[#3A8E9C] underline">Retour à la connexion</Link></p>
    </div>
  );
}