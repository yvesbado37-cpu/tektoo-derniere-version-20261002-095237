import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FileDown, GraduationCap, Loader2, Plus } from 'lucide-react';
import { getSession } from '@/lib/technicianSession';
import { downloadTrainingCredentials } from '@/lib/trainingPdf';
import { MAX_TRAINING_PARTICIPANTS, trainingDateLabel, trainingErrorMessage, trainingRequest, trainingStatus, trainingStatusLabel } from '@/lib/training';

export default function EspaceFormateur() {
  const [session] = useState(() => getSession());
  const auth = { accountId: session?.accountId, sessionToken: session?.sessionToken };
  const [trainings, setTrainings] = useState(/** @type {import('@/lib/training').Training[]} */ ([]));
  const [expiresAt, setExpiresAt] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [feedback, setFeedback] = useState('');
  const [busy, setBusy] = useState('');
  const [form, setForm] = useState({ title: '', startsAt: '', durationHours: '1', participantCount: '10' });
  const [credentials, setCredentials] = useState(/** @type {Record<string, import('@/lib/training').TrainingCredential[]>} */ ({}));

  useEffect(() => {
    let active = true;
    if (!session) { setLoading(false); return; }
    trainingRequest('mine', { accountId: session.accountId, sessionToken: session.sessionToken })
      .then((result) => {
        if (active) { setTrainings(result.trainings); setExpiresAt(result.technician.trainer_expires_at); }
      })
      .catch((err) => { if (active) setError(trainingErrorMessage(err)); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [session]);

  const create = async (event) => {
    event.preventDefault();
    setBusy('create'); setError(''); setFeedback('');
    try {
      const start = new Date(form.startsAt);
      if (!Number.isFinite(start.getTime())) throw new Error('Date de début invalide.');
      const result = await trainingRequest('create', {
        ...auth, ...form, startsAt: start.toISOString(),
        durationHours: Number(form.durationHours), participantCount: Number(form.participantCount)
      });
      setTrainings((current) => [result.training, ...current]);
      setForm({ title: '', startsAt: '', durationHours: '1', participantCount: '10' });
      setFeedback('Formation publiée. Générez maintenant les identifiants participants.');
    } catch (err) { setError(trainingErrorMessage(err)); }
    finally { setBusy(''); }
  };

  const exportAccess = async (training, regenerate = false) => {
    if (regenerate && !window.confirm('Générer de nouveaux accès invalide tous les anciens identifiants. Continuer ?')) return;
    setBusy(training.id); setError(''); setFeedback('');
    try {
      let rows = credentials[training.id];
      if (!rows || regenerate) {
        if (training.has_credentials && !regenerate && !window.confirm('Les mots de passe ne sont pas conservés. Créer un nouveau PDF invalidera les anciens accès. Continuer ?')) return;
        const result = await trainingRequest('credentials', { ...auth, trainingId: training.id });
        rows = result.credentials;
        setCredentials((current) => ({ ...current, [training.id]: rows }));
        setTrainings((current) => current.map((item) => item.id === training.id ? result.training : item));
      }
      const result = await downloadTrainingCredentials(training, rows);
      setFeedback(result?.message || 'PDF des identifiants généré. Distribuez une ligne par participant.');
    } catch (err) { setError(trainingErrorMessage(err)); }
    finally { setBusy(''); }
  };

  const cancel = async (training) => {
    if (!window.confirm('Annuler cette formation et invalider immédiatement tous ses accès ?')) return;
    setBusy(training.id); setError('');
    try {
      const result = await trainingRequest('cancel', { ...auth, trainingId: training.id });
      setTrainings((current) => current.map((item) => item.id === training.id ? result.training : item));
    } catch (err) { setError(trainingErrorMessage(err)); }
    finally { setBusy(''); }
  };

  if (loading) return <Loader2 className="mx-auto mt-10 animate-spin text-emerald-600" />;
  if (!session) return <div className="p-6 text-center"><p>Connectez-vous à votre compte Formateur.</p><Link className="mt-3 inline-block text-emerald-700 underline" to="/connexion">Se connecter</Link></div>;
  const updateForm = (key, value) => setForm((current) => ({ ...current, [key]: value }));
  return (
    <div className="scroll-pane h-full overflow-y-auto px-5 py-6">
      <h1 className="flex items-center gap-2 text-2xl font-semibold text-emerald-700"><GraduationCap /> Espace Formateur</h1>
      {expiresAt && <p className="mt-2 text-sm text-slate-600">Accès jusqu’au {trainingDateLabel(expiresAt)}. Renouvellement mensuel réservé à Admin Pro.</p>}
      <p className="mt-2 text-xs text-slate-500">Les dates sont saisies dans le fuseau horaire de cet appareil. Les participants ne peuvent entrer qu’entre le début et la fin de la session.</p>
      {error && <p role="alert" className="mt-4 text-sm text-red-600">{error}</p>}
      {feedback && <p role="status" className="mt-4 text-sm text-emerald-700">{feedback}</p>}
      {expiresAt && (
        <form onSubmit={create} className="mt-5 grid gap-3 rounded-2xl border border-emerald-200 bg-white p-5 sm:grid-cols-2">
          <label className="grid gap-1 text-sm font-semibold">Titre<input required maxLength={160} value={form.title} onChange={(event) => updateForm('title', event.target.value)} className="rounded-lg border p-2 font-normal" /></label>
          <label className="grid gap-1 text-sm font-semibold">Date et heure de début<input required type="datetime-local" value={form.startsAt} onChange={(event) => updateForm('startsAt', event.target.value)} className="rounded-lg border p-2 font-normal" /></label>
          <label className="grid gap-1 text-sm font-semibold">Durée (heures)<input required type="number" min="0.25" step="0.25" value={form.durationHours} onChange={(event) => updateForm('durationHours', event.target.value)} className="rounded-lg border p-2 font-normal" /></label>
          <label className="grid gap-1 text-sm font-semibold">Nombre de participants<input required type="number" min="1" max={MAX_TRAINING_PARTICIPANTS} step="1" value={form.participantCount} onChange={(event) => updateForm('participantCount', event.target.value)} className="rounded-lg border p-2 font-normal" /></label>
          <button disabled={Boolean(busy)} className="flex items-center justify-center gap-2 rounded-full bg-emerald-700 px-4 py-3 text-sm font-semibold text-white disabled:opacity-50 sm:col-span-2"><Plus size={16} /> Publier la formation</button>
        </form>
      )}
      <div className="mt-5 space-y-4">
        {trainings.map((training) => {
          const status = trainingStatus(training);
          return (
            <article key={training.id} className="rounded-2xl border border-emerald-200 bg-white p-5">
              <h2 className="text-lg font-semibold">{training.title}</h2>
              <p className="mt-1 text-sm text-slate-600">{trainingStatusLabel(status)} · {trainingDateLabel(training.starts_at)} · {training.duration_hours} h · {training.participant_count} participants</p>
              <div className="mt-4 flex flex-wrap gap-3">
                <Link to={`/formation/${training.id}?formateur=1`} className="rounded-full bg-emerald-700 px-4 py-2 text-sm font-semibold text-white">Ouvrir mon groupe</Link>
                {(status === 'scheduled' || credentials[training.id]) && (
                  <button onClick={() => exportAccess(training)} disabled={Boolean(busy)} className="flex items-center gap-2 rounded-full border border-emerald-700 px-4 py-2 text-sm font-semibold text-emerald-700 disabled:opacity-50"><FileDown size={16} /> {credentials[training.id] ? 'Retélécharger les accès PDF' : 'Générer les accès PDF'}</button>
                )}
                {status === 'scheduled' && credentials[training.id] && <button onClick={() => exportAccess(training, true)} disabled={Boolean(busy)} className="text-sm text-amber-700 underline">Remplacer les accès</button>}
                {(status === 'scheduled' || status === 'live') && <button onClick={() => cancel(training)} disabled={Boolean(busy)} className="text-sm text-red-600 underline">Annuler la session</button>}
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
