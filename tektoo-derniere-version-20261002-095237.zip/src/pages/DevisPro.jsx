import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { devisProApp } from '@/lib/companionApps';
import { isProActive } from '@/lib/proStatus';
import { getSession } from '@/lib/technicianSession';
import { CompanionAppWorkspace } from '@/components/companion/CompanionAppWorkspace';

export default function DevisPro() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [technician, setTechnician] = useState(null);

  useEffect(() => {
    let active = true;
    const session = getSession();
    if (!session) {
      navigate('/mon-compte', { replace: true });
      return;
    }

    base44.entities.Technician.get(session.technicianId)
      .then((technician) => {
        if (!active) return;
        if (!isProActive(technician)) {
          navigate('/mon-compte', { replace: true });
          return;
        }
        setTechnician(technician);
        setLoading(false);
      })
      .catch(() => {
        if (!active) return;
        navigate('/mon-compte', { replace: true });
      });

    return () => { active = false; };
  }, [navigate]);

  if (loading) {
    return <div className="flex h-full items-center justify-center text-sm text-slate-500"><Loader2 size={22} className="animate-spin"/></div>;
  }

  return (
    <div className="scroll-pane flex h-full flex-col overflow-y-auto px-5 py-6">
      <Link to="/mon-compte" className="inline-flex w-fit items-center gap-2 text-sm font-semibold text-[#3A8E9C]">
        <ArrowLeft size={16} /> Retour à mon compte
      </Link>
      <CompanionAppWorkspace app={devisProApp} technician={technician} standalone />
    </div>
  );
}
