import React, { useState } from 'react';
import { useNavigate, Link, useSearchParams, useLocation } from 'react-router-dom';
import { Loader2, KeyRound, ArrowUpRight, CheckCircle2, MessageCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function EntrezCode() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const location = useLocation();
  const phone = params.get('phone') || '';
  const whatsappLink = location.state?.whatsappLink;
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newPasswordConfirm, setNewPasswordConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const reset = async (e) => {
    e.preventDefault();
    setError('');
    if (newPassword !== newPasswordConfirm) { setError('Les deux mots de passe ne correspondent pas.'); return; }
    setBusy(true);
    try {
      await base44.functions.invoke('technicianAccount', {
        action: 'resetPassword',
        phone, code, newPassword
      });
      setDone(true);
    } catch (err) {
      setError(err?.response?.data?.error || 'Réinitialisation impossible.');
    } finally { setBusy(false); }
  };

  if (!phone) {
    return (
      <div className="scroll-pane flex h-full flex-col items-center justify-center gap-4 px-5 py-8 text-center">
        <p className="text-sm text-slate-500">Numéro manquant.</p>
        <Link to="/mot-de-passe-oublie" className="text-[#3A8E9C] underline">Retour</Link>
      </div>
    );
  }

  if (done) {
    return (
      <div className="scroll-pane flex h-full flex-col items-center justify-center gap-4 px-5 py-8 text-center">
        <CheckCircle2 size={44} className="text-emerald-600"/>
        <h1 className="text-xl font-semibold text-slate-900">Mot de passe réinitialisé</h1>
        <p className="max-w-xs text-sm text-slate-500">Vous pouvez vous connecter avec votre nouveau mot de passe.</p>
        <button className="primary-button" onClick={() => navigate('/connexion')}>Aller à la connexion <ArrowUpRight size={16}/></button>
      </div>
    );
  }

  return (
    <div className="scroll-pane flex h-full flex-col overflow-y-auto px-5 py-6">
      <div className="eyebrow text-[#3A8E9C]">RÉCUPÉRATION</div>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-900">Entrez votre code</h1>
      <p className="mt-2 text-sm text-slate-500">Un code de récupération va être envoyé sur votre numéro WhatsApp <span className="font-semibold text-slate-700">{phone}</span>. Cliquez sur le bouton ci-dessous pour l'obtenir.</p>

      {whatsappLink && (
        <>
          <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="whatsapp-button mt-4">
            <MessageCircle size={17}/>Obtenir le code de récupération sur WhatsApp
          </a>
          <p className="mt-3 rounded-none border border-[#D3CCBE] bg-[#E9E3D7] px-4 py-3 text-xs leading-relaxed text-slate-500">
            <strong className="text-slate-700">Important :</strong> après avoir ouvert WhatsApp, appuyez sur le bouton <strong className="text-slate-700">Envoyer</strong> pour envoyer le message. Le lien de récupération deviendra alors cliquable. Cliquez dessus pour réinitialiser votre mot de passe.
          </p>
        </>
      )}

      <form onSubmit={reset} className="mt-6 grid gap-4">
        <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Code de récupération
          <input required inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} placeholder="6 chiffres" className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
        </label>
        <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Nouveau mot de passe
          <input required type="password" minLength={6} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="6 caractères minimum" className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
        </label>
        <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Confirmer le mot de passe
          <input required type="password" minLength={6} value={newPasswordConfirm} onChange={(e) => setNewPasswordConfirm(e.target.value)} placeholder="Saisissez à nouveau" className="w-full rounded-none border border-[#D3CCBE] bg-white px-3 py-3 font-normal text-slate-900 outline-none focus:border-[#3A8E9C] shadow-sm"/>
        </label>
        {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
        <button type="submit" disabled={busy} className="primary-button">
          {busy ? <><Loader2 size={17} className="animate-spin"/>Réinitialisation…</> : <><KeyRound size={17}/>Réinitialiser mon mot de passe</>}
        </button>
      </form>

      <p className="mt-6 text-sm text-slate-500"><Link to="/connexion" className="text-[#3A8E9C] underline">Retour à la connexion</Link></p>
    </div>
  );
}