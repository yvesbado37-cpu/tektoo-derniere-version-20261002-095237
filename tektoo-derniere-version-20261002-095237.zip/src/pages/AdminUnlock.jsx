import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, ShieldCheck, KeyRound, MessageCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getSession } from '@/lib/technicianSession';

const UNLOCK_KEY = 'tektoo_admin_unlocked';
const YVES_TECHNICIAN_ID = '6aaa799537cfecc045c07485';
const ADMIN_PHONE = '22672330796';

export default function AdminUnlock() {
  const navigate = useNavigate();
  const session = getSession();
  const isYves = session?.technicianId === YVES_TECHNICIAN_ID;

  const [access, setAccess] = useState(null);
  const [error, setError] = useState('');
  const [waLink, setWaLink] = useState('');
  const [magicBusy, setMagicBusy] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [mode, setMode] = useState('wa_link'); // 'wa_link' | 'pw_verify' | 'pw_setup' | 'pw_change'
  const [busy, setBusy] = useState(false);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [current, setCurrent] = useState('');

  const urlParams = new URLSearchParams(window.location.search);
  const urlToken = urlParams.get('token');
  const urlCode = urlParams.get('code');

  const invoke = async (action, extra = {}) => {
    const res = await base44.functions.invoke('adminAccess', {
      action, accountId: session.accountId, sessionToken: session.sessionToken, ...extra
    });
    return res.data;
  };

  // Redirige si pas connecté en tant que Yves.
  useEffect(() => {
    if (!session || !isYves) { navigate('/mon-compte', { replace: true }); }
  }, []);

  // Charge l'état d'accès admin.
  useEffect(() => {
    if (!isYves) return;
    let active = true;
    invoke('hasAccess')
      .then((data) => { if (active) setAccess(data); })
      .catch(() => { if (active) setAccess({}); });
    return () => { active = false; };
  }, [isYves]);

  // Vérification du lien magique reçu via WhatsApp.
  useEffect(() => {
    if (!urlToken || !isYves || !access) return;
    let active = true;
    setVerifying(true);
    invoke('verifyMagic', { token: urlToken, code: urlCode })
      .then(() => {
        if (!active) return;
        sessionStorage.setItem(UNLOCK_KEY, '1');
        window.history.replaceState({}, '', '/admin-unlock');
        navigate('/admin-pro', { replace: true });
      })
      .catch((err) => {
        if (!active) return;
        setError(err?.response?.data?.error || err?.data?.error || 'Lien invalide ou expiré.');
        setVerifying(false);
      });
    return () => { active = false; };
  }, [urlToken, urlCode, isYves, access]);

  // Génération automatique du code + lien magique à chaque visite.
  useEffect(() => {
    if (!isYves || !access || urlToken || mode !== 'wa_link') return;
    let active = true;
    setMagicBusy(true);
    setError('');
    invoke('generateMagicLink')
      .then((data) => {
        if (!active) return;
        const magicUrl = `${window.location.origin}/admin-pro?token=${data.token}&code=${data.code}`;
        const text = encodeURIComponent(`tektoo — Accès administrateur\nCode de vérification : ${data.code}\nLien d'accès (valable 10 min) : ${magicUrl}`);
        setWaLink(`https://wa.me/${ADMIN_PHONE}?text=${text}`);
      })
      .catch((err) => { if (active) setError(err?.response?.data?.error || err?.data?.error || 'Génération impossible.'); })
      .finally(() => { if (active) setMagicBusy(false); });
    return () => { active = false; };
  }, [isYves, access, urlToken, mode]);

  const setUnlocked = () => {
    sessionStorage.setItem(UNLOCK_KEY, '1');
    navigate('/admin-pro', { replace: true });
  };

  const pwVerify = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      await invoke('verify', { adminPassword: password });
      setUnlocked();
    } catch (err) {
      setError(err?.response?.data?.error || err?.data?.error || 'Mot de passe admin incorrect.');
    } finally { setBusy(false); }
  };

  const pwSetup = async (e) => {
    e.preventDefault();
    if (password.length < 6) { setError('6 caractères minimum.'); return; }
    if (password !== confirm) { setError('Les mots de passe ne correspondent pas.'); return; }
    setBusy(true); setError('');
    try {
      await invoke('setPassword', { adminPassword: password });
      setUnlocked();
    } catch (err) {
      setError(err?.response?.data?.error || err?.data?.error || 'Échec de la configuration.');
    } finally { setBusy(false); }
  };

  const pwChange = async (e) => {
    e.preventDefault();
    if (password.length < 6) { setError('6 caractères minimum.'); return; }
    setBusy(true); setError('');
    try {
      await invoke('setPassword', { currentAdminPassword: current, adminPassword: password });
      setCurrent(''); setPassword(''); setConfirm('');
      setMode('pw_verify');
      setError('');
    } catch (err) {
      setError(err?.response?.data?.error || err?.data?.error || 'Échec du changement.');
    } finally { setBusy(false); }
  };

  if (!isYves || !access || verifying) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-2 px-5 text-center">
        <Loader2 size={22} className="animate-spin text-slate-400"/>
        <p className="text-sm text-slate-500">{verifying ? 'Vérification du lien…' : 'Chargement…'}</p>
        {verifying && error && <p className="text-sm text-red-600">{error}</p>}
      </div>
    );
  }

  const hasPw = !!access.hasAdminPassword;

  return (
    <div className="scroll-pane flex h-full flex-col items-center justify-center overflow-y-auto px-5 py-8">
      {mode === 'wa_link' && (
        <div className="w-full max-w-sm rounded-2xl border border-[#D3CCBE] bg-white p-6 shadow-sm">
          <div className="mb-5 flex items-center gap-2">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#10B981]/10 text-[#10B981]">
              <MessageCircle size={20}/>
            </span>
            <div>
              <h1 className="text-base font-semibold text-slate-900">Accès administrateur</h1>
              <p className="text-xs text-slate-500">Un code de vérification et un lien magique sont générés. Envoyez le message sur votre WhatsApp, puis cliquez le lien pour ouvrir la gestion des abonnements.</p>
            </div>
          </div>

          {error && <p className="mb-3 text-sm text-red-600">{error}</p>}

          <a
            href={waLink || '#'}
            target="_blank"
            rel="noopener noreferrer"
            aria-disabled={magicBusy || !waLink}
            onClick={(e) => { if (magicBusy || !waLink) e.preventDefault(); }}
            className="flex items-center justify-center gap-2 rounded-full bg-[#10B981] px-5 py-4 text-sm font-semibold text-white transition-colors hover:bg-[#0EA371] disabled:opacity-50"
          >
            {magicBusy ? <><Loader2 size={18} className="animate-spin"/>Génération…</> : <><MessageCircle size={18}/>Envoyer le code et le lien sur WhatsApp</>}
          </a>

          <p className="mt-3 text-center text-[11px] leading-relaxed text-slate-500">
            Le message est pré-rempli pour le +226 72 33 07 96. Valable 10 minutes. Un nouveau code est généré à chaque visite.
          </p>

          <div className="mt-5 flex justify-center border-t border-[#D3CCBE] pt-4 text-xs text-slate-500">
            <button type="button" onClick={() => setMode(hasPw ? 'pw_verify' : 'pw_setup')} className="underline">Utiliser un mot de passe à la place</button>
          </div>
        </div>
      )}

      {mode !== 'wa_link' && mode !== 'pw_change' && (
        <div className="w-full max-w-sm rounded-2xl border border-[#D3CCBE] bg-white p-6 shadow-sm">
          <div className="mb-5 flex items-center gap-2">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#3A8E9C]/10 text-[#3A8E9C]">
              <KeyRound size={20}/>
            </span>
            <div>
              <h1 className="text-base font-semibold text-slate-900">
                {mode === 'pw_verify' ? 'Accès administrateur' : 'Créer votre mot de passe admin'}
              </h1>
              <p className="text-xs text-slate-500">
                {mode === 'pw_verify' ? 'Saisissez votre mot de passe admin pour continuer.' : 'Définissez un mot de passe admin de secours.'}
              </p>
            </div>
          </div>

          <form onSubmit={mode === 'pw_setup' ? pwSetup : pwVerify} className="grid gap-3">
            <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Mot de passe admin
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus className="w-full rounded-lg border border-[#D3CCBE] bg-white px-3 py-3 text-sm outline-none focus:border-[#3A8E9C]"/>
            </label>
            {mode === 'pw_setup' && (
              <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Confirmer le mot de passe
                <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} className="w-full rounded-lg border border-[#D3CCBE] bg-white px-3 py-3 text-sm outline-none focus:border-[#3A8E9C]"/>
              </label>
            )}
            {error && <p className="text-sm text-red-600">{error}</p>}
            <button type="submit" disabled={busy} className="flex items-center justify-center gap-2 rounded-full bg-[#3A8E9C] px-5 py-3 text-sm font-semibold text-white disabled:opacity-50 hover:bg-[#2E7B88] transition-colors">
              {busy ? <><Loader2 size={16} className="animate-spin"/>Vérification…</> : mode === 'pw_setup' ? 'Créer l\'accès admin' : 'Déverrouiller'}
            </button>
            {mode === 'pw_verify' && (
              <button type="button" onClick={() => setMode('pw_change')} className="w-full text-center text-xs text-slate-500 underline">Changer mon mot de passe admin</button>
            )}
            <button type="button" onClick={() => setMode('wa_link')} className="w-full text-center text-xs text-slate-500 underline">Recevoir un code WhatsApp à la place</button>
          </form>
        </div>
      )}

      {mode === 'pw_change' && (
        <div className="w-full max-w-sm rounded-2xl border border-[#D3CCBE] bg-white p-6 shadow-sm">
          <h2 className="mb-3 text-sm font-semibold text-slate-900">Changer le mot de passe admin</h2>
          <form onSubmit={pwChange} className="grid gap-3">
            <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Mot de passe actuel
              <input type="password" value={current} onChange={(e) => setCurrent(e.target.value)} className="w-full rounded-lg border border-[#D3CCBE] bg-white px-3 py-3 text-sm outline-none focus:border-[#3A8E9C]"/>
            </label>
            <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Nouveau mot de passe
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full rounded-lg border border-[#D3CCBE] bg-white px-3 py-3 text-sm outline-none focus:border-[#3A8E9C]"/>
            </label>
            <label className="grid gap-1.5 text-xs font-semibold text-slate-700">Confirmer
              <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} className="w-full rounded-lg border border-[#D3CCBE] bg-white px-3 py-3 text-sm outline-none focus:border-[#3A8E9C]"/>
            </label>
            {error && <p className="text-sm text-red-600">{error}</p>}
            <div className="flex gap-2">
              <button type="submit" disabled={busy} className="flex flex-1 items-center justify-center gap-2 rounded-full bg-[#3A8E9C] px-5 py-3 text-sm font-semibold text-white disabled:opacity-50">
                {busy ? <Loader2 size={16} className="animate-spin"/> : 'Mettre à jour'}
              </button>
              <button type="button" onClick={() => setMode('pw_verify')} className="rounded-full border border-[#D3CCBE] px-4 py-3 text-sm font-semibold text-slate-700">Annuler</button>
            </div>
          </form>
        </div>
      )}

      <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-400">
        <ShieldCheck size={13}/> Accès admin sécurisé par tektoo
      </div>
    </div>
  );
}