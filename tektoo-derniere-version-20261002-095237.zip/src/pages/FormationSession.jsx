import React, { useEffect, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Loader2 } from 'lucide-react';
import TrainingDiscussion from '@/components/training/TrainingDiscussion';
import { getSession } from '@/lib/technicianSession';
import { readParticipantAccess, trainingDateLabel, trainingErrorMessage, trainingRequest, trainingStatus, trainingStatusLabel } from '@/lib/training';

export default function FormationSession() {
  const { id } = useParams();
  const [params] = useSearchParams();
  const trainerMode = params.get('formateur') === '1';
  const [session] = useState(() => getSession());
  const [training, setTraining] = useState(/** @type {import('@/lib/training').Training | null} */ (null));
  const [access, setAccess] = useState(() => readParticipantAccess(id));
  const [trainerDenied, setTrainerDenied] = useState(false);
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    let active = true;
    let timer;
    const refresh = async () => {
      try {
        const result = await trainingRequest('info', { trainingId: id });
        if (active) setTraining(result.training);
      } catch (err) { if (active) setError(trainingErrorMessage(err)); }
      finally {
        if (active) { setLoading(false); timer = setTimeout(refresh, 15000); }
      }
    };
    refresh();
    const clock = setInterval(() => setNow(Date.now()), 1000);
    return () => { active = false; clearTimeout(timer); clearInterval(clock); };
  }, [id]);

  const status = training ? trainingStatus(training, now) : '';
  const participantExpired = Boolean(access && Date.parse(access.expiresAt) <= now);
  useEffect(() => {
    if (status !== 'ended' && status !== 'cancelled' && !participantExpired) return;
    setAccess(null);
    try { sessionStorage.removeItem(`tektoo:formation:${id}`); }
    catch (err) { setError(trainingErrorMessage(err)); }
  }, [status, id, participantExpired]);

  const join = async (event) => {
    event.preventDefault(); setBusy(true); setError('');
    try {
      const result = await trainingRequest('join', { trainingId: id, ...form });
      sessionStorage.setItem(`tektoo:formation:${id}`, JSON.stringify(result));
      setAccess(result);
      setForm({ username: '', password: '' });
    } catch (err) { setError(trainingErrorMessage(err)); }
    finally { setBusy(false); }
  };

  const leave = () => {
    setAccess(null);
    try { sessionStorage.removeItem(`tektoo:formation:${id}`); }
    catch (err) { setError(trainingErrorMessage(err)); }
  };
  const denied = (message) => {
    if (trainerMode) setTrainerDenied(true);
    else leave();
    setError(message);
  };
  const auth = trainerMode && session && !trainerDenied
    ? { accountId: session.accountId, sessionToken: session.sessionToken }
    : !trainerMode && access && !participantExpired && status === 'live'
      ? { accessId: access.accessId, participantToken: access.participantToken } : null;
  if (loading) return <Loader2 className="mx-auto mt-10 animate-spin text-emerald-600" />;
  if (!training) return <div className="p-6"><p role="alert" className="text-red-600">{error || 'Formation introuvable.'}</p><Link to="/formation" className="mt-3 inline-block underline">Retour aux formations</Link></div>;
  return (
    <div className="flex h-full min-h-0 flex-col px-4 py-4">
      <Link to={trainerMode ? '/espace-formateur' : '/formation'} className="flex w-fit items-center gap-2 text-xs font-semibold text-emerald-700"><ArrowLeft size={14} /> Retour</Link>
      <h1 className="mt-2 text-xl font-semibold text-emerald-800">{training.title}</h1>
      <p className="mt-1 text-xs text-slate-600">{training.trainer_name} · {trainingStatusLabel(status)} · {trainingDateLabel(training.starts_at)} → {trainingDateLabel(training.ends_at)}</p>
      {access && !trainerMode && <button onClick={leave} className="mt-2 w-fit text-xs text-slate-600 underline">Quitter le groupe</button>}
      {error && <p role="alert" className="mt-3 text-sm text-red-600">{error}</p>}
      {auth ? (
        <TrainingDiscussion key={`${id}:${auth.accessId || auth.accountId}`} training={training} auth={auth} onTrainingChange={setTraining} onAccessDenied={denied} />
      ) : (
        <div className="mt-5 overflow-y-auto rounded-2xl border border-emerald-200 bg-white p-5">
          {status === 'scheduled' && <p className="text-sm text-slate-600">La session commencera le {trainingDateLabel(training.starts_at)}. Les identifiants seront utilisables à cette heure.</p>}
          {(status === 'ended' || status === 'cancelled') && <p className="text-sm text-slate-600">La session est {status === 'cancelled' ? 'annulée' : 'terminée'}. Les accès participants ne sont plus valides.</p>}
          {trainerMode ? (
            <Link to="/connexion" className="text-sm text-emerald-700 underline">{trainerDenied ? 'Reconnectez-vous ou contactez Admin Pro.' : 'Connectez-vous à votre compte Formateur.'}</Link>
          ) : status === 'live' && (
            <form onSubmit={join} className="grid max-w-md gap-3">
              <h2 className="text-lg font-semibold text-slate-900">Entrer dans la formation</h2>
              <p className="text-xs text-slate-500">Utilisez l’identifiant et le mot de passe remis par le formateur. Chaque accès correspond à un participant.</p>
              <label className="grid gap-1 text-sm">Identifiant<input required autoComplete="username" value={form.username} onChange={(event) => setForm((current) => ({ ...current, username: event.target.value }))} className="rounded-lg border p-2" /></label>
              <label className="grid gap-1 text-sm">Mot de passe<input required type="password" autoComplete="current-password" maxLength={128} value={form.password} onChange={(event) => setForm((current) => ({ ...current, password: event.target.value }))} className="rounded-lg border p-2" /></label>
              <button disabled={busy} className="rounded-full bg-emerald-700 px-4 py-3 text-sm font-semibold text-white disabled:opacity-50">{busy ? 'Connexion…' : 'Rejoindre la session'}</button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}
