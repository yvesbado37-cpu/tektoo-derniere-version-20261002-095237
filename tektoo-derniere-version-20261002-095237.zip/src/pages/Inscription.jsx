import React from 'react';
import JoinForm from '@/components/directory/JoinForm';
export default function Inscription() {
  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-[#D3CCBE] px-5 pt-5 pb-4">
        <div className="section-kicker"><span>INSCRIPTION</span><span>VOTRE SAVOIR-FAIRE</span></div>
        <h2 className="mt-3 text-2xl font-semibold tracking-tight text-slate-900">Créez votre <span className="text-[#3A8E9C]">profil tektoo.</span></h2>
        <p className="mt-1 text-sm text-slate-500">Renseignez vos informations pour être contacté par WhatsApp.</p>
      </div>
      <div className="scroll-pane min-h-0 flex-1 overflow-y-auto px-5 py-5"><div className="mx-auto max-w-xl"><JoinForm/></div></div>
    </div>
  );
}