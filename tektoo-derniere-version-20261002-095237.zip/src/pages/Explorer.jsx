import React, { useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Search, MapPin, Wrench, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import TechnicianCard from '@/components/directory/TechnicianCard';
import { normalize, trades, quartiers, quartiersBobo } from '@/components/directory/catalog';
import { isProActive } from '@/lib/proStatus';
export default function Explorer() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { data: records = [], isLoading: loading } = useQuery({
    queryKey: ['technicians'],
    queryFn: () => base44.entities.Technician.list('-created_date', 100),
    staleTime: 5 * 60 * 1000,
  });
  const { data: rankings = [] } = useQuery({
    queryKey: ['tradeRanking'],
    queryFn: () => base44.entities.TradeRanking.list('rank', 20),
    staleTime: 60 * 60 * 1000,
  });
  const tradeRank = useMemo(() => {
    const map = {};
    rankings.forEach(r => { map[r.trade] = r.rank; });
    return map;
  }, [rankings]);
  const [search, setSearch] = useState(params.get('q') || '');
  const [city, setCity] = useState(params.get('city') || '');
  const [quartier, setQuartier] = useState('');
  const [trade, setTrade] = useState(params.get('trade') || '');
  const all = records;
  const cities = [...new Set(all.map(t => t.city).filter(Boolean))].sort();
  const quartierOptions = [...new Set([...quartiers, ...quartiersBobo, ...all.map(t => t.quartier).filter(Boolean)])].sort();
  const filtered = useMemo(() => all.filter(t => {
    const category = trades.find(x => x.id === t.trade);
    const haystack = normalize([t.name, t.description, t.city, t.quartier, category?.label, category?.short, t.custom_trade, ...(category?.services || [])].join(' '));
    const tradeText = [category?.label, category?.short, t.custom_trade].filter(Boolean).join(' ');
    return (!trade || normalize(tradeText).includes(normalize(trade))) && (!city || normalize(t.city).includes(normalize(city))) && (!quartier || normalize(t.quartier).includes(normalize(quartier))) && (!search || haystack.includes(normalize(search)));
  }), [all, search, city, quartier, trade]);
  const sorted = [...filtered].sort((a, b) => {
    const proA = isProActive(a) ? 1 : 0;
    const proB = isProActive(b) ? 1 : 0;
    if (proA !== proB) return proB - proA;
    const rankA = tradeRank[a.trade] || 99;
    const rankB = tradeRank[b.trade] || 99;
    if (rankA !== rankB) return rankA - rankB;
    return (b.available ? 1 : 0) - (a.available ? 1 : 0) || (b.experience || 0) - (a.experience || 0);
  });
  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-[#D3CCBE] px-4 pt-2 pb-2">
        <h2 className="text-base font-semibold tracking-tight text-slate-900">Les plus <span className="text-[#3A8E9C]">actifs</span></h2>
        <div className="mt-1.5 flex items-center gap-2 border border-[#D3CCBE] bg-[#F3EFE7] px-3 py-1"><Search size={14} className="text-[#3A8E9C]"/><input aria-label="Rechercher" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Nom, besoin…" className="w-full bg-transparent text-sm text-slate-900 outline-none placeholder:text-slate-500"/></div>
        <div className="mt-1.5">
          <div className="grid grid-cols-3 border border-[#3A8E9C] bg-[#F3EFE7]">
            <label className="flex items-center gap-1.5 border-r border-[#D3CCBE] px-2.5 py-2"><MapPin size={14} className="text-[#3A8E9C]"/><input aria-label="Ville" value={city} onChange={e=>setCity(e.target.value)} list="city-list" placeholder="Ville" className="w-full bg-transparent text-xs font-semibold text-slate-900 outline-none"/></label>
            <label className="flex items-center gap-1.5 border-r border-[#D3CCBE] px-2.5 py-2"><MapPin size={14} className="text-[#3A8E9C]"/><input aria-label="Quartier" value={quartier} onChange={e=>setQuartier(e.target.value)} list="quartier-list" placeholder="Quartier" className="w-full bg-transparent text-xs font-semibold text-slate-900 outline-none"/></label>
            <label className="flex items-center gap-1.5 px-2.5 py-2"><Wrench size={14} className="shrink-0 text-slate-500"/>
              <input aria-label="Domaine" value={trade} onChange={e=>setTrade(e.target.value)} list="trade-list" placeholder="Domaine" className="w-full bg-transparent text-xs font-semibold text-slate-900 outline-none"/>
            </label>
          </div>
          <datalist id="city-list">{cities.map(c=><option key={c} value={c}/>)}</datalist>
          <datalist id="quartier-list">{quartierOptions.map(q=><option key={q} value={q}/>)}</datalist>
          <datalist id="trade-list">{trades.map(t=><option key={t.id} value={t.label}/>)}</datalist>
        </div>
        <div className="mt-1.5 flex gap-2 overflow-x-auto pb-0.5">
          <button onClick={()=>setTrade('')} className={`whitespace-nowrap rounded-full border px-3 py-1.5 text-sm font-semibold ${!trade?'border-[#3A8E9C] bg-[#3A8E9C] text-white':'border-[#D3CCBE] bg-[#F3EFE7] text-slate-500'}`}>Tous</button>
          {trades.map(t => <button key={t.id} onClick={()=>setTrade(normalize(trade)===normalize(t.label)?'':t.label)} className={`whitespace-nowrap rounded-full border px-3 py-1.5 text-sm font-semibold ${normalize(trade)===normalize(t.label)?'border-[#3A8E9C] bg-[#3A8E9C] text-white':'border-[#D3CCBE] bg-[#F3EFE7] text-slate-500'}`}>{t.label}</button>)}
        </div>
      </div>
      <div className="scroll-pane min-h-0 flex-1 overflow-y-auto px-5 py-4">
        {loading ? <div className="flex h-full items-center justify-center text-sm text-slate-500">Chargement…</div>
        : filtered.length ? <div className="grid grid-cols-1 gap-5 justify-items-center">{sorted.map(t => <TechnicianCard key={t.id} technician={t} onOpen={(tech)=>navigate(`/explorer/${tech.id}`)}/>)}</div>
        : <div className="flex h-full flex-col items-center justify-center gap-2 text-center text-slate-500"><Search size={26}/><h3 className="text-base font-semibold text-slate-900">Aucun technicien.</h3><p>Essayez un autre domaine ou quartier.</p>{(search||city||quartier||trade)&&<button className="reset-filters mt-2" onClick={()=>{setSearch('');setCity('');setQuartier('');setTrade('');}}><X size={14}/>Effacer les filtres</button>}</div>}
      </div>
    </div>
  );
}