import { useEffect, useState } from 'react';

// Returns the height (px) of the mobile virtual keyboard, computed from the
// VisualViewport API. 0 on desktop / unsupported browsers.
export default function useKeyboardOffset() {
  const [offset, setOffset] = useState(0);
  useEffect(() => {
    const vv = window.visualViewport;
    if (!vv) return;
    const onResize = () => {
      const kb = window.innerHeight - vv.height - vv.offsetTop;
      setOffset(kb > 0 ? kb : 0);
    };
    onResize();
    vv.addEventListener('resize', onResize);
    vv.addEventListener('scroll', onResize);
    return () => {
      vv.removeEventListener('resize', onResize);
      vv.removeEventListener('scroll', onResize);
    };
  }, []);
  return offset;
}