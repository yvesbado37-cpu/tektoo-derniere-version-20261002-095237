import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import { lazy, Suspense } from 'react';
import Layout from '@/components/Layout';
import AdminRoute from '@/components/AdminRoute';
import Home from '@/pages/Home';
import Domaines from '@/pages/Domaines';
import Explorer from '@/pages/Explorer';
import Inscription from '@/pages/Inscription';
const APropos = lazy(() => import('@/pages/APropos'));
const Connexion = lazy(() => import('@/pages/Connexion'));
const MonCompte = lazy(() => import('@/pages/MonCompte'));
const MotDePasseOublie = lazy(() => import('@/pages/MotDePasseOublie'));
const EntrezCode = lazy(() => import('@/pages/EntrezCode'));
const Recuperation = lazy(() => import('@/pages/Recuperation'));
const TechnicianDetail = lazy(() => import('@/pages/TechnicianDetail'));
const Forum = lazy(() => import('@/pages/Forum'));
const ForumTopic = lazy(() => import('@/pages/ForumTopic'));
const AdminPro = lazy(() => import('@/pages/AdminPro'));
const AdminUnlock = lazy(() => import('@/pages/AdminUnlock'));
const MoneyGest = lazy(() => import('@/pages/MoneyGest'));
const DevisPro = lazy(() => import('@/pages/DevisPro'));
const MaintPlan = lazy(() => import('@/pages/MaintPlan'));
const SolarSet = lazy(() => import('@/pages/SolarSet'));
const FrioPress = lazy(() => import('@/pages/FrioPress'));
const Formation = lazy(() => import('@/pages/Formation'));
const FormationSession = lazy(() => import('@/pages/FormationSession'));
const EspaceFormateur = lazy(() => import('@/pages/EspaceFormateur'));
// Add page imports here

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Suspense fallback={<div className="flex h-[100dvh] items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-4 border-[#D4D8DF] border-t-[#004EEB]" /></div>}>
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/domaines" element={<Domaines />} />
        <Route path="/explorer" element={<Explorer />} />
        <Route path="/explorer/:id" element={<TechnicianDetail />} />
        <Route path="/forum" element={<Forum />} />
        <Route path="/forum/:id" element={<ForumTopic />} />
        <Route path="/inscription" element={<Inscription />} />
        <Route path="/a-propos" element={<APropos />} />
        <Route path="/connexion" element={<Connexion />} />
        <Route path="/mot-de-passe-oublie" element={<MotDePasseOublie />} />
        <Route path="/entrez-code" element={<EntrezCode />} />
        <Route path="/recuperation/:token" element={<Recuperation />} />
        <Route path="/mon-compte" element={<MonCompte />} />
        <Route path="/moneygest" element={<MoneyGest />} />
        <Route path="/devispro" element={<DevisPro />} />
        <Route path="/maintplan" element={<MaintPlan />} />
        <Route path="/solarset" element={<SolarSet />} />
        <Route path="/friopress" element={<FrioPress />} />
        <Route path="/formation" element={<Formation />} />
        <Route path="/formation/:id" element={<FormationSession />} />
        <Route path="/espace-formateur" element={<EspaceFormateur />} />
        <Route path="/admin-unlock" element={<AdminUnlock />} />
        <Route element={<AdminRoute />}>
          <Route path="/admin-pro" element={<AdminPro />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
    </Suspense>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App