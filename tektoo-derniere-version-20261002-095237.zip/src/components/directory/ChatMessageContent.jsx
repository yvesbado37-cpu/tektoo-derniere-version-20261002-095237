import React from 'react';

export function isAudioMessage(message) {
  return message?.message_type === 'audio' && !!message?.audio_url;
}

export function getMessagePreview(message) {
  if (isAudioMessage(message)) return '🎤 Message vocal';
  return message?.content || '';
}

function formatDuration(durationMs) {
  const totalSeconds = Math.max(1, Math.round((durationMs || 0) / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

export default function ChatMessageContent({ message }) {
  if (isAudioMessage(message)) {
    return (
      <div className="grid gap-2">
        <span className="text-[11px] font-semibold uppercase tracking-[0.18em] opacity-75">Message vocal</span>
        <audio
          controls
          preload="metadata"
          src={message.audio_url}
          aria-label="Lecture du message vocal"
          className="h-10 w-full min-w-[220px] max-w-full"
        />
        {message.audio_duration_ms ? (
          <span className="text-[11px] opacity-75">{formatDuration(message.audio_duration_ms)}</span>
        ) : null}
      </div>
    );
  }

  return <>{message?.content}</>;
}
