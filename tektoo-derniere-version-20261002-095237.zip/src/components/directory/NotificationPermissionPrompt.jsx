import React, { useEffect, useState } from 'react';
import { Bell, X, Check } from 'lucide-react';
import { getSession } from '@/lib/technicianSession';
import { subscribeToPush } from '@/lib/pushNotifications';

const DISMISS_KEY = 'tektoo_notif_prompt_dismissed';

export default function NotificationPermissionPrompt() {
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const session = getSession();

  useEffect(() => {
    if (!session) return;
    if (!('Notification' in window) || Notification.permission !== 'default') return;
    if (localStorage.getItem(DISMISS_KEY) === '1') return;
    const t = setTimeout(() => setShow(true), 2000);
    return () => clearTimeout(t);
  }, [session]);

  const accept = async () => {
    setBusy(true);
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted' && session?.technicianId) {
        subscribeToPush(session.technicianId);
      }
    } catch {}
    setShow(false);
    setBusy(false);
  };

  const dismiss = () => {
    localStorage.setItem(DISMISS_KEY, '1');
    setShow(false);
  };

  if (!show) return null;

  return (
    <div className="fixed inset-x-0 bottom-[130px] z-50 flex justify-center px-4">
      <div className="glass flex w-full max-w-sm items-center gap-3 rounded-2xl border border-[#3A8E9C]/20 p-3 shadow-2xl">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#3A8E9C] text-white">
          <Bell size={18} />
        </span>
        <p className="min-w-0 flex-1 text-sm font-semibold leading-snug text-slate-900">Acceptez de recevoir des notifications de tektoo</p>
        <button onClick={accept} disabled={busy} aria-label="Accepter" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#3A8E9C] text-white transition-colors hover:bg-[#2E7B88] disabled:opacity-50">
          <Check size={18} />
        </button>
        <button onClick={dismiss} aria-label="Plus tard" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600">
          <X size={18} />
        </button>
      </div>
    </div>
  );
}