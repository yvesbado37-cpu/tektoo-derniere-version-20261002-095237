import React, { useState } from 'react';
import { Loader2, Upload, X, FileText, ExternalLink } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const MAX_SIZE = 10 * 1024 * 1024;

export default function PdfInput({ label, value, onChange }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const handle = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError('');
    if (file.type !== 'application/pdf') { setError('Veuillez choisir un fichier PDF.'); return; }
    if (file.size > MAX_SIZE) { setError('Fichier trop lourd (max 10 Mo).'); return; }
    setBusy(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      onChange(file_url);
    } catch {
      setError('Échec du téléversement.');
    } finally { setBusy(false); }
  };

  return (
    <label className="grid gap-1.5 text-xs font-semibold">
      {label}
      <div className="relative flex min-h-[80px] items-center justify-center overflow-hidden rounded-xl border border-dashed border-[#D3CCBE] bg-white shadow-sm">
        {value ? (
          <div className="flex w-full items-center gap-3 px-4 py-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#3A8E9C]/10 text-[#3A8E9C]"><FileText size={20} /></span>
            <span className="min-w-0 flex-1 text-sm font-normal text-slate-700">CV.pdf</span>
            <a href={value} target="_blank" rel="noreferrer" onClick={(e) => e.preventDefault()} className="flex h-8 w-8 items-center justify-center text-slate-500 hover:text-[#3A8E9C]"><ExternalLink size={16} /></a>
            <button type="button" onClick={(e) => { e.preventDefault(); onChange(''); }} className="flex h-8 w-8 items-center justify-center text-slate-500 hover:text-red-600"><X size={16} /></button>
          </div>
        ) : (
          <span className="flex flex-col items-center gap-1 px-3 text-center text-xs text-slate-500">
            {busy ? <Loader2 size={20} className="animate-spin" /> : <Upload size={20} />}
            {busy ? 'Téléversement…' : 'Téléverser un CV en PDF (10 Mo max)'}
          </span>
        )}
        <input type="file" accept="application/pdf" onChange={handle} className="absolute inset-0 cursor-pointer opacity-0" disabled={busy} />
      </div>
      {error && <span className="text-xs text-red-600">{error}</span>}
    </label>
  );
}