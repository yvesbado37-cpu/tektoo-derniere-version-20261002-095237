import React, { useEffect, useState } from 'react';
import { Eye, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getSession } from '@/lib/technicianSession';
import { playNotificationSound, triggerVibrate } from '@/lib/buttonSound';

export default function ProfileViewsBubble() {
  const [views, setViews] = useState(null);
  const [open, setOpen] = useState(false);
  const session = getSession();

  useEffect(() => {
    if (!session) return;
    let done = false;
    const prev = { current: null };
    const load = () => {
      base44.entities.ProfileView.filter({ technician_id: session.technicianId })
        .then(list => {
          if (done) return;
          const start = new Date(); start.setHours(0, 0, 0, 0);
          const todayViews = list.filter(v => new Date(v.created_date) >= start).length;
          if (prev.current !== null && todayViews > prev.current) {
            const diff = todayViews - prev.current;
            playNotificationSound();
            if ('Notification' in window && Notification.permission === 'granted') {
              try {
                const n = new Notification('Nouvelle visite de profil', {
                  body: `Votre profil a été consulté par ${diff} nouvelle${diff > 1 ? 's personne' : ' personne'}.`,
                  tag: 'tektoo_profile_view'
                });
                n.onclick = () => { window.focus(); n.close(); };
              } catch {}
            }
            if (navigator.vibrate) triggerVibrate(200);
          }
          prev.current = todayViews;
          setViews(todayViews);
        })
        .catch(() => { if (!done) setViews(0); });
    };
    load();
    const t = setInterval(load, 30000);
    return () => { done = true; clearInterval(t); };
  }, []);

  if (!session || views === null) return null;

  return (
    <div className="fixed right-4 top-[136px] z-30">
      <button
        onClick={() => setOpen(o => !o)}
        aria-label="Consultations de mon profil"
        className="flex h-11 items-center gap-2 rounded-full bg-[#3A8E9C] px-3 text-white shadow-lg transition-colors hover:bg-[#2E7B88]"
      >
        <Eye size={18} strokeWidth={2.2} />
        <span className="text-sm font-semibold">{views}</span>
      </button>

      {open && (
        <div className="glass absolute top-14 right-0 w-60 rounded-2xl p-3 shadow-xl">
          <div className="flex items-start justify-between gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#3A8E9C]/10 text-[#3A8E9C]"><Eye size={15} /></span>
            <button aria-label="Fermer" onClick={() => setOpen(false)} className="text-slate-500 hover:text-slate-900"><X size={15} /></button>
          </div>
          <p className="mt-2 text-sm leading-snug text-slate-900">
            Votre profil a été consulté par <span className="font-semibold text-[#3A8E9C]">{views}</span> {views > 1 ? 'personnes' : 'personne'} aujourd'hui.
          </p>
        </div>
      )}
    </div>
  );
}