import React, { useEffect, useRef, useState } from 'react';
import { Loader2, Video, X, Upload } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import TrimmedVideo from '@/components/directory/TrimmedVideo';

const MAX_SIZE = 50 * 1024 * 1024;

const readDuration = (url) => new Promise((resolve, reject) => {
  const v = document.createElement('video');
  v.preload = 'metadata';
  v.muted = true;
  v.onloadedmetadata = () => {
    if (!isFinite(v.duration) || isNaN(v.duration) || v.duration <= 0) {
      v.currentTime = 1e101;
      const onTime = () => {
        v.ontimeupdate = null;
        const d = v.duration;
        if (isFinite(d) && d > 0) resolve(d); else reject(new Error('read'));
      };
      v.ontimeupdate = onTime;
      return;
    }
    resolve(v.duration);
  };
  v.onerror = () => reject(new Error('read'));
  v.src = url;
});

export default function VideoInput({ label, value, onChange, maxDuration = 30 }) {
  const MAX_DURATION = maxDuration;
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [trim, setTrim] = useState(null); // { url, file, duration, start, end }
  const videoRef = useRef(null);
  const trimUrlRef = useRef(null);

  useEffect(() => () => {
    if (trimUrlRef.current) URL.revokeObjectURL(trimUrlRef.current);
  }, []);

  const handle = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError('');
    if (!file.type.startsWith('video/')) { setError('Veuillez choisir un fichier vidéo.'); return; }
    if (file.size > MAX_SIZE) { setError('Vidéo trop lourde (max 50 Mo).'); return; }
    const url = URL.createObjectURL(file);
    if (trimUrlRef.current) { URL.revokeObjectURL(trimUrlRef.current); }
    trimUrlRef.current = url;
    try {
      const duration = await readDuration(url);
      if (duration <= MAX_DURATION) {
        setBusy(true);
        try {
          const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
          onChange(file_url);
        } catch {
          setError('Échec du téléversement.');
        } finally {
          setBusy(false);
        }
        if (trimUrlRef.current) { URL.revokeObjectURL(trimUrlRef.current); trimUrlRef.current = null; }
        return;
      }
      setTrim({ url, file, duration, start: 0, end: Math.min(MAX_DURATION, duration) });
    } catch {
      if (trimUrlRef.current) { URL.revokeObjectURL(trimUrlRef.current); trimUrlRef.current = null; }
      setError('Impossible de lire cette vidéo.');
    }
  };

  const seekToStart = () => {
    const v = videoRef.current;
    if (!v || !trim) return;
    v.currentTime = trim.start;
  };

  const setStart = (val) => {
    let s = Math.max(0, Math.min(val, trim.duration - 0.1));
    let e = trim.end;
    if (e - s > MAX_DURATION) e = Math.min(trim.duration, s + MAX_DURATION);
    if (e - s < 0.1) e = s + 0.1;
    setTrim({ ...trim, start: s, end: e });
  };
  const setEnd = (val) => {
    let e = Math.min(trim.duration, Math.max(val, 0.1));
    let s = trim.start;
    if (e - s > MAX_DURATION) s = Math.max(0, e - MAX_DURATION);
    if (e - s < 0.1) s = Math.max(0, e - 0.1);
    setTrim({ ...trim, start: s, end: e });
  };

  const uploadTrimmed = async () => {
    if (!trim?.file) return;
    setBusy(true); setError('');
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file: trim.file });
      const trimmedUrl = `${file_url}#t=${trim.start},${trim.end}`;
      onChange(trimmedUrl);
      if (trimUrlRef.current) { URL.revokeObjectURL(trimUrlRef.current); trimUrlRef.current = null; }
      setTrim(null);
    } catch {
      setError('Échec du téléversement.');
    } finally {
      setBusy(false);
    }
  };

  const fmt = (s) => `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')}`;

  return (
    <label className="grid gap-1.5 text-xs font-semibold">
      {label}
      <div className="relative flex min-h-[130px] items-center justify-center overflow-hidden border border-dashed border-[#D3CCBE] bg-[#E9E3D7]">
        {value ? (
          <>
            <TrimmedVideo src={value} className="absolute inset-0 h-full w-full object-contain bg-black" />
            <button type="button" onClick={(e) => { e.preventDefault(); onChange(''); }} className="absolute right-2 top-2 z-10 bg-white/90 p-1"><X size={14}/></button>
          </>
        ) : trim ? (
          <span className="flex flex-col items-center gap-1 px-3 text-center text-xs text-slate-500">
            {busy ? <Loader2 size={20} className="animate-spin"/> : <Video size={20}/>}
            {busy ? 'Téléversement…' : 'Ajustez l’extrait ci-dessous'}
          </span>
        ) : (
          <span className="flex flex-col items-center gap-1 px-3 text-center text-xs text-slate-500">
            {busy ? <Loader2 size={20} className="animate-spin"/> : <Video size={20}/>}
            {busy ? 'Chargement…' : `Vidéo (${MAX_DURATION}s max)`}
          </span>
        )}
        {!value && !trim && (
          <input type="file" accept="video/*" onChange={handle} className="absolute inset-0 cursor-pointer opacity-0" disabled={busy}/>
        )}
      </div>

      {trim && !value && (
        <div className="grid gap-2 border border-[#D3CCBE] bg-white p-3">
          <video ref={videoRef} src={trim.url} playsInline muted controls className="h-auto w-full border border-[#D3CCBE] bg-black"/>
          <div className="text-xs text-slate-500">Vidéo de {fmt(trim.duration)} — sélectionnez un extrait de {MAX_DURATION}s max.</div>
          <div className="relative h-10 w-full">
            <div className="absolute top-1/2 h-1.5 w-full -translate-y-1/2 rounded-full bg-[#E9E3D7]"/>
            <div className="absolute top-1/2 h-1.5 -translate-y-1/2 rounded-full bg-[#3A8E9C]/70" style={{ left: `${(trim.start/trim.duration)*100}%`, width: `${((trim.end-trim.start)/trim.duration)*100}%` }}/>
            <input type="range" min={0} max={trim.duration} step={0.1} value={trim.start} onChange={(e)=>setStart(Number(e.target.value))} className="trim-range" aria-label="Début"/>
            <input type="range" min={0} max={trim.duration} step={0.1} value={trim.end} onChange={(e)=>setEnd(Number(e.target.value))} className="trim-range" aria-label="Fin"/>
          </div>
          <div className="flex items-center justify-between text-xs font-semibold">
            <span>Début {fmt(trim.start)}</span>
            <span className="text-[#3A8E9C]">Extrait : {fmt(trim.end - trim.start)}</span>
            <span>Fin {fmt(trim.end)}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={seekToStart} className="flex items-center gap-2 rounded-full border border-[#D3CCBE] px-3 py-2 text-xs font-semibold">Aller au début</button>
            <button type="button" onClick={uploadTrimmed} disabled={busy} className="flex items-center gap-2 rounded-full bg-[#3A8E9C] px-3 py-2 text-xs font-semibold text-white disabled:opacity-50"><Upload size={14}/>Téléverser l’extrait</button>
            <button type="button" onClick={() => { if (trimUrlRef.current) { URL.revokeObjectURL(trimUrlRef.current); trimUrlRef.current = null; } setTrim(null); setError(''); }} className="flex items-center gap-2 rounded-full border border-[#D3CCBE] px-3 py-2 text-xs font-semibold">Annuler</button>
          </div>
        </div>
      )}
      {error && <span className="text-xs text-red-600">{error}</span>}
    </label>
  );
}