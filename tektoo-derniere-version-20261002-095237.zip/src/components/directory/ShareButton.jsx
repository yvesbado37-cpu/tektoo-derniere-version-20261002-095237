import React, { useState } from 'react';
import { Share2, Facebook, Twitter, Instagram, MessageCircle, Link2, X } from 'lucide-react';

const SITE_URL = 'https://www.tektoo.org';
const SITE_TEXT = 'tektoo — la solution à tout. L\'annuaire des techniciens près de chez vous.';

export default function ShareButton() {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const share = (url) => { window.open(url, '_blank', 'noopener,noreferrer'); };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(SITE_URL);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* ignore */ }
  };

  const nativeShare = async () => {
    if (navigator.share) {
      try { await navigator.share({ title: 'tektoo', text: SITE_TEXT, url: SITE_URL }); } catch { /* cancelled */ }
    } else { setOpen(true); }
  };

  const options = [
    { label: 'Facebook', icon: Facebook, color: '#1877F2', url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(SITE_URL)}` },
    { label: 'Twitter / X', icon: Twitter, color: '#3A8E9C', url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(SITE_TEXT)}&url=${encodeURIComponent(SITE_URL)}` },
    { label: 'WhatsApp', icon: MessageCircle, color: '#10B981', url: `https://wa.me/?text=${encodeURIComponent(SITE_TEXT + ' ' + SITE_URL)}` },
    { label: 'Instagram', icon: Instagram, color: '#E4405F', url: `https://www.instagram.com/` },
  ];

  return (
    <>
      <button
        onClick={nativeShare}
        aria-label="Partager"
        className="fixed right-4 top-[84px] z-30 flex h-11 w-11 items-center justify-center rounded-full bg-[#3A8E9C] text-white shadow-lg transition-colors hover:bg-[#2E7B88]"
      >
        <Share2 size={18} strokeWidth={2.2} />
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 sm:items-center" onClick={() => setOpen(false)}>
          <div className="glass w-full max-w-sm rounded-t-2xl p-5 sm:rounded-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-[#D3CCBE] pb-3">
              <h3 className="text-base font-semibold text-slate-900">Partager tektoo</h3>
              <button aria-label="Fermer" onClick={() => setOpen(false)} className="flex h-9 w-9 items-center justify-center text-slate-500 hover:text-slate-900"><X size={18} /></button>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3">
              {options.map(o => (
                <button key={o.label} onClick={() => share(o.url)} className="glass glass-hover flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-slate-700">
                  <o.icon size={18} style={{ color: o.color }} strokeWidth={2} />
                  <span>{o.label}</span>
                </button>
              ))}
            </div>
            <button onClick={copyLink} className="glass glass-hover mt-3 flex w-full items-center justify-center gap-2 rounded-xl px-3 py-3 text-sm font-semibold text-slate-700">
              <Link2 size={16} />
              {copied ? 'Lien copié !' : 'Copier le lien'}
            </button>
          </div>
        </div>
      )}
    </>
  );
}