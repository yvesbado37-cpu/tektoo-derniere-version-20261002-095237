import React, { useEffect, useRef, useState } from 'react';
import { Loader2, ArrowLeft, MessageSquare, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getSession } from '@/lib/technicianSession';
import { addDeletedConvId } from '@/lib/deletedConversations';
import ChatComposer from '@/components/directory/ChatComposer';
import ChatMessageContent, { getMessagePreview } from '@/components/directory/ChatMessageContent';

export default function TechnicianInbox() {
  const [conversations, setConversations] = useState([]);
  const [activeConv, setActiveConv] = useState(null);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef(null);
  const session = getSession();

  useEffect(() => {
    if (!session) return;
    let done = false;
    base44.entities.ChatMessage.filter({ technician_id: session.technicianId }, 'created_date', 500)
      .then(list => {
        if (done) return;
        const groups = {};
        list.forEach(m => {
          if (!groups[m.conversation_id]) groups[m.conversation_id] = [];
          groups[m.conversation_id].push(m);
        });
        const convs = Object.entries(groups).map(([id, msgs]) => ({
          id,
          client_technician_id: msgs[0]?.client_technician_id,
          name: msgs[0]?.sender_name || 'Client',
          phone: msgs[0]?.sender_phone || '',
          lastMsg: msgs[msgs.length - 1],
          messages: msgs.sort((a, b) => new Date(a.created_date) - new Date(b.created_date))
        })).sort((a, b) => new Date(b.lastMsg.created_date) - new Date(a.lastMsg.created_date));
        setConversations(convs);
        setLoading(false);
      })
      .catch(() => { if (!done) setLoading(false); });
    let unsub = () => {};
    try {
      unsub = base44.entities.ChatMessage.subscribe((event) => {
        const m = event.data;
        if (!m || m.technician_id !== session.technicianId) return;
        setConversations(prev => {
          const existing = prev.find(c => c.id === m.conversation_id);
          if (existing) {
            const updated = { ...existing, messages: [...existing.messages, m], lastMsg: m };
            return [updated, ...prev.filter(c => c.id !== m.conversation_id)].sort((a, b) => new Date(b.lastMsg.created_date) - new Date(a.lastMsg.created_date));
          }
          return [{
            id: m.conversation_id,
            client_technician_id: m.client_technician_id,
            name: m.sender_name || 'Client',
            phone: m.sender_phone || '',
            lastMsg: m,
            messages: [m]
          }, ...prev].sort((a, b) => new Date(b.lastMsg.created_date) - new Date(a.lastMsg.created_date));
        });
        if (!m.from_technician && activeConv?.id !== m.conversation_id) {
          if ('Notification' in window && Notification.permission === 'granted') {
            try {
              const n = new Notification(`Nouveau message de ${m.sender_name || 'un client'}`, { body: getMessagePreview(m), tag: `tektoo_inbox_${m.conversation_id}` });
              n.onclick = () => { window.focus(); n.close(); };
            } catch {}
          }
          if (navigator.vibrate) navigator.vibrate(200);
        }
      });
    } catch (e) {
      console.warn('Inbox subscribe unavailable, using polling', e);
    }
    const poll = setInterval(() => {
      base44.entities.ChatMessage.filter({ technician_id: session.technicianId }, 'created_date', 500)
        .then(list => {
          const groups = {};
          list.forEach(m => {
            if (!groups[m.conversation_id]) groups[m.conversation_id] = [];
            groups[m.conversation_id].push(m);
          });
          const convs = Object.entries(groups).map(([id, msgs]) => ({
            id,
            client_technician_id: msgs[0]?.client_technician_id,
            name: msgs[0]?.sender_name || 'Client',
            phone: msgs[0]?.sender_phone || '',
            lastMsg: msgs[msgs.length - 1],
            messages: msgs.sort((a, b) => new Date(a.created_date) - new Date(b.created_date))
          })).sort((a, b) => new Date(b.lastMsg.created_date) - new Date(a.lastMsg.created_date));
          setConversations(convs);
        })
        .catch(() => {});
    }, 10000);
    return () => { done = true; try { unsub(); } catch {} clearInterval(poll); };
  }, [session]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [activeConv?.messages]);

  const deleteConversation = async (convId) => {
    addDeletedConvId(convId);
    setConversations(prev => prev.filter(c => c.id !== convId));
    if (activeConv?.id === convId) setActiveConv(null);
    try {
      await base44.functions.invoke('deleteConversation', {
        conversation_id: convId,
        deleted_by: session.technicianId
      });
    } catch (e) {
      console.error('deleteConversation error', e);
    }
  };

  const persistMessage = async (payload) => {
    if (busy || !activeConv) return;
    setDraft('');
    setBusy(true);
    try {
      const msg = await base44.entities.ChatMessage.create({
        technician_id: session.technicianId,
        conversation_id: activeConv.id,
        client_technician_id: activeConv.client_technician_id,
        sender_name: '',
        sender_phone: '',
        from_technician: true,
        ...payload
      });
      setConversations(prev => prev.map(c =>
        c.id === activeConv.id
          ? { ...c, messages: [...c.messages, msg], lastMsg: msg }
          : c
      ));
      return true;
    } catch {
      if (payload.message_type !== 'audio') setDraft(payload.content || '');
      return false;
    } finally {
      setBusy(false);
    }
  };

  const sendText = async (content) => {
    if (!content.trim()) return;
    return persistMessage({
      content,
      message_type: 'text',
    });
  };

  const sendAudio = async ({ audioUrl, durationMs, mimeType }) => {
    return persistMessage({
      content: '🎤 Message vocal',
      message_type: 'audio',
      audio_url: audioUrl,
      audio_duration_ms: durationMs,
      audio_mime_type: mimeType,
    });
  };

  if (loading) {
    return <div className="flex items-center gap-2 text-sm text-[#675F54]"><Loader2 size={18} className="animate-spin" />Chargement des messages…</div>;
  }

  if (conversations.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 border border-[#C4BCB0] bg-[#F3EFE7] px-4 py-8 text-center">
        <MessageSquare size={28} className="text-[#C4BCB0]" />
        <p className="text-sm text-[#675F54]">Aucun message pour le moment. Les clients pourront vous écrire directement depuis votre profil.</p>
      </div>
    );
  }

  if (activeConv) {
    return (
      <div className="border border-[#C4BCB0] bg-[#F3EFE7]">
        <div className="flex items-center gap-3 border-b border-[#C4BCB0] px-4 py-3">
          <button onClick={() => setActiveConv(null)} className="flex h-9 w-9 items-center justify-center text-[#675F54]" aria-label="Retour"><ArrowLeft size={20} /></button>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold">{activeConv.name}</div>
            {activeConv.phone && <div className="text-xs text-[#675F54]">{activeConv.phone}</div>}
          </div>
          <button onClick={() => deleteConversation(activeConv.id)} className="flex h-9 w-9 items-center justify-center text-red-500 hover:bg-red-500/10" aria-label="Supprimer la conversation" title="Supprimer la conversation"><Trash2 size={18} /></button>
        </div>
        <div ref={scrollRef} className="scroll-pane max-h-80 min-h-48 overflow-y-auto p-4 grid gap-2 content-start">
          {activeConv.messages.map(m => (
            <div key={m.id} className={`flex ${m.from_technician ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[78%] px-3 py-2 text-sm leading-snug ${m.from_technician ? 'bg-[#3A8E9C] text-white' : 'bg-[#D3CCBE] text-[#2E2A24]'}`}>
                <ChatMessageContent message={m} />
              </div>
            </div>
          ))}
        </div>
        <ChatComposer
          draft={draft}
          onDraftChange={setDraft}
          onSendText={sendText}
          onSendAudio={sendAudio}
          busy={busy}
          placeholder="Votre réponse…"
        />
      </div>
    );
  }

  return (
    <div className="grid gap-2">
      {conversations.map(c => (
        <div key={c.id} className="flex items-center gap-3 border border-[#C4BCB0] bg-[#F3EFE7] px-4 py-3 transition-colors hover:bg-[#D3CCBE]">
          <button onClick={() => setActiveConv(c)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#3A8E9C]/10 text-[#3A8E9C]"><MessageSquare size={18} /></span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-semibold">{c.name}</span>
              <span className="block truncate text-xs text-[#675F54]">{c.lastMsg?.from_technician ? 'Vous : ' : ''}{getMessagePreview(c.lastMsg)}</span>
            </span>
            {c.phone && <span className="shrink-0 text-xs text-[#675F54]">{c.phone}</span>}
          </button>
          <button onClick={() => deleteConversation(c.id)} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-red-500 hover:bg-red-500 hover:text-white" aria-label="Supprimer la conversation" title="Supprimer la conversation"><Trash2 size={17} /></button>
        </div>
      ))}
    </div>
  );
}