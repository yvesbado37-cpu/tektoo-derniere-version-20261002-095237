import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { MessageSquare, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getSession } from '@/lib/technicianSession';
import { getDeletedConvIds } from '@/lib/deletedConversations';
import { playNotificationSound, triggerVibrate } from '@/lib/buttonSound';
import { getMessagePreview } from '@/components/directory/ChatMessageContent';

export default function NotificationToast() {
  const [toasts, setToasts] = useState([]);
  const session = getSession();
  const techIdRef = useRef(session?.technicianId);
  techIdRef.current = session?.technicianId;
  const knownIds = useRef(new Set());
  const timers = useRef({});

  const dismiss = (id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
    if (timers.current[id]) { clearTimeout(timers.current[id]); delete timers.current[id]; }
  };

  const showToast = (msg, senderName, convId) => {
    const toastId = `${msg.id}_${Date.now()}`;
    setToasts(prev => [...prev.slice(-2), { id: toastId, content: getMessagePreview(msg), senderName, convId }]);
    timers.current[toastId] = setTimeout(() => dismiss(toastId), 6000);
  };

  useEffect(() => {
    if (!techIdRef.current) return;
    // Seed known IDs to avoid showing toasts for already-seen messages
    const seed = async () => {
      try {
        const [incoming, outgoing] = await Promise.all([
          base44.entities.ChatMessage.filter({ technician_id: techIdRef.current }, '-created_date', 50).catch(() => []),
          base44.entities.ChatMessage.filter({ client_technician_id: techIdRef.current }, '-created_date', 50).catch(() => [])
        ]);
        [...incoming, ...outgoing].forEach(m => knownIds.current.add(m.id));
      } catch {}
    };
    seed();

    let unsub = () => {};
    try {
      unsub = base44.entities.ChatMessage.subscribe((event) => {
        const m = event.data;
        if (!m || knownIds.current.has(m.id)) return;
        knownIds.current.add(m.id);
        const techId = techIdRef.current;
        if (!techId) return;
        const isTech = m.technician_id === techId;
        const isClient = m.client_technician_id === techId;
        if (!isTech && !isClient) return;
        if (getDeletedConvIds().has(m.conversation_id)) return;
        const fromOther = isTech ? !m.from_technician : m.from_technician;
        if (!fromOther) return;

        playNotificationSound();
        if (navigator.vibrate) triggerVibrate([200, 100, 200]);

        const otherId = isTech ? m.client_technician_id : m.technician_id;
        base44.entities.Technician.get(otherId)
          .then(t => showToast(m, t?.name || t?.nom || 'Nouveau message', m.conversation_id))
          .catch(() => showToast(m, 'Nouveau message', m.conversation_id));

        if ('Notification' in window && Notification.permission === 'granted') {
          try {
            const n = new Notification('Nouveau message tektoo', { body: getMessagePreview(m), tag: `tektoo_toast_${m.conversation_id}` });
            n.onclick = () => { window.focus(); n.close(); };
          } catch {}
        }
      });
    } catch {}

    const poll = setInterval(async () => {
      const techId = techIdRef.current;
      if (!techId) return;
      try {
        const [incoming, outgoing] = await Promise.all([
          base44.entities.ChatMessage.filter({ technician_id: techId }, '-created_date', 10).catch(() => []),
          base44.entities.ChatMessage.filter({ client_technician_id: techId }, '-created_date', 10).catch(() => [])
        ]);
        const all = [...incoming, ...outgoing];
        const deleted = getDeletedConvIds();
        for (const m of all) {
          if (knownIds.current.has(m.id)) continue;
          knownIds.current.add(m.id);
          if (deleted.has(m.conversation_id)) continue;
          const isTech = m.technician_id === techId;
          const isClient = m.client_technician_id === techId;
          if (!isTech && !isClient) continue;
          const fromOther = isTech ? !m.from_technician : m.from_technician;
          if (!fromOther) continue;
          playNotificationSound();
          if (navigator.vibrate) triggerVibrate([200, 100, 200]);
          const otherId = isTech ? m.client_technician_id : m.technician_id;
          base44.entities.Technician.get(otherId)
            .then(t => showToast(m, t?.name || t?.nom || 'Nouveau message', m.conversation_id))
            .catch(() => showToast(m, 'Nouveau message', m.conversation_id));
        }
      } catch {}
    }, 3000);

    return () => { try { unsub(); } catch {} clearInterval(poll); Object.values(timers.current).forEach(clearTimeout); };
  }, []);

  return (
    <div className="pointer-events-none fixed inset-x-0 top-[72px] z-[60] flex flex-col items-center gap-2 px-4">
      <AnimatePresence>
        {toasts.map(t => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: -30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ duration: 0.3, ease: [0.34, 1.56, 0.64, 1] }}
            className="pointer-events-auto flex w-full max-w-sm items-center gap-3 rounded-2xl border border-[#3A8E9C]/30 bg-[#F3EFE7] p-3 shadow-2xl"
          >
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#3A8E9C] text-white">
              <MessageSquare size={18} />
            </span>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-bold text-[#3A8E9C]">{t.senderName}</div>
              <div className="truncate text-xs text-slate-600">{t.content}</div>
            </div>
            <button onClick={() => dismiss(t.id)} className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-slate-400 hover:bg-slate-100 hover:text-slate-600" aria-label="Fermer">
              <X size={15} />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}