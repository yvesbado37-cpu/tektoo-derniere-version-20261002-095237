import React, { useEffect, useState } from 'react';
import { Phone, MessageCircle, MapPin, Check, ArrowUpRight, FileText, Video } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { trades, tradeLabel } from '@/components/directory/catalog';
import Reviews from '@/components/directory/Reviews';
import ReportProfile from '@/components/directory/ReportProfile';
import ZoomableImage from '@/components/directory/ZoomableImage';
import ProfileMediaViewer from '@/components/directory/ProfileMediaViewer';
import { getProfileMedia } from '@/components/directory/profileMedia';
export default function ProfileDialog({ technician: t, onClose, onJoin }) {
 const trade=trades.find(x=>x.id===t?.trade); const phone=t?.phone?.replace(/[^\d+]/g,'');
 const [agreed,setAgreed]=useState(false);
 const [viewerOpen, setViewerOpen] = useState(false);
 const [viewerIndex, setViewerIndex] = useState(0);
 const media = getProfileMedia(t);
 const imageMedia = media.filter((item) => item.type === 'image');
 const videoMedia = media.filter((item) => item.type === 'video');
 useEffect(()=>{setAgreed(false);},[t?.id]);
 useEffect(() => { setViewerOpen(false); setViewerIndex(0); }, [t?.id]);
 const openViewerAt = (src) => {
   const nextIndex = media.findIndex((item) => item.src === src);
   setViewerIndex(nextIndex >= 0 ? nextIndex : 0);
   setViewerOpen(true);
 };
 return <Dialog open={!!t} onOpenChange={open=>!open&&onClose()}><DialogContent className="profile-dialog">{t&&<>
 <div className="eyebrow text-[#3A8E9C]">{tradeLabel(t)} / {t.demo ? 'PROFIL DE DÉMONSTRATION' : 'PROFIL DÉCLARÉ'}</div><DialogTitle className="text-3xl tracking-tight">{t.name}</DialogTitle><DialogDescription className="flex items-center gap-2"><MapPin size={16}/>{t.city}{t.quartier ? ` · ${t.quartier}` : ''} · {t.experience || 0} ans d’expérience{t.age ? ` · ${t.age} ans` : ''}</DialogDescription>
 <div className="profile-status"><span className="status-dot"/>{t.available ? 'Se déclare disponible pour de nouvelles demandes' : 'Interventions sur rendez-vous'}</div>
 <section><h3 className="profile-heading">Le savoir-faire</h3><p className="text-slate-500 leading-relaxed">{t.description}</p></section>
 {t.demo&&<section><h3 className="profile-heading">Exemples de prestations</h3><div className="profile-services">{trade?.services.map(s=><span key={s}><Check size={15}/>{s}</span>)}</div></section>}
 {media.length > 0 && <section><button type="button" onClick={() => { setViewerIndex(0); setViewerOpen(true); }} className="flex items-center gap-2 rounded-full border border-[#3A8E9C] px-4 py-2 text-sm font-semibold text-[#3A8E9C] transition-colors hover:bg-[#3A8E9C] hover:text-white">Voir les médias <Video size={16} /></button></section>}
 {imageMedia.length > 0 && <section><h3 className="profile-heading">En images</h3><div className="grid grid-cols-2 gap-2">{imageMedia.map((item,i)=><ZoomableImage key={item.id} src={item.src} alt={`${item.label} — ${t.name}`} className="h-40 w-full border border-[#D3CCBE] object-cover" wrapperClassName="overflow-hidden rounded-lg" onOpen={() => openViewerAt(item.src)} icon={i < 4} />)}</div></section>}
 {videoMedia.length > 0 && <section><h3 className="profile-heading">Vidéos</h3><div className="grid gap-2">{videoMedia.map((item, i) => <button key={item.id} type="button" onClick={() => openViewerAt(item.src)} className="flex items-center justify-center gap-2 rounded-full border border-[#3A8E9C] px-4 py-2 text-sm font-semibold text-[#3A8E9C] transition-colors hover:bg-[#3A8E9C] hover:text-white"><Video size={16}/>Voir la vidéo {i + 1}</button>)}</div></section>}
 {t.cv_url&&<section><h3 className="profile-heading">CV</h3><a href={t.cv_url} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-full border border-[#D3CCBE] bg-[#E9E3D7] px-4 py-3 text-sm font-semibold text-[#3A8E9C] transition-colors hover:bg-[#D3CCBE]"><FileText size={17}/>Voir le CV (PDF)</a></section>}
 <Reviews technicianId={t.id}/>
 <div className="contact-panel"><h3 className="profile-heading">Contacter le pro en cochant l’agrément.</h3><p>Validez l’agrément ci-dessous pour afficher les coordonnées du professionnel.</p>{t.demo ? <div className="demo-contact">Ce profil est fictif et ne peut pas être contacté. Les coordonnées des vrais techniciens apparaîtront ici.<button className="primary-button mt-4" onClick={()=>{onClose();onJoin();}}>Inscrire mon activité <ArrowUpRight size={16}/></button></div> : <><label className="flex flex-row items-start gap-2 leading-relaxed mt-4"><input type="checkbox" checked={agreed} onChange={e=>setAgreed(e.target.checked)} className="mt-0.5 h-4 w-4 flex-shrink-0"/><span className="text-xs text-slate-500">J’accepte que tektoo est un annuaire de mise en relation et décline toute responsabilité quant aux prestations, tarifs et comportements des techniciens. L’entière responsabilité des services fournis incombe au professionnel et à moi-même.</span></label>{agreed&&<div className="contact-actions"><a className="whatsapp-button" target="_blank" rel="noreferrer" href={`https://wa.me/${phone.replace(/\D/g,'')}?text=${encodeURIComponent(`Bonjour ${t.name}, je vous ai trouvé sur tektoo. J’aimerais vous contacter pour une intervention.`)}`}><MessageCircle size={17}/>Discuter sur WhatsApp</a><a className="primary-button" href={`tel:${phone}`}><Phone size={17}/>Appeler</a></div>}{agreed&&<span className="block mt-3 text-sm">{t.phone}</span>}</>}</div>
 {!t.demo && <ReportProfile technicianId={t.id}/>}
 <p className="text-xs text-slate-500">Informations déclarées, non vérifiées par tektoo. Disponibilité à confirmer directement auprès du professionnel.</p>
 <ProfileMediaViewer open={viewerOpen} onOpenChange={setViewerOpen} media={media} initialIndex={viewerIndex} profileName={t.name} />
 </>}</DialogContent></Dialog>;
}