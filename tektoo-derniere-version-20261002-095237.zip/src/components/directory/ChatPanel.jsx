import React, { useEffect, useRef, useState } from 'react';
import { Loader2, MessageSquare, X, Trash2, RefreshCw, Eraser } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import useKeyboardOffset from '@/hooks/useKeyboardOffset';
import { getSession } from '@/lib/technicianSession';
import { isConvDeleted, addDeletedConvId, removeDeletedConvId } from '@/lib/deletedConversations';
import { Link } from 'react-router-dom';
import { LogIn } from 'lucide-react';
import { notifyOfflineRecipient } from '@/lib/whatsappNotify';
import { playNotificationSound, triggerVibrate } from '@/lib/buttonSound';
import ChatComposer from '@/components/directory/ChatComposer';
import ChatMessageContent, { getMessagePreview } from '@/components/directory/ChatMessageContent';

export default function ChatPanel({ technicianId, technicianName }) {
  const [open, setOpen] = useState(false);
  const [session, setSessionState] = useState(getSession());
  const [identity, setIdentity] = useState(null);
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(false);
  const [unread, setUnread] = useState(0);
  const [error, setError] = useState('');
  const [techPhoto, setTechPhoto] = useState(null);
  const [myPhoto, setMyPhoto] = useState(null);
  const scrollRef = useRef(null);
  const openRef = useRef(false);
  openRef.current = open;
  const refreshRef = useRef(() => {});
  const kb = useKeyboardOffset();

  useEffect(() => {
    const sync = () => setSessionState(getSession());
    window.addEventListener('tektoo-session', sync);
    window.addEventListener('storage', sync);
    return () => { window.removeEventListener('tektoo-session', sync); window.removeEventListener('storage', sync); };
  }, []);

  useEffect(() => {
    if (!session?.technicianId) { setIdentity(null); return; }
    const convId = [session.technicianId, technicianId].sort().join('__');
    setIdentity({ conversation_id: convId, deleted: isConvDeleted(convId) });
  }, [technicianId, session]);

  useEffect(() => {
    const sync = () => {
      if (!identity) return;
      setIdentity(prev => prev ? { ...prev, deleted: isConvDeleted(prev.conversation_id) } : prev);
    };
    window.addEventListener('tektoo-deleted-conv', sync);
    window.addEventListener('storage', sync);
    return () => { window.removeEventListener('tektoo-deleted-conv', sync); window.removeEventListener('storage', sync); };
  }, [identity]);

  useEffect(() => {
    if (!identity) return;
    const convId = identity.conversation_id;
    if (identity.deleted) { setMessages([]); setLoading(false); return; }
    let cancelled = false;
    let retryCount = 0;
    const fetchMessages = () => {
      if (cancelled || isConvDeleted(convId)) return;
      base44.entities.ChatMessage.filter({ conversation_id: convId }, '-created_date', 200)
        .then(list => {
          if (cancelled) return;
          setMessages(list.reverse());
          setLoading(false);
          // Opera Mini may return a cached empty response on first load;
          // retry a few times so messages from other browsers appear.
          if (list.length === 0 && retryCount < 4) {
            retryCount++;
            setTimeout(fetchMessages, 1500 * retryCount);
          }
        })
        .catch(() => { if (!cancelled) setLoading(false); });
    };
    setLoading(true);
    fetchMessages();
    refreshRef.current = fetchMessages;
    let unsub = () => {};
    try {
      unsub = base44.entities.ChatMessage.subscribe((event) => {
        const m = event.data;
        if (!m || m.conversation_id !== convId) return;
        if (isConvDeleted(convId)) return;
        setMessages(prev => prev.some(x => x.id === m.id) ? prev : [...prev, m]);
        if (m.from_technician && !openRef.current) {
          setUnread(u => u + 1);
          notify(m);
        }
      });
    } catch (e) {
      console.warn('Chat subscribe unavailable, using polling', e);
    }
    const poll = setInterval(() => {
      if (isConvDeleted(convId)) { setMessages([]); return; }
      base44.entities.ChatMessage.filter({ conversation_id: convId }, '-created_date', 200)
        .then(list => setMessages(list.reverse()))
        .catch(() => {});
    }, 2000);
    const refetch = () => {
      if (isConvDeleted(convId)) { setMessages([]); return; }
      base44.entities.ChatMessage.filter({ conversation_id: convId }, '-created_date', 200)
        .then(list => setMessages(list.reverse()))
        .catch(() => {});
    };
    document.addEventListener('visibilitychange', refetch);
    window.addEventListener('focus', refetch);
    return () => { cancelled = true; try { unsub(); } catch {} clearInterval(poll); document.removeEventListener('visibilitychange', refetch); window.removeEventListener('focus', refetch); };
  }, [identity]);

  useEffect(() => {
    if (open) setUnread(0);
  }, [open]);

  useEffect(() => {
    base44.entities.Technician.get(technicianId).then(t => setTechPhoto(t?.profile_photo || null)).catch(() => {});
  }, [technicianId]);

  useEffect(() => {
    if (!session?.technicianId) { setMyPhoto(null); return; }
    base44.entities.Technician.get(session.technicianId).then(t => setMyPhoto(t?.profile_photo || null)).catch(() => {});
  }, [session?.technicianId]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, open]);

  const notify = (m) => {
    playNotificationSound();
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        const n = new Notification(`${technicianName} vous a répondu`, { body: getMessagePreview(m), tag: `tektoo_chat_${technicianId}` });
        n.onclick = () => { window.focus(); n.close(); setOpen(true); };
      } catch {}
    }
    if (navigator.vibrate) triggerVibrate(200);
  };

  const clearForMe = () => {
    if (!identity) return;
    addDeletedConvId(identity.conversation_id);
    setMessages([]);
    setOpen(false);
    setUnread(0);
  };

  const deleteConversation = async () => {
    if (!identity) return;
    addDeletedConvId(identity.conversation_id);
    setMessages([]);
    setOpen(false);
    setUnread(0);
    try {
      await base44.functions.invoke('deleteConversation', {
        conversation_id: identity.conversation_id,
        deleted_by: session.technicianId
      });
    } catch (e) {
      console.error('deleteConversation error', e);
    }
  };

  const persistMessage = async (payload, offlinePreview) => {
    if (busy || !identity || !session) return;
    setError('');
    setDraft('');
    setBusy(true);
    removeDeletedConvId(identity.conversation_id);
    try {
      const msg = await base44.entities.ChatMessage.create({
        technician_id: technicianId,
        conversation_id: identity.conversation_id,
        client_technician_id: session.technicianId,
        sender_name: '',
        sender_phone: '',
        from_technician: false,
        ...payload
      });
      setMessages(prev => prev.some(x => x.id === msg.id) ? prev : [...prev, msg]);
      base44.entities.ChatMessage.filter({ conversation_id: identity.conversation_id }, '-created_date', 200)
        .then(list => setMessages(list.reverse()))
        .catch(() => {});
      notifyOfflineRecipient(technicianId, offlinePreview, identity.conversation_id, '');
      return true;
    } catch {
      if (payload.message_type !== 'audio') setDraft(payload.content || '');
      setError('Envoi impossible. Réessayez.');
      return false;
    } finally {
      setBusy(false);
    }
  };

  const sendText = async (content) => {
    if (!content.trim()) return;
    return persistMessage({
      content,
      message_type: 'text',
    }, content);
  };

  const sendAudio = async ({ audioUrl, durationMs, mimeType }) => {
    return persistMessage({
      content: '🎤 Message vocal',
      message_type: 'audio',
      audio_url: audioUrl,
      audio_duration_ms: durationMs,
      audio_mime_type: mimeType,
    }, '🎤 Message vocal');
  };

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="primary-button mt-3 relative">
        <MessageSquare size={17} />Discuter en direct
        {unread > 0 && (
          <span className="badge-ring absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1 text-xs font-bold text-white">{unread}</span>
        )}
      </button>

      {open && (
        <div className="fixed inset-x-0 bottom-[57px] z-50 sm:inset-x-auto sm:bottom-20 sm:right-4 sm:w-80" style={kb > 0 ? { bottom: `calc(57px + ${kb}px)` } : undefined}>
          <div className="flex flex-col border border-[#D3CCBE] bg-[#F3EFE7] shadow-2xl" style={{ maxHeight: '70vh' }}>
            <div className="flex items-center justify-between bg-[#3A8E9C] px-4 py-3 text-white">
              <div className="flex items-center gap-2">
                <span className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-full bg-[#F3EFE7]/20">
                  {techPhoto ? <img src={techPhoto} alt={technicianName} className="h-full w-full object-cover" /> : <MessageSquare size={16} />}
                </span>
                <div className="min-w-0">
                  <Link to={`/explorer/${technicianId}`} onClick={() => setOpen(false)} className="block truncate text-sm font-semibold leading-tight underline-offset-2 hover:underline">{technicianName}</Link>
                  <div className="flex items-center gap-1 text-xs text-cyan-100"><span className="status-dot" /> En ligne</div>
                </div>
              </div>
              <button onClick={() => refreshRef.current()} className="flex h-8 w-8 items-center justify-center text-white/90 hover:text-white" aria-label="Rafraîchir"><RefreshCw size={16} /></button>
              <button onClick={clearForMe} className="flex h-8 w-8 items-center justify-center text-white/90 hover:text-white" aria-label="Effacer pour moi" title="Effacer pour moi"><Eraser size={17} /></button>
              <button onClick={deleteConversation} className="flex h-8 w-8 items-center justify-center text-white/90 hover:text-white" aria-label="Supprimer la conversation" title="Supprimer la conversation"><Trash2 size={18} /></button>
              <button onClick={() => setOpen(false)} className="flex h-8 w-8 items-center justify-center text-white/90 hover:text-white" aria-label="Fermer"><X size={20} /></button>
            </div>

            {session ? (
              <>
                <div ref={scrollRef} className="scroll-pane flex-1 overflow-y-auto bg-[#E9E3D7] p-3 grid gap-2 content-start" style={{ minHeight: '200px' }}>
                  {loading && <span className="flex items-center gap-2 text-xs text-slate-500"><Loader2 size={14} className="animate-spin" />Chargement…</span>}
                  {!loading && messages.length === 0 && <span className="text-xs text-slate-500">Démarrez la conversation — écrivez votre premier message ci-dessous.</span>}
                  {messages.map(m => (
                    <div key={m.id} className={`flex items-end gap-1.5 ${m.from_technician ? 'justify-start' : 'justify-end'}`}>
                      {m.from_technician && (
                        <span className="flex h-6 w-6 shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#F3EFE7] border border-[#D3CCBE]">
                          {techPhoto ? <img src={techPhoto} alt="" className="h-full w-full object-cover" /> : <MessageSquare size={12} className="text-slate-400" />}
                        </span>
                      )}
                      <div className={`max-w-[78%] rounded-2xl px-3 py-2 text-sm leading-snug ${m.from_technician ? 'bg-[#F3EFE7] text-slate-900 border border-[#D3CCBE]' : 'bg-[#3A8E9C] text-white'}`}>
                        <ChatMessageContent message={m} />
                      </div>
                      {!m.from_technician && (
                        <span className="flex h-6 w-6 shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#3A8E9C]/20 border border-[#3A8E9C]/30">
                          {myPhoto ? <img src={myPhoto} alt="" className="h-full w-full object-cover" /> : <span className="text-[10px] font-bold text-[#3A8E9C]">Moi</span>}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
                {error && <span className="px-3 pt-2 text-xs text-red-600">{error}</span>}
                <ChatComposer
                  draft={draft}
                  onDraftChange={setDraft}
                  onSendText={sendText}
                  onSendAudio={sendAudio}
                  busy={busy}
                />
              </>
            ) : (
              <div className="flex flex-1 flex-col items-center justify-center gap-4 bg-[#E9E3D7] p-6 text-center">
                <span className="text-sm font-semibold text-slate-900">Connexion requise</span>
                <p className="max-w-[240px] text-sm leading-relaxed text-slate-500">Le chat instantané est réservé aux utilisateurs connectés à leur compte tektoo.</p>
                <Link to="/connexion" className="primary-button" onClick={() => setOpen(false)}><LogIn size={17} />Se connecter</Link>
                <Link to="/inscription" className="text-sm font-semibold text-[#3A8E9C] underline underline-offset-4" onClick={() => setOpen(false)}>Créer un compte</Link>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}