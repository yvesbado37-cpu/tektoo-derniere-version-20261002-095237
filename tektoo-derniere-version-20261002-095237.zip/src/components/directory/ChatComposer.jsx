import React, { useEffect, useRef, useState } from 'react';
import { Delete, Loader2, Mic, Send, Square, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const QUICK_KEYS = ['Bonjour', 'Merci', "D’accord", 'À bientôt'];
const AUDIO_MIME_TYPES = [
  'audio/webm;codecs=opus',
  'audio/webm',
  'audio/mp4',
  'audio/ogg;codecs=opus',
];
const MAX_AUDIO_DURATION_MS = 180000;

function getSupportedMimeType() {
  if (typeof window === 'undefined' || typeof window.MediaRecorder === 'undefined') return '';
  return AUDIO_MIME_TYPES.find((type) => window.MediaRecorder.isTypeSupported?.(type)) || '';
}

function formatRecordingDuration(durationMs) {
  const totalSeconds = Math.max(0, Math.floor(durationMs / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

/**
 * Shared themed composer for every chat surface.
 * `onSendText` and `onSendAudio` may be async and can return `false` to signal send failure.
 * `onSendAudio` receives `{ audioUrl, durationMs, mimeType }` after the upload succeeds.
 */
export default function ChatComposer({
  draft,
  onDraftChange,
  onSendText,
  onSendAudio,
  busy,
  placeholder = 'Votre message…',
}) {
  const [recordingState, setRecordingState] = useState('idle');
  const [recordingMs, setRecordingMs] = useState(0);
  const [error, setError] = useState('');
  const [pendingAudio, setPendingAudio] = useState(null);
  const recorderRef = useRef(null);
  const streamRef = useRef(null);
  const chunksRef = useRef([]);
  const startedAtRef = useRef(0);
  const timerRef = useRef(null);
  const discardRef = useRef(false);

  const canRecord = typeof navigator !== 'undefined'
    && !!navigator.mediaDevices?.getUserMedia
    && typeof window !== 'undefined'
    && typeof window.MediaRecorder !== 'undefined';
  const localBusy = busy || recordingState === 'uploading';

  const stopTracks = () => {
    if (!streamRef.current) return;
    streamRef.current.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
  };

  const clearTimer = () => {
    if (!timerRef.current) return;
    window.clearInterval(timerRef.current);
    timerRef.current = null;
  };

  const resetRecorder = () => {
    clearTimer();
    stopTracks();
    recorderRef.current = null;
    chunksRef.current = [];
    setRecordingMs(0);
  };

  useEffect(() => () => {
    discardRef.current = true;
    try {
      if (recorderRef.current && recorderRef.current.state !== 'inactive') recorderRef.current.stop();
    } catch {}
    resetRecorder();
  }, []);

  const deliverAudioMessage = async (audioPayload) => {
    if (!audioPayload?.audioUrl) {
      setError('Message vocal introuvable. Recommencez l’enregistrement.');
      return false;
    }
    const sent = await onSendAudio?.(audioPayload);
    if (sent === false) {
      setPendingAudio({ ...audioPayload, audioUrl: audioPayload.audioUrl });
      setError('Message vocal prêt. Réessayez l’envoi.');
      return false;
    }
    setPendingAudio(null);
    setError('');
    return true;
  };

  const finalizeRecording = async () => {
    const durationMs = Math.min(MAX_AUDIO_DURATION_MS, Math.max(0, Date.now() - startedAtRef.current));
    const mimeType = recorderRef.current?.mimeType || getSupportedMimeType() || 'audio/webm';
    const discard = discardRef.current;
    const chunks = [...chunksRef.current];
    resetRecorder();
    discardRef.current = false;

    if (discard) {
      setRecordingState('idle');
      return;
    }

    if (chunks.length === 0) {
      setRecordingState('idle');
      setError('Aucun son capturé.');
      return;
    }

    setRecordingState('uploading');
    try {
      const blob = new Blob(chunks, { type: mimeType });
      const extension = mimeType.includes('mp4') ? 'm4a' : mimeType.includes('ogg') ? 'ogg' : 'webm';
      const file = new File([blob], `voice-message-${Date.now()}.${extension}`, { type: mimeType });
      const uploadPublicFile = /** @type {any} */ (base44.integrations.Core).UploadPublicFile;
      const { file_url } = await uploadPublicFile({ file });
      const uploadedAudioPayload = { audioUrl: file_url, durationMs, mimeType };
      await deliverAudioMessage(uploadedAudioPayload);
    } catch {
      setError('Téléversement du message vocal impossible.');
    } finally {
      setRecordingState('idle');
    }
  };

  const startRecording = async () => {
    if (!canRecord || localBusy || recordingState === 'recording') return;
    setError('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = getSupportedMimeType();
      const recorder = new window.MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      streamRef.current = stream;
      recorderRef.current = recorder;
      chunksRef.current = [];
      discardRef.current = false;
      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) chunksRef.current.push(event.data);
      };
      recorder.onstop = () => { void finalizeRecording(); };
      recorder.onerror = () => {
        discardRef.current = true;
        recorder.onstop = null;
        setRecordingState('idle');
        setError('Enregistrement impossible.');
        resetRecorder();
      };
      startedAtRef.current = Date.now();
      setRecordingState('recording');
      setRecordingMs(0);
      recorder.start();
      timerRef.current = window.setInterval(() => {
        const nextDuration = Date.now() - startedAtRef.current;
        setRecordingMs(nextDuration);
        if (nextDuration >= MAX_AUDIO_DURATION_MS) {
          if (recorderRef.current?.state === 'recording') recorderRef.current.stop();
          clearTimer();
        }
      }, 250);
    } catch {
      setError('Accès au micro refusé ou indisponible.');
      setRecordingState('idle');
      setPendingAudio(null);
      resetRecorder();
    }
  };

  const stopRecording = (discard = false) => {
    if (!recorderRef.current) return;
    discardRef.current = discard;
    clearTimer();
    if (recorderRef.current.state !== 'inactive') {
      recorderRef.current.stop();
      return;
    }
    void finalizeRecording();
  };

  const appendQuickKey = (value) => {
    if (localBusy || recordingState === 'recording') return;
    const nextValue = draft.trim() ? `${draft.trimEnd()} ${value}` : value;
    onDraftChange(nextValue);
  };

  const removeLastWord = () => {
    if (localBusy || recordingState === 'recording') return;
    const nextValue = draft.trimEnd().replace(/\s*\S+\s*$/, '');
    onDraftChange(nextValue);
  };

  const submitText = async (event) => {
    event.preventDefault();
    if (localBusy || recordingState === 'recording') return;
    const content = draft.trim();
    if (!content) return;
    await onSendText?.(content);
  };

  return (
    <div className="border-t border-[#D3CCBE] bg-[#F3EFE7] p-3">
      <div className="mb-2 flex flex-wrap items-center gap-2">
        {QUICK_KEYS.map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => appendQuickKey(value)}
            disabled={localBusy || recordingState === 'recording'}
            className="rounded-2xl border border-[#3A8E9C]/20 bg-[#E9E3D7] px-3 py-1.5 text-[11px] font-semibold text-[#3A8E9C] transition-colors hover:bg-[#dce9eb] disabled:opacity-50"
          >
            {value}
          </button>
        ))}
        <button
          type="button"
          onClick={removeLastWord}
          disabled={!draft.trim() || localBusy || recordingState === 'recording'}
          className="ml-auto flex h-8 w-8 items-center justify-center rounded-full border border-[#D3CCBE] bg-white/70 text-[#675F54] transition-colors hover:border-[#3A8E9C] hover:text-[#3A8E9C] disabled:opacity-40"
          aria-label="Effacer le dernier mot"
        >
          <Delete size={15} />
        </button>
      </div>

      <form onSubmit={submitText} className="grid gap-2">
        <div className="flex items-end gap-2 rounded-[28px] border border-[#D3CCBE] bg-[#E9E3D7] p-2 shadow-inner">
          <div className="min-w-0 flex-1 rounded-[22px] border border-[#D3CCBE]/70 bg-[#F7F3EC] px-3 py-2">
            <div className="mb-1 text-[10px] font-bold uppercase tracking-[0.22em] text-[#3A8E9C]/70">Touches rapides</div>
            <textarea
              value={draft}
              onChange={(event) => onDraftChange(event.target.value)}
              placeholder={placeholder}
              rows={1}
              disabled={localBusy || recordingState === 'recording'}
              onKeyDown={(event) => {
                if (event.key === 'Enter' && !event.shiftKey) {
                  event.preventDefault();
                  void submitText(event);
                }
              }}
              className="max-h-24 min-h-[32px] w-full resize-none bg-transparent text-sm outline-none placeholder:text-slate-400"
            />
          </div>

          {recordingState === 'recording' ? (
            <>
              <div className="flex min-h-[44px] min-w-[88px] items-center justify-center rounded-full bg-[#3A8E9C] px-3 text-sm font-semibold text-white">
                {formatRecordingDuration(recordingMs)}
              </div>
              <button
                type="button"
                onClick={() => stopRecording(true)}
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full border border-red-500/20 bg-red-500/10 text-red-500"
                aria-label="Annuler l'enregistrement"
              >
                <X size={18} />
              </button>
              <button
                type="button"
                onClick={() => stopRecording(false)}
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full bg-[#3A8E9C] text-white"
                aria-label="Envoyer le message vocal"
              >
                <Square size={16} fill="currentColor" />
              </button>
            </>
          ) : (
            <>
              {canRecord && (
                <button
                  type="button"
                  onClick={startRecording}
                  disabled={localBusy}
                  className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full border border-[#3A8E9C]/20 bg-[#3A8E9C]/10 text-[#3A8E9C] disabled:opacity-50"
                  aria-label="Enregistrer un message vocal"
                >
                  {recordingState === 'uploading' ? <Loader2 size={18} className="animate-spin" /> : <Mic size={18} />}
                </button>
              )}
              <button
                type="submit"
                disabled={localBusy || !draft.trim()}
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full bg-[#3A8E9C] px-4 text-white disabled:opacity-50"
              >
                {busy ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
              </button>
            </>
          )}
        </div>

        {(recordingState === 'recording' || recordingState === 'uploading' || error) && (
          <div className={`text-xs ${error ? 'text-red-600' : 'text-[#675F54]'}`}>
            {error || (recordingState === 'uploading'
              ? 'Téléversement du message vocal…'
              : `Enregistrement en cours… ${formatRecordingDuration(recordingMs)} / 3:00`)}
          </div>
        )}
        {pendingAudio && recordingState === 'idle' && (
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => { void deliverAudioMessage(pendingAudio); }}
              className="rounded-full bg-[#3A8E9C] px-3 py-2 text-xs font-semibold text-white"
            >
              Réessayer l’envoi du vocal
            </button>
            <button
              type="button"
              onClick={() => { setPendingAudio(null); setError(''); }}
              className="rounded-full border border-[#D3CCBE] px-3 py-2 text-xs font-semibold text-[#675F54]"
            >
              Annuler
            </button>
          </div>
        )}
      </form>
    </div>
  );
}
