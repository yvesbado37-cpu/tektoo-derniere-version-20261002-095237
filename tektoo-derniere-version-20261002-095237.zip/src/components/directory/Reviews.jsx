import React, { useEffect, useState } from 'react';
import { Star, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

function Stars({ value, size = 16 }) {
  return <div className="flex gap-0.5">{[1, 2, 3, 4, 5].map(n => <Star key={n} size={size} className={n <= Math.round(value) ? 'fill-[#3A8E9C] text-[#3A8E9C]' : 'text-slate-300'}/>)}</div>;
}

export default function Reviews({ technicianId }) {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [rating, setRating] = useState(5);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = () => {
    setLoading(true);
    base44.entities.Review.filter({ technician_id: technicianId }, '-created_date', 50)
      .then(setReviews).finally(() => setLoading(false));
  };
  useEffect(() => { if (technicianId) load(); }, [technicianId]);

  const avg = reviews.length ? reviews.reduce((s, r) => s + (r.rating || 0), 0) / reviews.length : 0;

  const submit = async e => {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      await base44.entities.Review.create({
        technician_id: technicianId,
        rating: Number(rating),
        author_name: name.trim() || undefined
      });
      setName(''); setRating(5);
      load();
    } catch (err) {
      setError("La note n'a pas pu être publiée. Veuillez réessayer.");
    } finally { setBusy(false); }
  };

  return (
    <section>
      <h3 className="profile-heading text-slate-900">Évaluations</h3>
      {loading ? <p className="text-sm text-slate-500">Chargement…</p>
        : reviews.length > 0 ? (
          <div className="flex items-center gap-3 border-y border-[#D3CCBE] py-3">
            <span className="text-3xl font-semibold text-slate-900">{avg.toFixed(1)}</span>
            <div><Stars value={avg}/><span className="text-xs text-slate-500">{reviews.length} avis</span></div>
          </div>
        ) : <p className="text-sm text-slate-500">Aucune évaluation pour le moment. Soyez le premier à noter ce professionnel.</p>}
      <form onSubmit={submit} className="mt-4 grid gap-2 border-t border-[#D3CCBE] pt-4">
        <span className="text-sm font-semibold text-slate-700">Noter ce professionnel</span>
        <label className="flex items-center gap-2 text-sm text-slate-700">Note :
          <select value={rating} onChange={e => setRating(e.target.value)} className="rounded-lg border border-[#D3CCBE] bg-[#E9E3D7] px-2 py-2 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]">
            {[5, 4, 3, 2, 1].map(n => <option key={n} value={n}>{n} étoile{n > 1 ? 's' : ''}</option>)}
          </select>
        </label>
        <input maxLength={50} placeholder="Votre nom (facultatif)" value={name} onChange={e => setName(e.target.value)} className="w-full rounded-lg border border-[#D3CCBE] bg-[#E9E3D7] px-3 py-2 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]"/>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button type="submit" className="primary-button" disabled={busy}>{busy ? <><Loader2 size={16} className="animate-spin"/>Publication…</> : 'Publier ma note'}</button>
      </form>
    </section>
  );
}