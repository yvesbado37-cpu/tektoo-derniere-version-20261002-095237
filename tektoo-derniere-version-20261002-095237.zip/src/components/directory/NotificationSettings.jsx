import React, { useState, useEffect } from 'react';
import { X, Volume2, VolumeX, Vibrate, Bell, Play, Check } from 'lucide-react';
import {
  isMuted, toggleMuted,
  getVolume, setVolume,
  getRingtone, setRingtone,
  isVibrateEnabled, setVibrateEnabled,
  ringtones, playRingtonePreview, triggerVibrate,
} from '@/lib/buttonSound';

export default function NotificationSettings({ open, onClose }) {
  const [muted, setMutedState] = useState(isMuted());
  const [vol, setVol] = useState(Math.round(getVolume() * 100));
  const [rt, setRt] = useState(getRingtone());
  const [vib, setVib] = useState(isVibrateEnabled());

  useEffect(() => {
    if (!open) return;
    const sync = () => {
      setMutedState(isMuted());
      setVol(Math.round(getVolume() * 100));
      setRt(getRingtone());
      setVib(isVibrateEnabled());
    };
    window.addEventListener('tektoo-sound-muted', sync);
    window.addEventListener('tektoo-sound-settings', sync);
    return () => {
      window.removeEventListener('tektoo-sound-muted', sync);
      window.removeEventListener('tektoo-sound-settings', sync);
    };
  }, [open]);

  if (!open) return null;

  const handleMute = () => { toggleMuted(); setMutedState(isMuted()); };
  const handleVol = (v) => { setVol(v); setVolume(v / 100); };
  const handleRingtone = (id) => { setRt(id); setRingtone(id); playRingtonePreview(id); };
  const handleVibrate = () => { const next = !vib; setVib(next); setVibrateEnabled(next); if (next) triggerVibrate([100, 50, 100]); };

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40" />
      <div
        className="relative z-10 max-h-[88vh] w-full overflow-y-auto border border-[#D3CCBE] bg-[#F3EFE7] sm:max-w-md"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#D3CCBE] bg-[#3A8E9C] px-4 py-3 text-white">
          <div className="flex items-center gap-2">
            <Bell size={18} />
            <span className="text-sm font-semibold">Réglages des notifications</span>
          </div>
          <button onClick={onClose} className="no-sound flex h-8 w-8 items-center justify-center text-white/90 hover:text-white" aria-label="Fermer">
            <X size={20} />
          </button>
        </div>

        <div className="grid gap-5 p-4">
          {/* Mute toggle */}
          <button
            onClick={handleMute}
            className={`no-sound flex items-center justify-between rounded-lg border px-4 py-3 text-sm font-semibold transition-colors ${muted ? 'border-[#D3CCBE] bg-[#E9E3D7] text-[#675F54]' : 'border-[#3A8E9C] bg-[#3A8E9C]/10 text-[#3A8E9C]'}`}
          >
            <span className="flex items-center gap-2">
              {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
              {muted ? 'Sons coupés' : 'Sons activés'}
            </span>
            <span className={`relative h-6 w-11 rounded-full transition-colors ${muted ? 'bg-[#D3CCBE]' : 'bg-[#3A8E9C]'}`}>
              <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${muted ? 'left-0.5' : 'left-[22px]'}`} />
            </span>
          </button>

          {/* Volume slider */}
          <div className={`grid gap-2 ${muted ? 'opacity-40 pointer-events-none' : ''}`}>
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#2E2A24]">Volume</label>
              <span className="font-mono text-xs text-[#675F54]">{vol}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={vol}
              onChange={e => handleVol(Number(e.target.value))}
              className="h-2 w-full cursor-pointer appearance-none rounded-full bg-[#D3CCBE] outline-none [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#3A8E9C] [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white [&::-webkit-slider-thumb]:shadow [&::-moz-range-thumb]:h-5 [&::-moz-range-thumb]:w-5 [&::-moz-range-thumb]:appearance-none [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-[#3A8E9C] [&::-moz-range-thumb]:border-2 [&::-moz-range-thumb]:border-white"
            />
          </div>

          {/* Ringtone selection */}
          <div className={`grid gap-2 ${muted ? 'opacity-40 pointer-events-none' : ''}`}>
            <label className="text-xs font-semibold text-[#2E2A24]">Sonnerie des messages</label>
            <div className="grid gap-1.5">
              {ringtones.map(r => (
                <button
                  key={r.id}
                  onClick={() => handleRingtone(r.id)}
                  className={`no-sound flex items-center justify-between rounded-lg border px-3 py-2.5 text-left transition-colors ${rt === r.id ? 'border-[#3A8E9C] bg-[#3A8E9C]/10' : 'border-[#D3CCBE] bg-[#F3EFE7] hover:bg-[#E9E3D7]'}`}
                >
                  <span className="min-w-0">
                    <span className="block text-sm font-semibold text-[#2E2A24]">{r.label}</span>
                    <span className="block text-xs text-[#675F54]">{r.desc}</span>
                  </span>
                  <span className="flex shrink-0 items-center gap-2">
                    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#3A8E9C]/15 text-[#3A8E9C]">
                      <Play size={13} fill="currentColor" />
                    </span>
                    {rt === r.id && <Check size={16} className="text-[#3A8E9C]" />}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Vibrate toggle */}
          <button
            onClick={handleVibrate}
            className={`no-sound flex items-center justify-between rounded-lg border px-4 py-3 text-sm font-semibold transition-colors ${vib ? 'border-[#3A8E9C] bg-[#3A8E9C]/10 text-[#3A8E9C]' : 'border-[#D3CCBE] bg-[#E9E3D7] text-[#675F54]'}`}
          >
            <span className="flex items-center gap-2">
              <Vibrate size={18} />
              {vib ? 'Vibreur activé' : 'Vibreur désactivé'}
            </span>
            <span className={`relative h-6 w-11 rounded-full transition-colors ${vib ? 'bg-[#3A8E9C]' : 'bg-[#D3CCBE]'}`}>
              <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${vib ? 'left-[22px]' : 'left-0.5'}`} />
            </span>
          </button>

          <p className="text-xs leading-relaxed text-[#675F54]">
            Ces réglages s'appliquent aux notifications de messages sur cet appareil. Le mode vibreur nécessite un appareil compatible.
          </p>
        </div>
      </div>
    </div>
  );
}