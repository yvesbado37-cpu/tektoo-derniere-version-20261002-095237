function normalizeMediaSrc(src) {
  return typeof src === 'string' ? src.trim().split('#')[0] : '';
}

export function getProfileMedia(technician) {
  if (!technician) return [];

  const orderedMedia = [
    { type: 'image', src: technician.profile_photo, label: 'Photo de profil' },
    { type: 'image', src: technician.illustration_1, label: 'Illustration 1' },
    { type: 'image', src: technician.illustration_2, label: 'Illustration 2' },
    { type: 'image', src: technician.illustration_3, label: 'Illustration 3' },
    { type: 'image', src: technician.illustration_4, label: 'Illustration 4' },
    { type: 'video', src: technician.presentation_video, label: 'Vidéo de présentation' },
    ...((technician.pro_album_1 || []).map((src, index) => ({ type: 'image', src, label: `Album 1 · Photo ${index + 1}` }))),
    ...((technician.pro_album_2 || []).map((src, index) => ({ type: 'image', src, label: `Album 2 · Photo ${index + 1}` }))),
    ...((technician.pro_videos || []).map((src, index) => ({ type: 'video', src, label: `Vidéo pro ${index + 1}` }))),
  ];

  const seen = new Set();

  return orderedMedia
    .filter((media) => {
      const normalizedSrc = normalizeMediaSrc(media.src);
      if (!normalizedSrc || seen.has(normalizedSrc)) return false;
      seen.add(normalizedSrc);
      return true;
    })
    .map((media, index) => ({
      ...media,
      src: media.src.trim(),
      id: `${media.type}-${index}-${normalizeMediaSrc(media.src)}`,
    }));
}
