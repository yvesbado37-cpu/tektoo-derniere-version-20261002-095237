import React, { useEffect, useState } from 'react';
import { X, Loader2 } from 'lucide-react';

export default function TrimmedVideo({ src, className, autoPlay }) {
  const [videoEl, setVideoEl] = useState(null);
  const [isFs, setIsFs] = useState(false);
  const [loading, setLoading] = useState(true);

  const hash = src ? src.split('#t=')[1] : null;
  const [startStr, endStr] = hash ? hash.split(',') : [];
  const start = parseFloat(startStr) || 0;
  const end = endStr ? parseFloat(endStr) : null;
  const cleanSrc = src ? src.split('#')[0] : src;

  useEffect(() => {
    const v = videoEl;
    if (!v || !hash) return;

    const onLoaded = () => { if (start > 0) v.currentTime = start; };
    const onTimeUpdate = () => {
      if (end && v.currentTime >= end) {
        v.pause();
        if (start > 0) v.currentTime = start;
      }
    };

    v.addEventListener('loadedmetadata', onLoaded);
    v.addEventListener('timeupdate', onTimeUpdate);
    return () => {
      v.removeEventListener('loadedmetadata', onLoaded);
      v.removeEventListener('timeupdate', onTimeUpdate);
    };
  }, [videoEl, src]);

  useEffect(() => {
    const v = videoEl;
    if (!v) return;

    const onPlay = () => setIsFs(true);
    const onEnded = () => setIsFs(false);
    const onWaiting = () => setLoading(true);
    const onPlaying = () => setLoading(false);
    const onCanPlay = () => setLoading(false);

    v.addEventListener('play', onPlay);
    v.addEventListener('ended', onEnded);
    v.addEventListener('waiting', onWaiting);
    v.addEventListener('playing', onPlaying);
    v.addEventListener('canplay', onCanPlay);
    return () => {
      v.removeEventListener('play', onPlay);
      v.removeEventListener('ended', onEnded);
      v.removeEventListener('waiting', onWaiting);
      v.removeEventListener('playing', onPlaying);
      v.removeEventListener('canplay', onCanPlay);
    };
  }, [videoEl]);

  const exitFs = () => {
    if (videoEl) videoEl.pause();
    setIsFs(false);
  };

  const spinner = loading && (
    <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/20">
      <Loader2 size={28} className="animate-spin text-white/90" />
    </div>
  );

  if (isFs) {
    return (
      <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black">
        <button type="button" onClick={exitFs} aria-label="Quitter le plein écran" className="absolute right-3 top-3 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20">
          <X size={22} />
        </button>
        {spinner}
        <video ref={setVideoEl} src={cleanSrc} controls autoPlay playsInline preload="auto" className="max-h-full max-w-full object-contain" />
      </div>
    );
  }

  return (
    <div className={`relative ${className || ''}`}>
      {spinner}
      <video ref={setVideoEl} src={cleanSrc} controls autoPlay={autoPlay} playsInline preload={autoPlay ? 'auto' : 'metadata'} className="h-full w-full object-contain" />
    </div>
  );
}