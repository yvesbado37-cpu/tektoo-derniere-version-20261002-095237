import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, ImageOff, Play, Video, X } from 'lucide-react';

function getMediaFileName(src) {
  if (!src) return '';
  try {
    const cleanSrc = src.split('?')[0];
    return decodeURIComponent(cleanSrc.split('/').pop() || '');
  } catch {
    return src;
  }
}

export default function ProfileMediaViewer({ open, onOpenChange, media = [], initialIndex = 0, profileName }) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [loadError, setLoadError] = useState('');
  const videoRef = useRef(null);
  const touchStartX = useRef(null);
  const closeButtonRef = useRef(null);
  const previousFocusRef = useRef(null);

  useEffect(() => {
    if (open) {
      previousFocusRef.current = document.activeElement;
      setCurrentIndex(Math.min(initialIndex, Math.max(media.length - 1, 0)));
      window.requestAnimationFrame(() => closeButtonRef.current?.focus());
    } else if (previousFocusRef.current?.focus) {
      previousFocusRef.current.focus();
    }
  }, [initialIndex, media.length, open]);

  const currentMedia = media[currentIndex];
  const hasMultiple = media.length > 1;

  const pauseActiveVideo = useCallback(() => {
    const activeVideo = videoRef.current;
    if (!activeVideo) return;
    activeVideo.pause();
    activeVideo.removeAttribute('src');
    activeVideo.load();
    videoRef.current = null;
  }, []);

  const handleClose = useCallback((nextOpen) => {
    if (!nextOpen) pauseActiveVideo();
    onOpenChange(nextOpen);
  }, [onOpenChange, pauseActiveVideo]);

  useEffect(() => {
    setLoadError('');
    return () => {
      pauseActiveVideo();
    };
  }, [currentMedia?.id, pauseActiveVideo]);

  useEffect(() => {
    if (!open) return undefined;

    const onKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        handleClose(false);
        return;
      }
      if (event.key === 'ArrowRight' && hasMultiple) {
        event.preventDefault();
        setCurrentIndex((index) => (index + 1) % media.length);
      }
      if (event.key === 'ArrowLeft' && hasMultiple) {
        event.preventDefault();
        setCurrentIndex((index) => (index - 1 + media.length) % media.length);
      }
    };

    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [handleClose, hasMultiple, media.length, open]);

  const goTo = (index) => {
    if (!media.length) return;
    setCurrentIndex((index + media.length) % media.length);
  };

  const handleTouchStart = (event) => {
    if (currentMedia?.type === 'video') return;
    touchStartX.current = event.changedTouches?.[0]?.clientX ?? null;
  };

  const handleTouchEnd = (event) => {
    if (currentMedia?.type === 'video') return;
    if (!hasMultiple || touchStartX.current === null) return;
    const touchEndX = event.changedTouches?.[0]?.clientX ?? touchStartX.current;
    const delta = touchEndX - touchStartX.current;
    touchStartX.current = null;
    if (Math.abs(delta) < 40) return;
    goTo(delta < 0 ? currentIndex + 1 : currentIndex - 1);
  };

  if (!open || !media.length) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`Visionneuse média du profil ${profileName}`}
      className="fixed inset-0 z-[70] flex h-[100dvh] max-h-[100dvh] w-screen flex-col overflow-hidden bg-black text-white"
      style={{
        paddingTop: 'max(0.75rem, env(safe-area-inset-top))',
        paddingBottom: 'max(0.75rem, env(safe-area-inset-bottom))',
        paddingLeft: 'max(0.75rem, env(safe-area-inset-left))',
        paddingRight: 'max(0.75rem, env(safe-area-inset-right))',
      }}
    >
      <div
        className="absolute inset-0"
        onClick={() => handleClose(false)}
        aria-hidden="true"
      />
      <div
        className="relative flex h-full flex-col"
        style={{
          minHeight: 0,
        }}
      >
        <div className="flex items-center justify-between gap-3 px-2 pb-2">
          <div className="min-w-0">
            <p className="text-sm font-semibold text-white">{currentIndex + 1} / {media.length}</p>
            <p className="break-words text-xs text-white/70">{currentMedia?.label}</p>
          </div>
          <button
            ref={closeButtonRef}
            type="button"
            onClick={() => handleClose(false)}
            aria-label="Fermer la visionneuse"
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white/20"
          >
            <X size={22} />
          </button>
        </div>

        <div className="relative flex min-h-0 flex-1 items-center justify-center overflow-hidden" onTouchStart={handleTouchStart} onTouchEnd={handleTouchEnd}>
          {hasMultiple && (
            <>
              <button
                type="button"
                onClick={() => goTo(currentIndex - 1)}
                aria-label="Média précédent"
                className="absolute left-2 top-1/2 z-10 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/15 text-white transition hover:bg-white/25"
              >
                <ChevronLeft size={24} />
              </button>
              <button
                type="button"
                onClick={() => goTo(currentIndex + 1)}
                aria-label="Média suivant"
                className="absolute right-2 top-1/2 z-10 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/15 text-white transition hover:bg-white/25"
              >
                <ChevronRight size={24} />
              </button>
            </>
          )}

          {loadError ? (
            <div className="mx-auto flex max-w-sm flex-col items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-5 py-6 text-center">
              <ImageOff size={28} className="text-white/70" />
              <p className="text-sm font-medium text-white">Ce média est indisponible.</p>
              <p className="break-words text-xs text-white/70">{getMediaFileName(currentMedia?.src) || currentMedia?.label}</p>
            </div>
          ) : currentMedia?.type === 'video' ? (
            <video
              key={currentMedia.id}
              ref={videoRef}
              src={currentMedia.src}
              controls
              playsInline
              preload="metadata"
              onError={() => setLoadError('video')}
              className="max-h-full max-w-full object-contain"
            />
          ) : (
            <img
              src={currentMedia?.src}
              alt={currentMedia?.label || `Média de ${profileName}`}
              onError={() => setLoadError('image')}
              className="max-h-full max-w-full object-contain"
            />
          )}
        </div>

        <div className="px-2 pt-3">
          <p className="break-words text-xs text-white/70">{getMediaFileName(currentMedia?.src)}</p>
          {hasMultiple && (
            <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
              {media.map((item, index) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => goTo(index)}
                  aria-label={`Afficher ${item.label}`}
                  className={`relative flex h-16 w-16 shrink-0 overflow-hidden rounded-xl border ${index === currentIndex ? 'border-white' : 'border-white/15'} bg-white/5`}
                >
                  {item.type === 'image' ? (
                    <img src={item.src} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <span className="flex h-full w-full flex-col items-center justify-center gap-1 px-1 text-[10px] text-white/80">
                      <Video size={16} />
                      <span className="break-words text-center leading-tight">Vidéo {index + 1}</span>
                    </span>
                  )}
                  {item.type === 'video' && (
                    <span className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/20">
                      <Play size={16} className="fill-white text-white" />
                    </span>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
