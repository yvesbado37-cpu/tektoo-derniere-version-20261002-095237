import { Zap, Wrench, Snowflake, PaintRoller, Droplets, BrickWall, Plus } from 'lucide-react';
export const trades = [
  { id: 'electricite', label: 'Électricité', short: 'Électricien', icon: Zap, caption: 'Installation & dépannage', services: ['Installations électriques', 'Diagnostic de panne', 'Tableaux et prises'] },
  { id: 'mecanique', label: 'Mécanique auto', short: 'Mécanicien automobile', icon: Wrench, caption: 'Entretien & réparation', services: ['Diagnostic automobile', 'Vidange et entretien', 'Réparation moteur'] },
  { id: 'froid', label: 'Froid & climatisation', short: 'Frigoriste', icon: Snowflake, caption: 'Installation & maintenance', services: ['Pose de climatiseurs', 'Entretien et nettoyage', 'Dépannage frigorifique'] },
  { id: 'peinture', label: 'Peinture', short: 'Artisan peintre', icon: PaintRoller, caption: 'Intérieur & extérieur', services: ['Peinture intérieure', 'Façades extérieures', 'Préparation des surfaces'] },
  { id: 'plomberie', label: 'Plomberie', short: 'Plombier', icon: Droplets, caption: 'Installation & dépannage', services: ['Installation sanitaire', 'Recherche de fuite', 'Débouchage et evacuation'] },
  { id: 'maconnerie', label: 'Maçonnerie', short: 'Maçon', icon: BrickWall, caption: 'Construction & rénovation', services: ['Gros œuvre', 'Dalles et chapes', 'Rénovation de murs'] },
  { id: 'autres', label: 'Autres', short: 'Autre domaine', icon: Plus, caption: 'Domaine personnalisé', services: [] }
];
export const tradeLabel = (t) => {
  if (!t) return '';
  if (t.trade === 'autres') return t.custom_trade || 'Autre domaine';
  return trades.find(x => x.id === t.trade)?.short || t.trade;
};
export const demos = [];
export const quartiers = [
  'Pissy', 'Gounghin', 'Bilbalogo', "Patte d'Oie", 'Cissin Tampuy', 'Zone du Bois',
  'Zogona', 'Wemtenga', 'Dagnoen', 'Sanyiri', 'Karpala', 'Cité An II', 'Cité An III',
  'Cité Azimo', 'Ouaga 2000', 'Koulouba', 'Zone 1', 'Kalgondin', 'Bassinko', 'Balkuy',
  'Hamdalaye', 'Saanba', 'ZAD', 'Tanghin', 'Somgandé', 'Kamboinsin', 'Dapoya', 'Larlin'
];
export const quartiersBobo = [
  'Secteur 1', 'Secteur 2', 'Secteur 3', 'Secteur 4', 'Secteur 5', 'Secteur 6',
  'Secteur 7', 'Secteur 8', 'Secteur 9', 'Secteur 10', 'Secteur 11', 'Secteur 12',
  'Accart-ville', 'Diarradougou', 'Sarfalao', 'Bolomakotè', 'Farimaké', 'Lafiabougou',
  'Tounouma', 'Kuinima', 'Dogona', 'Sokoura', 'Goufeba'
];
export const DEFAULT_AVATAR = 'https://media.base44.com/images/public/6aa99892f8c49e0cebb09430/46d775503_generated_image.png';
export const normalize = value => (value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();