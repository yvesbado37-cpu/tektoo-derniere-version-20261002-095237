import React, { useEffect, useState } from 'react';
import { Star, X, ChevronRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getSession } from '@/lib/technicianSession';
import { isProActive } from '@/lib/proStatus';

const STORAGE_KEY = 'tektoo_pro_hint_dismissed';

export default function ProHintBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let alive = true;
    try {
      if (sessionStorage.getItem(STORAGE_KEY)) return;
    } catch {}
    const session = getSession();
    if (!session?.technicianId) { if (alive) setVisible(true); return; }
    base44.entities.Technician.get(session.technicianId)
      .then(t => { if (alive && !isProActive(t)) setVisible(true); })
      .catch(() => { /* en cas d'erreur, on n'affiche pas la bannière (évite les faux positifs pour les Pro) */ });
    return () => { alive = false; };
  }, []);

  const dismiss = () => {
    try { sessionStorage.setItem(STORAGE_KEY, '1'); } catch {}
    setVisible(false);
  };

  const open = () => {
    window.dispatchEvent(new CustomEvent('tektoo-open-pro'));
  };

  if (!visible) return null;
  return (
    <div className="fixed bottom-4 left-4 right-4 z-30 sm:left-4 sm:right-auto sm:max-w-xs">
      <div className="flex items-center gap-2.5 rounded-2xl border bg-white px-3.5 py-3 shadow-lg" style={{ borderColor: 'rgba(194,121,46,0.35)' }}>
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-white" style={{ backgroundColor: '#C2792E' }}><Star size={16} fill="currentColor" /></span>
        <button type="button" onClick={open} className="min-w-0 flex-1 text-left">
          <div className="truncate text-sm font-semibold text-slate-900">Passez au compte Pro</div>
          <div className="truncate text-xs text-slate-500">Plus de visibilité, albums & vidéos.</div>
        </button>
        <button type="button" onClick={open} aria-label="Découvrir le compte Pro" className="no-sound shrink-0 rounded-full p-1.5 text-white" style={{ backgroundColor: '#C2792E' }}><ChevronRight size={16} /></button>
        <button type="button" onClick={dismiss} aria-label="Fermer" className="no-sound shrink-0 rounded-full p-1 text-slate-400 hover:bg-slate-100"><X size={15} /></button>
      </div>
    </div>
  );
}