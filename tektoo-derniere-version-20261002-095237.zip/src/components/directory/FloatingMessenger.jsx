import React, { useEffect, useRef, useState } from 'react';
import { MessageSquare, X, Loader2, ArrowLeft, Trash2, RefreshCw, Search } from 'lucide-react';
import { Link, useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { getSession } from '@/lib/technicianSession';
import { addDeletedConvId, getDeletedConvIds } from '@/lib/deletedConversations';
import useKeyboardOffset from '@/hooks/useKeyboardOffset';
import { updateLastActive, notifyOfflineRecipient } from '@/lib/whatsappNotify';
import { subscribeToPush } from '@/lib/pushNotifications';
import { playNotificationSound, triggerVibrate } from '@/lib/buttonSound';
import ChatComposer from '@/components/directory/ChatComposer';
import ChatMessageContent, { getMessagePreview } from '@/components/directory/ChatMessageContent';

export default function FloatingMessenger() {
  const [session, setSessionState] = useState(getSession());
  const [open, setOpen] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();
  const [conversations, setConversations] = useState([]);
  const [activeConvId, setActiveConvId] = useState(null);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(false);
  const [unreadConvIds, setUnreadConvIds] = useState(() => new Set());
  const totalUnread = unreadConvIds.size;
  const [search, setSearch] = useState('');
  const [myPhoto, setMyPhoto] = useState(null);
  const scrollRef = useRef(null);
  const activeIdRef = useRef(null);
  const activeConv = conversations.find(c => c.id === activeConvId) || null;
  activeIdRef.current = activeConv?.id;
  const kb = useKeyboardOffset();

  const techId = session?.technicianId;
  const techIdRef = useRef(techId);
  techIdRef.current = techId;

  useEffect(() => {
    const sync = () => setSessionState(getSession());
    window.addEventListener('tektoo-session', sync);
    window.addEventListener('storage', sync);
    return () => { window.removeEventListener('tektoo-session', sync); window.removeEventListener('storage', sync); };
  }, []);

  useEffect(() => {
    const syncDeleted = () => {
      const deletedSet = getDeletedConvIds();
      setConversations(prev => prev.filter(c => !deletedSet.has(c.id)));
      if (activeIdRef.current && deletedSet.has(activeIdRef.current)) setActiveConvId(null);
    };
    window.addEventListener('tektoo-deleted-conv', syncDeleted);
    window.addEventListener('storage', syncDeleted);
    return () => { window.removeEventListener('tektoo-deleted-conv', syncDeleted); window.removeEventListener('storage', syncDeleted); };
  }, []);

  useEffect(() => {
    if (!techId) { setMyPhoto(null); return; }
    base44.entities.Technician.get(techId).then(t => setMyPhoto(t?.profile_photo || null)).catch(() => {});
  }, [techId]);

  useEffect(() => {
    if (!techId) return;
    updateLastActive();
    subscribeToPush(techId);
    const interval = setInterval(updateLastActive, 60000);
    return () => clearInterval(interval);
  }, [techId]);

  const loadConversations = useRef(() => {});
  const firstLoadRef = useRef(false);
  const knownMessageIds = useRef(new Set());
  const fetchLockRef = useRef(false);
  loadConversations.current = async (force = false) => {
    const currentTechId = techIdRef.current;
    if (!currentTechId) { setConversations([]); setLoading(false); return; }
    if (fetchLockRef.current) return;
    fetchLockRef.current = true;
    const showLoading = force || !firstLoadRef.current;
    if (showLoading) setLoading(true);
    try {
      const [incoming, outgoing] = await Promise.all([
        base44.entities.ChatMessage.filter({ technician_id: currentTechId }, '-created_date', 500).catch(() => []),
        base44.entities.ChatMessage.filter({ client_technician_id: currentTechId }, '-created_date', 500).catch(() => [])
      ]);
      const allMessages = [...incoming, ...outgoing];
      const seen = new Set();
      const unique = allMessages.filter(m => {
        if (seen.has(m.id)) return false;
        seen.add(m.id);
        return true;
      });
      const deletedSet = getDeletedConvIds();
      // Detect new messages from the other party (notifications via polling fallback)
      if (firstLoadRef.current) {
        const newFromOther = [];
        unique.forEach(m => {
          if (knownMessageIds.current.has(m.id)) return;
          knownMessageIds.current.add(m.id);
          if (deletedSet.has(m.conversation_id)) return;
          const isTech = m.technician_id === currentTechId;
          const isClient = m.client_technician_id === currentTechId;
          if (!isTech && !isClient) return;
          const fromOtherParty = isTech ? !m.from_technician : m.from_technician;
          if (fromOtherParty && activeIdRef.current !== m.conversation_id) newFromOther.push(m);
        });
        if (newFromOther.length > 0) {
          setUnreadConvIds(prev => new Set([...prev, ...newFromOther.map(m => m.conversation_id)]));
          playNotificationSound();
          if ('Notification' in window && Notification.permission === 'granted') {
            try {
              const lastMsg = newFromOther[newFromOther.length - 1];
              const n = new Notification('Nouveau message', { body: getMessagePreview(lastMsg), tag: `tektoo_msg_${lastMsg.conversation_id}` });
              n.onclick = () => { window.focus(); n.close(); setOpen(true); };
            } catch {}
          }
          if (navigator.vibrate) triggerVibrate(200);
        }
      } else {
        unique.forEach(m => knownMessageIds.current.add(m.id));
      }
      const groups = {};
      unique.forEach(m => {
        if (deletedSet.has(m.conversation_id)) return;
        if (!groups[m.conversation_id]) groups[m.conversation_id] = [];
        groups[m.conversation_id].push(m);
      });
      const convs = Object.entries(groups).map(([convId, msgs]) => {
        msgs.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
        const convTechId = msgs[0].technician_id;
        const convClientId = msgs[0].client_technician_id;
        const isTechnician = currentTechId === convTechId;
        return {
          id: convId,
          technician_id: convTechId,
          client_technician_id: convClientId,
          isTechnician,
          name: isTechnician ? (msgs[0]?.sender_name || 'Client') : 'Technicien',
          phone: isTechnician ? (msgs[0]?.sender_phone || '') : '',
          lastMsg: msgs[msgs.length - 1],
          messages: msgs
        };
      }).sort((a, b) => new Date(b.lastMsg.created_date) - new Date(a.lastMsg.created_date));
      const techIdsToFetch = [...new Set([
        ...convs.filter(c => !c.isTechnician).map(c => c.technician_id),
        ...convs.filter(c => c.isTechnician && c.client_technician_id).map(c => c.client_technician_id)
      ])];
      if (techIdsToFetch.length > 0) {
        const techs = await Promise.all(techIdsToFetch.map(tid => base44.entities.Technician.get(tid).catch(() => null)));
        const techMap = {};
        techs.forEach(t => { if (t) techMap[t.id] = { name: t.name || t.nom || 'Technicien', photo: t.profile_photo || null }; });
        convs.forEach(c => {
          if (!c.isTechnician) {
            c.name = techMap[c.technician_id]?.name || 'Technicien';
            c.photo = techMap[c.technician_id]?.photo || null;
          } else {
            c.name = techMap[c.client_technician_id]?.name || c.name || 'Client';
            c.photo = techMap[c.client_technician_id]?.photo || null;
          }
        });
      }
      setConversations(convs);
      if (!firstLoadRef.current) {
        const lastSeen = localStorage.getItem('tektoo_messenger_last_seen') || new Date(0).toISOString();
        const unreadIds = new Set();
        convs.forEach(c => {
          const fromOtherParty = c.isTechnician ? !c.lastMsg?.from_technician : c.lastMsg?.from_technician;
          if (fromOtherParty && c.lastMsg && new Date(c.lastMsg.created_date) > new Date(lastSeen)) {
            unreadIds.add(c.id);
          }
        });
        setUnreadConvIds(unreadIds);
      }
      firstLoadRef.current = true;
    } catch (e) {
      console.error('FloatingMessenger load error', e);
    } finally {
      if (showLoading) setLoading(false);
      fetchLockRef.current = false;
    }
  };

  useEffect(() => {
    loadConversations.current();
    let unsub = () => {};
    try {
      unsub = base44.entities.ChatMessage.subscribe((event) => {
        const m = event.data;
        if (!m) return;
        const isTech = m.technician_id === techIdRef.current;
        const isClient = m.client_technician_id === techIdRef.current;
        if (!isTech && !isClient) return;
        if (getDeletedConvIds().has(m.conversation_id)) return;
        knownMessageIds.current.add(m.id);
        setConversations(prev => {
          const existing = prev.find(c => c.id === m.conversation_id);
          if (existing) {
            if (existing.messages.some(msg => msg.id === m.id)) return prev;
            const updated = { ...existing, messages: [...existing.messages, m], lastMsg: m };
            return [updated, ...prev.filter(c => c.id !== m.conversation_id)].sort((a, b) => new Date(b.lastMsg.created_date) - new Date(a.lastMsg.created_date));
          }
          return [{
            id: m.conversation_id,
            technician_id: m.technician_id,
            client_technician_id: m.client_technician_id,
            isTechnician: isTech,
            name: isTech ? (m.sender_name || 'Client') : 'Technicien',
            phone: isTech ? (m.sender_phone || '') : '',
            lastMsg: m,
            messages: [m]
          }, ...prev].sort((a, b) => new Date(b.lastMsg.created_date) - new Date(a.lastMsg.created_date));
        });
        const fromOtherParty = isTech ? !m.from_technician : m.from_technician;
        if (fromOtherParty && activeIdRef.current !== m.conversation_id) {
          setUnreadConvIds(prev => new Set([...prev, m.conversation_id]));
          playNotificationSound();
          if ('Notification' in window && Notification.permission === 'granted') {
            try {
              const n = new Notification('Nouveau message', { body: getMessagePreview(m), tag: `tektoo_msg_${m.conversation_id}` });
              n.onclick = () => { window.focus(); n.close(); setOpen(true); };
            } catch {}
          }
          if (navigator.vibrate) triggerVibrate(200);
        }
      });
    } catch (e) {
      console.warn('Messenger subscribe unavailable, using polling', e);
    }
    const poll = setInterval(() => { loadConversations.current(); }, 2000);
    const refetch = () => loadConversations.current();
    document.addEventListener('visibilitychange', refetch);
    window.addEventListener('focus', refetch);
    return () => { try { unsub(); } catch {} clearInterval(poll); document.removeEventListener('visibilitychange', refetch); window.removeEventListener('focus', refetch); };
  }, [techId]);

  useEffect(() => {
    if (open) { localStorage.setItem('tektoo_messenger_last_seen', new Date().toISOString()); loadConversations.current(); }
  }, [open]);

  useEffect(() => {
    const openConvId = searchParams.get('open_conv');
    if (!openConvId) return;
    const conv = conversations.find(c => c.id === openConvId);
    if (conv) {
      setOpen(true);
      openConv(openConvId);
      searchParams.delete('open_conv');
      setSearchParams(searchParams, { replace: true });
    }
  }, [searchParams, conversations]);

  const openConv = (id) => {
    setActiveConvId(id);
    setUnreadConvIds(prev => { const next = new Set(prev); next.delete(id); return next; });
  };

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [activeConv?.messages, activeConv]);

  const persistMessage = async (payload, offlinePreview) => {
    if (busy || !activeConv) return;
    setDraft('');
    setBusy(true);
    try {
      const msg = await base44.entities.ChatMessage.create({
        technician_id: activeConv.technician_id,
        conversation_id: activeConv.id,
        client_technician_id: activeConv.client_technician_id,
        sender_name: '',
        sender_phone: '',
        from_technician: activeConv.isTechnician,
        ...payload
      });
      setConversations(prev => prev.map(c =>
        c.id === activeConv.id
          ? { ...c, messages: c.messages.some(m => m.id === msg.id) ? c.messages : [...c.messages, msg], lastMsg: msg }
          : c
      ));
      loadConversations.current();
      const recipientId = activeConv.isTechnician ? activeConv.client_technician_id : activeConv.technician_id;
      notifyOfflineRecipient(recipientId, offlinePreview, activeConv.id, '');
      return true;
    } catch {
      if (payload.message_type !== 'audio') setDraft(payload.content || '');
      return false;
    } finally {
      setBusy(false);
    }
  };

  const sendText = async (content) => {
    if (!content.trim()) return;
    return persistMessage({
      content,
      message_type: 'text',
    }, content);
  };

  const sendAudio = async ({ audioUrl, durationMs, mimeType }) => {
    return persistMessage({
      content: '🎤 Message vocal',
      message_type: 'audio',
      audio_url: audioUrl,
      audio_duration_ms: durationMs,
      audio_mime_type: mimeType,
    }, '🎤 Message vocal');
  };

  const deleteConversation = async (convId) => {
    addDeletedConvId(convId);
    setConversations(prev => prev.filter(c => c.id !== convId));
    if (activeConvId === convId) setActiveConvId(null);
    try {
      await base44.functions.invoke('deleteConversation', {
        conversation_id: convId,
        deleted_by: techId
      });
    } catch (e) {
      console.error('deleteConversation error', e);
    }
  };

  const isOwn = (m) => activeConv?.isTechnician ? m.from_technician : !m.from_technician;

  const filteredConversations = conversations.filter(c => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return (c.name || '').toLowerCase().includes(q) || (c.lastMsg?.content || '').toLowerCase().includes(q);
  });

  return (
    <>
      {!open && (
        <button onClick={() => setOpen(true)} aria-label="Messagerie" className="fixed bottom-20 right-4 z-40 flex h-14 w-14 items-center justify-center overflow-hidden rounded-full bg-[#3A8E9C] text-white shadow-lg transition-colors hover:bg-[#2E7B88]">
          {myPhoto ? <img src={myPhoto} alt="Messagerie" className="h-full w-full object-cover" /> : <MessageSquare size={24} strokeWidth={2.2} />}
          {totalUnread > 0 && (
            <span className="badge-ring absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1 text-xs font-bold text-white">{totalUnread}</span>
          )}
        </button>
      )}

      {open && (
        <div className="fixed inset-x-0 bottom-[57px] z-50 sm:inset-x-auto sm:bottom-20 sm:right-4 sm:w-96" style={kb > 0 ? { bottom: `calc(57px + ${kb}px)` } : undefined}>
          <div className="flex flex-col border border-[#D3CCBE] bg-[#F3EFE7] shadow-2xl" style={{ maxHeight: '75vh' }}>
            <div className="flex items-center gap-2 bg-[#3A8E9C] px-4 py-3 text-white">
              {activeConv && (
                <button onClick={() => setActiveConvId(null)} className="flex h-8 w-8 items-center justify-center" aria-label="Retour"><ArrowLeft size={20} /></button>
              )}
              <span className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#F3EFE7]/20">
                {activeConv?.photo ? <img src={activeConv.photo} alt={activeConv.name} className="h-full w-full object-cover" /> : myPhoto ? <img src={myPhoto} alt="Moi" className="h-full w-full object-cover" /> : <MessageSquare size={16} />}
              </span>
              <div className="flex-1 min-w-0">
                {activeConv ? (
                  <Link to={`/explorer/${activeConv.isTechnician ? activeConv.client_technician_id : activeConv.technician_id}`} onClick={() => { setOpen(false); setActiveConvId(null); }} className="block truncate text-sm font-semibold underline-offset-2 hover:underline">{activeConv.name}</Link>
                ) : (
                  <div className="truncate text-sm font-semibold">Messagerie</div>
                )}
                {!activeConv && <div className="text-xs text-white/70">Vos conversations</div>}
                {activeConv?.phone && <div className="truncate text-xs text-white/70">{activeConv.phone}</div>}
              </div>
              {activeConv && (
                <button onClick={() => deleteConversation(activeConv.id)} className="flex h-8 w-8 items-center justify-center text-white/90 hover:text-white" aria-label="Supprimer la conversation" title="Supprimer la conversation"><Trash2 size={18} /></button>
              )}
              <button onClick={() => loadConversations.current(true)} className="flex h-8 w-8 items-center justify-center text-white/90 hover:text-white" aria-label="Rafraîchir"><RefreshCw size={16} /></button>
              <button onClick={() => { setOpen(false); setActiveConvId(null); }} className="flex h-8 w-8 items-center justify-center text-white/90 hover:text-white" aria-label="Fermer"><X size={20} /></button>
            </div>

            {activeConv ? (
              <>
                <div ref={scrollRef} className="scroll-pane flex-1 overflow-y-auto bg-[#E9E3D7] p-3 grid gap-2 content-start" style={{ minHeight: '200px' }}>
                  {activeConv.messages.map(m => (
                    <div key={m.id} className={`flex ${isOwn(m) ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[78%] rounded-2xl px-3 py-2 text-sm leading-snug ${isOwn(m) ? 'bg-[#3A8E9C] text-white' : 'bg-[#F3EFE7] text-slate-900 border border-[#D3CCBE]'}`}>
                        <ChatMessageContent message={m} />
                      </div>
                    </div>
                  ))}
                </div>
                <ChatComposer
                  draft={draft}
                  onDraftChange={setDraft}
                  onSendText={sendText}
                  onSendAudio={sendAudio}
                  busy={busy}
                />
              </>
            ) : (
              <>
              <div className="flex items-center gap-2 border-b border-[#D3CCBE] px-3 py-2">
                <Search size={15} className="text-slate-400" />
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher une conversation…" className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-slate-400" />
                {search && <button onClick={() => setSearch('')} className="text-slate-400 hover:text-slate-600" aria-label="Effacer"><X size={15} /></button>}
              </div>
              <div className="scroll-pane flex-1 overflow-y-auto p-3" style={{ minHeight: '200px' }}>
                {loading ? (
                  <div className="flex items-center gap-2 text-sm text-slate-500"><Loader2 size={16} className="animate-spin" />Chargement…</div>
                ) : filteredConversations.length === 0 ? (
                  <div className="flex flex-col items-center gap-3 py-8 text-center text-sm text-slate-500">
                    <span className="text-base font-semibold text-slate-900">Vide</span>
                    <p className="max-w-[260px] leading-relaxed">Pour entamer une conversation, rendez-vous sur le profil d'un technicien.</p>
                  </div>
                ) : (
                  <div className="grid gap-2">
                    {filteredConversations.map(c => (
                      <div key={c.id} className="flex items-center gap-2 border border-[#D3CCBE] bg-[#F3EFE7] pr-2 transition-colors hover:bg-[#E9E3D7]">
                        <button onClick={() => openConv(c.id)} className="flex min-w-0 flex-1 items-center gap-3 px-3 py-3 text-left">
                          <span className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#3A8E9C]/15 text-[#3A8E9C]">{c.photo ? <img src={c.photo} alt={c.name} className="h-full w-full object-cover" /> : <MessageSquare size={18} />}{unreadConvIds.has(c.id) && <span className="badge-ring absolute -right-0.5 -top-0.5 flex h-3.5 w-3.5 items-center justify-center rounded-full border-2 border-[#F3EFE7] bg-red-500" />}</span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-sm font-semibold">{c.name}</span>
                            <span className="block truncate text-xs text-slate-500">{(c.isTechnician ? c.lastMsg?.from_technician : !c.lastMsg?.from_technician) ? 'Vous : ' : ''}{getMessagePreview(c.lastMsg)}</span>
                          </span>
                          {c.phone && <span className="shrink-0 text-xs text-slate-500">{c.phone}</span>}
                        </button>
                        <div className="flex shrink-0 pr-1">
                          <button onClick={() => deleteConversation(c.id)} aria-label="Supprimer la conversation" title="Supprimer la conversation" className="flex h-9 w-9 items-center justify-center rounded-full bg-red-500/10 text-red-500 transition-colors hover:bg-red-500 hover:text-white"><Trash2 size={17} /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}