import React, { useState } from 'react';
import { MapPin, BriefcaseBusiness, Check, FileText, Video, Award, Star, Images, Play } from 'lucide-react';
import { trades, tradeLabel, DEFAULT_AVATAR } from '@/components/directory/catalog';
import ZoomableImage from '@/components/directory/ZoomableImage';
import ProfileMediaViewer from '@/components/directory/ProfileMediaViewer';
import { getProfileMedia } from '@/components/directory/profileMedia';
import { isProActive } from '@/lib/proStatus';
import { proTheme, profileBadge } from '@/lib/proTheme';

const CardTitle = ({ index, label, Icon, color }) => (
  <div className="absolute left-1/2 top-0 z-10 flex -translate-x-1/2 -translate-y-1/2 items-center gap-1.5 whitespace-nowrap rounded-full border bg-white px-3 py-1 shadow-sm" style={{ borderColor: color || '#3A8E9C' }}>
    <span className="micro" style={{ color: color || '#3A8E9C' }}>{index} · {label}</span>
    <Icon size={14} style={{ color: color || '#3A8E9C' }} />
  </div>
);

export default function ProfileCards({ t }) {
  const trade = trades.find(x => x.id === t.trade);
  const [viewerOpen, setViewerOpen] = useState(false);
  const [viewerIndex, setViewerIndex] = useState(0);
  const illustrations = [t.illustration_1, t.illustration_2, t.illustration_3, t.illustration_4].filter(Boolean);
  const album1 = (t.pro_album_1 || []).filter(Boolean);
  const album2 = (t.pro_album_2 || []).filter(Boolean);
  const proVideos = (t.pro_videos || []).filter(Boolean);
  const pro = proTheme(t);
  const accent = pro?.primary;
  const isPro = isProActive(t);
  const media = getProfileMedia(t);
  const hasImages = media.some((item) => item.type === 'image');
  const hasVideos = media.some((item) => item.type === 'video');

  const openViewerAt = (src) => {
    const nextIndex = media.findIndex((item) => item.src === src);
    setViewerIndex(nextIndex >= 0 ? nextIndex : 0);
    setViewerOpen(true);
  };

  return (
    <>
      <div className="mb-3 flex items-center justify-end">
        <button
          type="button"
          onClick={() => {
            setViewerIndex(0);
            setViewerOpen(true);
          }}
          disabled={!media.length}
          className={`${pro ? 'pro-outline-btn' : 'rounded-full border border-[#3A8E9C] px-4 py-2 text-sm font-semibold text-[#3A8E9C] transition-colors hover:bg-[#3A8E9C] hover:text-white'} ${!media.length ? 'cursor-not-allowed opacity-50 hover:bg-transparent hover:text-[#3A8E9C]' : ''}`}
        >
          {!media.length ? 'Aucun média disponible' : hasImages && hasVideos ? 'Voir les photos et vidéos' : 'Voir les médias'}
        </button>
      </div>
      <div className="flex items-start gap-4 overflow-x-auto pb-2 pt-6 snap-x snap-mandatory">
        {/* Carte 1 — Identité */}
        <article className="relative w-auto max-w-[92%] min-w-[280px] snap-center shrink-0 rounded-2xl border bg-white shadow-sm" style={{ borderColor: pro?.border || '#D3CCBE' }}>
          <CardTitle index="01" label="IDENTITÉ" Icon={Award} color={accent} />
          <div className="h-7 rounded-t-2xl bg-gradient-to-r from-[#3A8E9C] to-[#3A8E9C]" style={accent ? { background: `linear-gradient(to right, ${accent}, ${accent})` } : undefined} />
          <div className="px-5 pb-4">
            <div className="-mt-5 flex flex-col items-center text-center">
              {t.profile_photo ? (
                <ZoomableImage src={t.profile_photo} alt={`Photo de ${t.name}`} className="h-28 w-28 rounded-full border-4 border-white object-cover shadow-md" wrapperClassName="rounded-full" onOpen={() => openViewerAt(t.profile_photo)} />
              ) : (
                <img src={DEFAULT_AVATAR} alt={`Avatar par défaut — ${t.name}`} className="h-28 w-28 rounded-full border-4 border-white object-cover shadow-md" />
              )}
              <h3 className="mt-2 text-xl font-semibold tracking-tight text-slate-900">{t.name}</h3>
              <div className="mt-0.5 text-sm font-semibold uppercase tracking-wider text-[#3A8E9C]" style={accent ? { color: accent } : undefined}>{tradeLabel(t)}</div>
              {pro && <span className="mt-1 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white" style={{ backgroundColor: accent }}>{profileBadge(t)}</span>}
            </div>
            <div className="mt-3 grid gap-1.5 text-sm">
              <span className="flex items-center gap-2 rounded-full bg-[#F3EFE7] px-3 py-1.5 text-slate-700"><BriefcaseBusiness size={15} style={{ color: accent || '#3A8E9C' }} />{t.experience || 0} ans d'expérience{t.age ? ` · ${t.age} ans` : ''}</span>
              <span className="flex items-center gap-2 rounded-full bg-[#F3EFE7] px-3 py-1.5 text-slate-700"><MapPin size={15} style={{ color: accent || '#3A8E9C' }} />{t.city}{t.quartier ? ` · ${t.quartier}` : ''}</span>
              <span className={`flex items-center gap-2 rounded-full px-3 py-1.5 font-semibold ${t.available ? 'bg-[#ECFDF5] text-emerald-600' : 'bg-[#F3EFE7] text-slate-500'}`}><span className="status-dot" />{t.available ? 'Disponible' : 'Sur rendez-vous'}</span>
            </div>
          </div>
        </article>

        {/* Carte 2 — Profession */}
        <article className="relative w-auto max-w-[92%] min-w-[280px] snap-center shrink-0 rounded-2xl border bg-white shadow-sm" style={{ borderColor: pro?.border || '#D3CCBE' }}>
          <CardTitle index="02" label="PROFESSION" Icon={BriefcaseBusiness} color={accent} />
          <div className="h-7 rounded-t-2xl bg-gradient-to-r from-[#3A8E9C] to-[#3A8E9C]" style={accent ? { background: `linear-gradient(to right, ${accent}, ${accent})` } : undefined} />
          <div className="px-5 pb-4">
            <h3 className="mt-2 text-lg font-semibold tracking-tight text-slate-900">Le savoir-faire</h3>
            <p className="mt-2 line-clamp-3 break-words text-sm leading-relaxed text-slate-600">{t.description}</p>
            {t.demo && trade?.services?.length > 0 && (
              <div className="mt-4">
                <div className="micro mb-2 text-slate-500">EXEMPLES DE PRESTATIONS</div>
                <div className="grid gap-2">
                  {trade.services.map(s => <span key={s} className="flex items-center gap-2 rounded-full bg-[#F3EFE7] px-3 py-1.5 text-sm text-slate-700"><Check size={14} style={{ color: accent || '#3A8E9C' }} />{s}</span>)}
                </div>
              </div>
            )}
            {t.cv_url && (
              <a href={t.cv_url} target="_blank" rel="noreferrer" className="mt-4 flex items-center justify-center gap-2 rounded-full border border-[#D3CCBE] bg-[#E9E3D7] px-4 py-3 text-sm font-semibold transition-colors hover:bg-[#D3CCBE]" style={{ color: accent || '#3A8E9C' }}>
                <FileText size={17} />Voir le CV (PDF)
              </a>
            )}
          </div>
        </article>

        {/* Carte 3 — Réalisation */}
        <article className="relative w-auto max-w-[92%] min-w-[280px] snap-center shrink-0 rounded-2xl border bg-white shadow-sm" style={{ borderColor: pro?.border || '#D3CCBE' }}>
          <CardTitle index="03" label="RÉALISATION" Icon={Video} color={accent} />
          <div className="h-7 rounded-t-2xl bg-gradient-to-r from-[#3A8E9C] to-[#3A8E9C]" style={accent ? { background: `linear-gradient(to right, ${accent}, ${accent})` } : undefined} />
          <div className="px-5 pb-4">
            {illustrations.length > 0 ? (
              <div className="mt-2 grid grid-cols-2 gap-2">
                {illustrations.map((src, i) => (
                  <ZoomableImage key={i} src={src} alt={`Illustration ${i + 1} — ${t.name}`} className="h-28 w-full rounded-lg border border-[#D3CCBE] object-cover" wrapperClassName="overflow-hidden rounded-lg" onOpen={() => openViewerAt(src)} />
                ))}
              </div>
            ) : (
              <p className="mt-3 text-sm text-slate-500">Aucune illustration publiée.</p>
            )}
            {t.presentation_video && (
              <div className="mt-4">
                <div className="micro mb-2 text-slate-500">VIDÉO STATUT</div>
                <button type="button" onClick={() => openViewerAt(t.presentation_video)} className={`${pro ? 'pro-outline-btn' : 'flex items-center justify-center gap-2 rounded-full border border-[#3A8E9C] px-4 py-2.5 text-sm font-semibold text-[#3A8E9C] transition-colors hover:bg-[#3A8E9C] hover:text-white'} w-full`}>
                  <Video size={16} />Lire la vidéo statut
                </button>
              </div>
            )}
          </div>
        </article>

        {isPro && (
          <article className="relative w-auto max-w-[92%] min-w-[280px] snap-center shrink-0 rounded-2xl border bg-white shadow-sm" style={{ borderColor: `${accent}66` }}>
            <CardTitle index="PRO" label="ESPACE PRO" Icon={Star} color={accent} />
            <div className="h-10 rounded-t-2xl" style={{ background: `linear-gradient(to right, ${accent}, ${accent})` }} />
            <div className="px-5 pb-5">
              <div className="mt-3 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider" style={{ color: accent }}><Star size={13} fill="currentColor" />Contenu Pro</div>

              <div className="mt-3">
                <div className="micro mb-2 flex items-center gap-1.5 text-slate-500"><Images size={13} />ALBUM 1</div>
                <div className="grid grid-cols-2 gap-2">
                  {album1.length > 0
                    ? album1.map((src, i) => <ZoomableImage key={i} src={src} alt={`Album 1 - ${i + 1}`} className="h-28 w-full rounded-lg border border-[#D3CCBE] object-cover" wrapperClassName="overflow-hidden rounded-lg" onOpen={() => openViewerAt(src)} />)
                    : Array.from({ length: 2 }).map((_, i) => <div key={i} className="flex h-28 w-full items-center justify-center rounded-lg border border-dashed bg-[#F3EFE7]" style={{ borderColor: `${accent}55` }}><Images size={18} className="text-slate-300" /></div>)}
                </div>
              </div>

              <div className="mt-4">
                <div className="micro mb-2 flex items-center gap-1.5 text-slate-500"><Images size={13} />ALBUM 2</div>
                <div className="grid grid-cols-2 gap-2">
                  {album2.length > 0
                    ? album2.map((src, i) => <ZoomableImage key={i} src={src} alt={`Album 2 - ${i + 1}`} className="h-28 w-full rounded-lg border border-[#D3CCBE] object-cover" wrapperClassName="overflow-hidden rounded-lg" onOpen={() => openViewerAt(src)} />)
                    : Array.from({ length: 2 }).map((_, i) => <div key={i} className="flex h-28 w-full items-center justify-center rounded-lg border border-dashed bg-[#F3EFE7]" style={{ borderColor: `${accent}55` }}><Images size={18} className="text-slate-300" /></div>)}
                </div>
              </div>

              <div className="mt-4">
                <div className="micro mb-2 text-slate-500">DOSSIER VIDÉOS</div>
                {proVideos.length > 0 ? (
                  <div className="grid gap-3">
                    {proVideos.map((src, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => openViewerAt(src)}
                        aria-label={`Voir la vidéo ${i + 1}`}
                        className="relative overflow-hidden rounded-lg border border-[#D3CCBE] bg-black"
                      >
                        <video src={src.split('#')[0]} playsInline muted preload="metadata" aria-hidden="true" tabIndex={-1} className="h-44 w-full object-contain" />
                        <span className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/20">
                          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-white/20 text-white backdrop-blur-sm">
                            <Play size={18} className="fill-current" />
                          </span>
                        </span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="flex h-44 w-full items-center justify-center rounded-lg border border-dashed bg-[#F3EFE7]" style={{ borderColor: `${accent}55` }}><Video size={22} className="text-slate-300" /></div>
                )}
              </div>
            </div>
          </article>
        )}
      </div>
      <ProfileMediaViewer open={viewerOpen} onOpenChange={setViewerOpen} media={media} initialIndex={viewerIndex} profileName={t.name} />
    </>
  );
}