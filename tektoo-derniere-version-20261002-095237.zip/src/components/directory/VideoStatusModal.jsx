import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import TrimmedVideo from '@/components/directory/TrimmedVideo';

export default function VideoStatusModal({ video, name, onClose }) {
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [onClose]);

  if (!video) return null;
  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-black/95" role="dialog" aria-modal="true" aria-label={`Statut vidéo de ${name}`}>
      <div className="flex items-center justify-end px-4 py-3 text-white">
        <button type="button" onClick={onClose} aria-label="Fermer" className="flex h-11 w-11 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"><X size={20}/></button>
      </div>
      <div className="flex flex-1 items-center justify-center p-2">
        <TrimmedVideo src={video} autoPlay className="max-h-full max-w-full object-contain"/>
      </div>
    </div>
  );
}