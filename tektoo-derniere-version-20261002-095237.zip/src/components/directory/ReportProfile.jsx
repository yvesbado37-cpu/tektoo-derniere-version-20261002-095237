import React, { useState } from 'react';
import { Flag, Loader2, Check } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const reasons = ['Profil fictif / faux compte', 'Coordonnées incorrectes', 'Contenu inapproprié', 'Autre'];

export default function ReportProfile({ technicianId }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState(reasons[0]);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  const submit = async e => {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      await base44.entities.Report.create({
        technician_id: technicianId,
        reason,
        reporter_name: name.trim() || undefined
      });
      setDone(true);
    } catch (err) {
      setError("Le signalement n'a pas pu être envoyé.");
    } finally { setBusy(false); }
  };

  if (done) return <p className="flex items-center gap-2 text-sm text-emerald-600"><Check size={15}/>Signalement envoyé. Merci, notre équipe va vérifier ce profil.</p>;

  return (
    <div className="border-t border-[#D3CCBE] pt-4">
      {!open ? (
        <button onClick={() => setOpen(true)} className="flex items-center gap-2 text-sm text-slate-500 underline underline-offset-4 hover:text-[#3A8E9C]"><Flag size={15}/>Signaler ce profil</button>
      ) : (
        <form onSubmit={submit} className="grid gap-2">
          <span className="text-sm font-semibold text-slate-700">Signaler ce profil</span>
          <select value={reason} onChange={e => setReason(e.target.value)} className="rounded-lg border border-[#D3CCBE] bg-[#E9E3D7] px-3 py-2 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]">
            {reasons.map(r => <option key={r}>{r}</option>)}
          </select>
          <input maxLength={50} placeholder="Votre nom (facultatif)" value={name} onChange={e => setName(e.target.value)} className="border border-[#D3CCBE] bg-[#E9E3D7] rounded-lg px-3 py-2 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]"/>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <div className="flex items-center gap-3">
            <button type="submit" className="primary-button" disabled={busy}>{busy ? <><Loader2 size={16} className="animate-spin"/>Envoi…</> : 'Envoyer'}</button>
            <button type="button" onClick={() => setOpen(false)} className="text-sm text-slate-500 underline underline-offset-4">Annuler</button>
          </div>
        </form>
      )}
    </div>
  );
}