import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Share2, Eye, LogIn, LogOut, UserCircle, Facebook, Twitter, Instagram, MessageCircle, Link2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getSession, clearSession } from '@/lib/technicianSession';
import { useAuth } from '@/lib/AuthContext';
import { playNotificationSound, triggerVibrate } from '@/lib/buttonSound';

const SITE_URL = 'https://www.tektoo.org';
const SITE_TEXT = 'tektoo — la solution à tout. L\'annuaire des techniciens près de chez vous.';

const shareOptions = [
  { label: 'Facebook', icon: Facebook, color: '#1877F2', url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(SITE_URL)}` },
  { label: 'Twitter / X', icon: Twitter, color: '#3A8E9C', url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(SITE_TEXT)}&url=${encodeURIComponent(SITE_URL)}` },
  { label: 'WhatsApp', icon: MessageCircle, color: '#10B981', url: `https://wa.me/?text=${encodeURIComponent(SITE_TEXT + ' ' + SITE_URL)}` },
  { label: 'Instagram', icon: Instagram, color: '#E4405F', url: `https://www.instagram.com/` },
];

export default function HeaderMenu({ compact }) {
  const { user, logout: authLogout } = useAuth();
  const [session, setSession] = useState(getSession());
  const [open, setOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [views, setViews] = useState(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const sync = () => setSession(getSession());
    window.addEventListener('tektoo-session', sync);
    window.addEventListener('storage', sync);
    return () => { window.removeEventListener('tektoo-session', sync); window.removeEventListener('storage', sync); };
  }, []);

  useEffect(() => {
    if (!session) { setViews(null); return; }
    let done = false;
    const prev = { current: null };
    const load = () => {
      base44.entities.ProfileView.filter({ technician_id: session.technicianId })
        .then(list => {
          if (done) return;
          const start = new Date(); start.setHours(0, 0, 0, 0);
          const todayViews = list.filter(v => new Date(v.created_date) >= start).length;
          if (prev.current !== null && todayViews > prev.current) {
            const diff = todayViews - prev.current;
            playNotificationSound();
            if ('Notification' in window && Notification.permission === 'granted') {
              try {
                const n = new Notification('Nouvelle visite de profil', {
                  body: `Votre profil a été consulté par ${diff} nouvelle${diff > 1 ? 's personne' : ' personne'}.`,
                  tag: 'tektoo_profile_view'
                });
                n.onclick = () => { window.focus(); n.close(); };
              } catch {}
            }
            if (navigator.vibrate) triggerVibrate(200);
          }
          prev.current = todayViews;
          setViews(todayViews);
        })
        .catch(() => { if (!done) setViews(0); });
    };
    load();
    const t = setInterval(load, 30000);
    return () => { done = true; clearInterval(t); };
  }, [session]);

  const logout = () => { clearSession(); authLogout('/'); setOpen(false); };

  const nativeShare = async () => {
    if (navigator.share) {
      try { await navigator.share({ title: 'tektoo', text: SITE_TEXT, url: SITE_URL }); } catch { /* cancelled */ }
    } else { setShareOpen(true); }
  };

  const copyLink = async () => {
    try { await navigator.clipboard.writeText(SITE_URL); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch {}
  };

  const share = (url) => { window.open(url, '_blank', 'noopener,noreferrer'); };

  const size = compact ? 'h-8 w-8' : 'min-h-[44px] min-w-[44px]';

  return (
    <>
      <div className="relative shrink-0">
        <button
          onClick={() => setOpen(o => !o)}
          aria-label="Menu"
          aria-expanded={open}
          className={`no-sound flex ${size} items-center justify-center rounded-full border border-[#D3CCBE] text-[#2E2A24] transition-colors hover:bg-[#E9E3D7]`}
        >
          {open ? <X size={compact ? 16 : 20} strokeWidth={2.2} /> : <Menu size={compact ? 16 : 20} strokeWidth={2.2} />}
        </button>

        {open && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} aria-hidden="true" />
            <div className="absolute right-0 top-full z-50 mt-2 min-w-[230px] border border-[#D3CCBE] bg-[#F3EFE7] shadow-lg">
              {session ? (
                <>
                  <Link to="/mon-compte" onClick={() => setOpen(false)} className="flex min-h-[44px] items-center gap-2.5 px-4 py-2.5 text-sm font-semibold text-[#2E2A24] transition-colors hover:bg-[#E9E3D7]">
                    <UserCircle size={16} strokeWidth={2.2} className="text-[#3A8E9C]" />
                    <span>Mon compte</span>
                  </Link>
                  <div className="flex min-h-[44px] items-center justify-between gap-2.5 border-t border-[#D3CCBE] px-4 py-2.5 text-sm">
                    <span className="flex items-center gap-2.5 font-semibold text-[#2E2A24]">
                      <Eye size={16} strokeWidth={2.2} className="text-[#3A8E9C]" />
                      <span>Visites du jour</span>
                    </span>
                    <span className="rounded-full bg-[#3A8E9C] px-2.5 py-0.5 text-sm font-bold text-white">{views ?? '—'}</span>
                  </div>
                </>
              ) : (
                <Link to="/connexion" onClick={() => setOpen(false)} className="flex min-h-[44px] items-center gap-2.5 px-4 py-2.5 text-sm font-semibold text-[#2E2A24] transition-colors hover:bg-[#E9E3D7]">
                  <LogIn size={16} strokeWidth={2.2} className="text-[#3A8E9C]" />
                  <span>Se connecter</span>
                </Link>
              )}
              <button onClick={nativeShare} className="flex min-h-[44px] w-full items-center gap-2.5 border-t border-[#D3CCBE] px-4 py-2.5 text-left text-sm font-semibold text-[#2E2A24] transition-colors hover:bg-[#E9E3D7]">
                <Share2 size={16} strokeWidth={2.2} className="text-[#3A8E9C]" />
                <span>Partager tektoo</span>
              </button>
              {session && (
                <button onClick={logout} className="flex min-h-[44px] w-full items-center gap-2.5 border-t border-[#D3CCBE] px-4 py-2.5 text-left text-sm font-semibold text-[#2E2A24] transition-colors hover:bg-[#E9E3D7]">
                  <LogOut size={16} strokeWidth={2.2} className="text-[#3A8E9C]" />
                  <span>Déconnexion</span>
                </button>
              )}
            </div>
          </>
        )}
      </div>

      {shareOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 sm:items-center" onClick={() => setShareOpen(false)}>
          <div className="glass w-full max-w-sm rounded-t-2xl p-5 sm:rounded-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-[#D3CCBE] pb-3">
              <h3 className="text-base font-semibold text-slate-900">Partager tektoo</h3>
              <button aria-label="Fermer" onClick={() => setShareOpen(false)} className="flex h-9 w-9 items-center justify-center text-slate-500 hover:text-slate-900"><X size={18} /></button>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3">
              {shareOptions.map(o => (
                <button key={o.label} onClick={() => share(o.url)} className="glass glass-hover flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-slate-700">
                  <o.icon size={18} style={{ color: o.color }} strokeWidth={2} />
                  <span>{o.label}</span>
                </button>
              ))}
            </div>
            <button onClick={copyLink} className="glass glass-hover mt-3 flex w-full items-center justify-center gap-2 rounded-xl px-3 py-3 text-sm font-semibold text-slate-700">
              <Link2 size={16} />
              {copied ? 'Lien copié !' : 'Copier le lien'}
            </button>
          </div>
        </div>
      )}
    </>
  );
}