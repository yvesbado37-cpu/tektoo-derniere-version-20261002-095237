import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Component, Settings, Star } from 'lucide-react';
import { isMuted } from '@/lib/buttonSound';
import NotificationSettings from '@/components/directory/NotificationSettings';
import HeaderMenu from '@/components/directory/HeaderMenu';
export default function Header() {
  const { pathname } = useLocation();
  const isExplorer = pathname.startsWith('/explorer');
  const [soundMuted, setSoundMuted] = useState(isMuted());
  const [settingsOpen, setSettingsOpen] = useState(false);
  useEffect(() => {
    const sync = () => setSoundMuted(isMuted());
    window.addEventListener('tektoo-sound-muted', sync);
    window.addEventListener('tektoo-sound-settings', sync);
    return () => { window.removeEventListener('tektoo-sound-muted', sync); window.removeEventListener('tektoo-sound-settings', sync); };
  }, []);
  return <>
  <header className="site-header"><div className="shell">
    <div className={`header-inner ${isExplorer ? '!h-[50px]' : ''}`}>
      <Link to="/" className={`brand ${isExplorer ? 'text-[1.3rem]' : 'text-[2.1rem]'}`} aria-label="tektoo, accueil"><Component size={isExplorer ? 22 : 33} className="text-[#3A8E9C]" strokeWidth={2.5}/>{!isExplorer && <span>tektoo<span className="text-[#3A8E9C]">.</span></span>}
        <span className="inline-flex h-[18px] w-[27px] shrink-0 overflow-hidden rounded-[2px] border border-[#D3CCBE] align-middle" aria-label="Burkina Faso" title="Fait au Burkina Faso">
          <svg viewBox="0 0 30 20" className="h-full w-full" preserveAspectRatio="none" aria-hidden="true">
            <rect width="30" height="10" fill="#EF2B2D"/>
            <rect y="10" width="30" height="10" fill="#009E49"/>
            <polygon points="15,4 16.18,7.65 20,7.65 16.91,9.95 18.09,13.6 15,11.3 11.91,13.6 13.09,9.95 10,7.65 13.82,7.65" fill="#FCD116"/>
          </svg>
        </span>
      </Link>
      <span className="hidden min-w-0 flex-1 truncate text-[1.5rem] font-bold text-slate-500 sm:block">la solution à tout</span>
      <span className="hidden h-6 w-px bg-[#D3CCBE] sm:block"/>
      <p className="hidden text-[11px] font-medium leading-tight tracking-wide text-[#675F54] sm:block">l'annuaire des techniciens<br/>près de chez vous</p>
      <button type="button" onClick={() => setSettingsOpen(true)} aria-label="Réglages des notifications" title="Réglages des notifications" className={`no-sound relative flex shrink-0 items-center justify-center rounded-full border border-[#D3CCBE] text-[#2E2A24] transition-colors hover:bg-[#E9E3D7] ${isExplorer ? 'h-8 w-8' : 'min-h-[44px] min-w-[44px]'}`}>
        <Settings size={isExplorer ? 15 : 18} strokeWidth={2.2}/>
        {soundMuted && <span className="absolute -right-0.5 -top-0.5 flex h-2.5 w-2.5 items-center justify-center rounded-full bg-red-500" />}
      </button>
      <button type="button" onClick={() => window.dispatchEvent(new CustomEvent('tektoo-open-pro'))} aria-label="Découvrir le compte Pro" title="Avantages du compte Pro" className="no-sound flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1.5 text-xs font-semibold text-white transition-transform active:scale-95" style={{ backgroundColor: '#C2792E' }}>
        <Star size={13} fill="currentColor" />Pro
      </button>
      <HeaderMenu compact={isExplorer} />
    </div>
  </div></header>
  <NotificationSettings open={settingsOpen} onClose={() => setSettingsOpen(false)} />
  </>;
}