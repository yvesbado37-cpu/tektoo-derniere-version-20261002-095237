import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, MapPin, BriefcaseBusiness, Video } from 'lucide-react';
import { trades, tradeLabel, DEFAULT_AVATAR } from '@/components/directory/catalog';
import VideoStatusModal from '@/components/directory/VideoStatusModal';
import ZoomableImage from '@/components/directory/ZoomableImage';
import { proTheme, profileBadge } from '@/lib/proTheme';

export default function TechnicianCard({ technician: t, onOpen }) {
  const trade = trades.find(x => x.id === t.trade);
  const [showVideo, setShowVideo] = useState(false);
  const pro = proTheme(t);
  const accent = pro?.primary;
  return (
    <motion.article
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-30px' }}
      transition={{ duration: 0.45, ease: [0.34, 1.56, 0.64, 1] }}
      className={`w-full max-w-[320px] overflow-hidden rounded-2xl border bg-white shadow-sm ${profileBadge(t) === 'Formateur' ? 'trainer-profile' : ''}`}
      style={{ borderColor: pro?.border || undefined }}
      data-record-id={t.id}
    >
      <div className="h-12 bg-gradient-to-r from-[#3A8E9C] to-[#3A8E9C]" style={accent ? { background: `linear-gradient(to right, ${accent}, ${accent})` } : undefined} />
      <div className="px-5 pb-4">
        <div className="-mt-8 flex flex-col items-center text-center">
          {t.profile_photo || t.image ? (
            <ZoomableImage src={t.profile_photo || t.image} alt={`${trade?.short} — ${t.name}`} className="h-48 w-48 rounded-full border-4 border-white object-cover shadow-md" wrapperClassName="rounded-full" />
          ) : (
            <img src={DEFAULT_AVATAR} alt={`Avatar par défaut — ${t.name}`} className="h-48 w-48 rounded-full border-4 border-white object-cover shadow-md" />
          )}
          <h3 className="mt-2 text-xl font-semibold tracking-tight text-slate-900">{t.name}</h3>
          <div className="mt-0.5 text-sm font-semibold uppercase tracking-wider text-[#3A8E9C]" style={accent ? { color: accent } : undefined}>{tradeLabel(t)}</div>
          {pro && <span className="mt-1 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white" style={{ backgroundColor: accent }}>{profileBadge(t)}</span>}
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-center gap-2 text-xs">
          <span className="flex items-center gap-1.5 rounded-full bg-[#F3EFE7] px-3 py-1.5 text-slate-600"><MapPin size={13} />{t.city}{t.quartier ? ` · ${t.quartier}` : ''}</span>
          <span className="flex items-center gap-1.5 rounded-full bg-[#F3EFE7] px-3 py-1.5 text-slate-600"><BriefcaseBusiness size={13} />{t.experience || 0} ans</span>
          <span className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 font-semibold ${t.available ? 'bg-[#ECFDF5] text-emerald-600' : 'bg-[#F3EFE7] text-slate-500'}`}><span className="status-dot" />{t.available ? 'Disponible' : 'RDV'}</span>
        </div>
        <p className="mt-3 line-clamp-1 text-sm leading-relaxed text-slate-500">{t.description}</p>
        <button className={`${pro ? 'profile-button-pro' : 'profile-button'} mt-3`} onClick={() => onOpen(t)}>Voir le profil <ArrowUpRight size={16} /></button>
        {t.presentation_video && (
          <button type="button" onClick={() => setShowVideo(true)} className={`${pro ? 'pro-outline-btn' : 'flex w-full items-center justify-center gap-2 rounded-full border border-[#3A8E9C] px-4 py-2.5 text-sm font-semibold text-[#3A8E9C] transition-colors hover:bg-[#3A8E9C] hover:text-white'} mt-2 w-full`}>
            <Video size={16} />Statut vidéo
          </button>
        )}
      </div>
      {showVideo && <VideoStatusModal video={t.presentation_video} name={t.name} onClose={() => setShowVideo(false)} />}
    </motion.article>
  );
}