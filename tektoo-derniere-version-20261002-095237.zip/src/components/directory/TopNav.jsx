import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, LayoutGrid, Search, Info, MessageSquare, GraduationCap } from 'lucide-react';

const tabs = [
  { label: 'Accueil', root: '/', icon: Home },
  { label: 'Domaines', root: '/domaines', icon: LayoutGrid },
  { label: 'Explorer', root: '/explorer', icon: Search },
  { label: 'Forum', root: '/forum', icon: MessageSquare },
  { label: 'Formation', root: '/formation', icon: GraduationCap },
  { label: 'À propos', root: '/a-propos', icon: Info },
];

export default function TopNav() {
  const { pathname } = useLocation();
  const isActive = (t) => pathname === t.root || pathname.startsWith(t.root + '/');
  return (
    <nav className="border-b border-[#D3CCBE] bg-[#F3EFE7]" aria-label="Navigation principale">
      <div className="no-scrollbar flex gap-1.5 overflow-x-auto px-3 py-2">
        {tabs.map(t => {
          const active = isActive(t);
          const Icon = t.icon;
          return (
            <Link
              key={t.root}
              to={t.root}
              className={`flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-3.5 py-1.5 text-sm font-semibold transition-colors ${active ? 'bg-[#3A8E9C] text-white shadow-sm' : 'text-[#675F54] hover:bg-[#E9E3D7]'}`}
              aria-current={active ? 'page' : undefined}
            >
              <Icon size={15} strokeWidth={active ? 2.4 : 1.8} />
              <span>{t.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}