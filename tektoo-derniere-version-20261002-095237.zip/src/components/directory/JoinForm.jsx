import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowUpRight, CheckCircle2, Loader2, Upload, X, MessageCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { setSession } from '@/lib/technicianSession';
import { trades, quartiers, quartiersBobo } from '@/components/directory/catalog';
import VideoInput from '@/components/directory/VideoInput';
import PdfInput from '@/components/directory/PdfInput';

const initial = {
  nom: '', prenoms: '', trade: 'electricite', custom_trade: '', city: 'Ouagadougou', custom_city: '', quartier: '',
  age: '', whatsapp: '', description: '', experience: 0, available: true, password: '', passwordConfirm: '',
  profile_photo: '', illustration_1: '', illustration_2: '', illustration_3: '', illustration_4: '', presentation_video: '', cv_url: ''
};

function PhotoInput({ label, value, onChange }) {
  const [busy, setBusy] = useState(false);
  const handle = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      onChange(file_url);
    } finally { setBusy(false); }
  };
  return (
    <label>
      {label}
      <div className="relative flex h-32 items-center justify-center overflow-hidden rounded-xl border border-dashed border-[#D3CCBE] bg-white shadow-sm">
        {value ? (
          <>
            <img src={value} alt={label} className="absolute inset-0 h-full w-full object-cover"/>
            <button type="button" onClick={(e) => { e.preventDefault(); onChange(''); }} className="absolute right-2 top-2 bg-[#F3EFE7]/90 p-1"><X size={14}/></button>
          </>
        ) : (
          <span className="flex flex-col items-center gap-1 text-xs text-slate-500">
            {busy ? <Loader2 size={20} className="animate-spin"/> : <Upload size={20}/>}
            {busy ? 'Chargement…' : 'Cliquez pour téléverser'}
          </span>
        )}
        <input type="file" accept="image/*" onChange={handle} className="absolute inset-0 cursor-pointer opacity-0" disabled={busy}/>
      </div>
    </label>
  );
}

export default function JoinForm() {
  const navigate = useNavigate();
  const [form, setForm] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(null);
  const [verificationSent, setVerificationSent] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');
  const [whatsappLink, setWhatsappLink] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [codeBusy, setCodeBusy] = useState(false);
  const [sentViaApi, setSentViaApi] = useState(false);
  const [waitingForCode, setWaitingForCode] = useState(false);
  const [autoVerified, setAutoVerified] = useState(false);

  const field = (key) => ({ value: form[key], onChange: e => setForm({ ...form, [key]: e.target.value }) });

  useEffect(() => {
    if (!waitingForCode) return;
    const phone = form.whatsapp.replace(/[\s()-]/g, '');
    let cancelled = false;
    const poll = async () => {
      try {
        const res = await base44.functions.invoke('technicianAccount', { action: 'checkCodeVerified', phone });
        if (!cancelled && res.data.verified) {
          setWaitingForCode(false);
          setAutoVerified(true);
        }
      } catch {}
    };
    poll();
    const interval = setInterval(poll, 3000);
    return () => { cancelled = true; clearInterval(interval); };
  }, [waitingForCode, form.whatsapp]);

  const sendCode = async (e) => {
    if (e) e.preventDefault();
    if (!form.whatsapp.trim()) { setError("Saisissez votre numéro WhatsApp d'abord."); return; }
    setCodeBusy(true); setError('');
    try {
      const phone = form.whatsapp.replace(/[\s()-]/g, '');
      const res = await base44.functions.invoke('technicianAccount', { action: 'sendVerification', phone });
      setGeneratedCode(res.data.code || '');
      setWhatsappLink(res.data.whatsappLink || '');
      setSentViaApi(!!res.data.sent);
      setAutoVerified(false);
      setVerificationSent(true);
      if (res.data.sent) {
        setWaitingForCode(true);
      }
    } catch (err) {
      setError(err?.response?.data?.error || "Envoi du code impossible.");
    } finally { setCodeBusy(false); }
  };

  const submit = async e => {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      if (form.password !== form.passwordConfirm) {
        setError('Les deux mots de passe ne correspondent pas.');
        setBusy(false);
        return;
      }
      const name = `${form.prenoms} ${form.nom}`.trim();
      const whatsapp = form.whatsapp.replace(/[\s()-]/g, '');
      const city = form.city === 'Autre' ? form.custom_city.trim() : form.city;
      const { custom_city, password, passwordConfirm, ...rest } = form;
      const profile = {
        ...rest,
        name,
        nom: form.nom.trim(),
        prenoms: form.prenoms.trim(),
        city,
        quartier: form.quartier.trim(),
        custom_trade: form.trade === 'autres' ? form.custom_trade.trim() : '',
        age: form.age ? Number(form.age) : undefined,
        whatsapp,
        description: form.description.trim(),
        experience: Number(form.experience)
      };
      if (!autoVerified && !verificationCode.trim()) {
        setError("Entrez le code de vérification reçu par WhatsApp.");
        setBusy(false);
        return;
      }
      const res = await base44.functions.invoke('technicianAccount', {
        action: 'register',
        phone: whatsapp,
        password,
        verificationCode: autoVerified ? '' : verificationCode.trim(),
        profile
      });
      setSession({
        technicianId: res.data.technician.id,
        accountId: res.data.accountId,
        sessionToken: res.data.sessionToken
      });
      setSaved(res.data.technician);
    } catch (err) {
      setError('L’inscription n’a pas abouti. Veuillez réessayer.');
    } finally { setBusy(false); }
  };

  if (saved) {
    return (
      <div className="join-success border border-[#D3CCBE] bg-[#F3EFE7] p-10">
        <CheckCircle2 size={44} className="text-emerald-600"/>
        <h3>{saved.name}</h3>
        <p>Votre profil est maintenant visible dans l’annuaire. Les clients peuvent vous joindre par WhatsApp.</p>
        <button className="primary-button" onClick={() => navigate('/explorer')}>Voir l’annuaire <ArrowUpRight size={17}/></button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="join-form">
      <div className="form-grid">
        <label>Prénoms<input required minLength={2} maxLength={50} name="prenoms" placeholder="Ex. : Adama" {...field('prenoms')}/></label>
        <label>Nom<input required minLength={2} maxLength={50} name="nom" placeholder="Ex. : Ouédraogo" {...field('nom')}/></label>
      </div>
      <div className="form-grid">
        <label>Domaine d’activité<select {...field('trade')}>{trades.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}</select></label>
        <label>Ville<select required name="city" {...field('city')}><option value="Ouagadougou">Ouagadougou</option><option value="Bobo-Dioulasso">Bobo-Dioulasso</option><option value="Autre">Autre ville</option></select></label>
      </div>
      {form.trade === 'autres' && <label>Précisez le domaine<input required minLength={2} maxLength={50} name="custom_trade" placeholder="Ex. : Menuiserie, soudure…" {...field('custom_trade')}/></label>}
      {form.city === 'Autre' && <label>Précisez la ville<input required minLength={2} maxLength={60} name="custom_city" placeholder="Ex. : Koudougou" {...field('custom_city')}/></label>}
      <div className="form-grid">
        <label>Quartier{form.city === 'Ouagadougou' ? <select name="quartier" {...field('quartier')}><option value="">Sélectionnez…</option>{quartiers.map(q => <option key={q}>{q}</option>)}</select> : form.city === 'Bobo-Dioulasso' ? <select name="quartier" {...field('quartier')}><option value="">Sélectionnez…</option>{quartiersBobo.map(q => <option key={q}>{q}</option>)}</select> : <input name="quartier" maxLength={60} placeholder="Ex. : Secteur 4" {...field('quartier')}/>}</label>
        <label>Âge<input type="number" name="age" min="18" max="100" placeholder="Ex. : 32" {...field('age')}/></label>
      </div>
      <label>Numéro WhatsApp<input required type="tel" name="whatsapp" pattern="\+[0-9 ()-]{8,20}" placeholder="+226 XX XX XX XX" title="Numéro international commençant par +" {...field('whatsapp')}/></label>
      <button type="button" onClick={sendCode} disabled={codeBusy} className="flex items-center justify-center gap-2 rounded-full border border-[#D3CCBE] bg-[#E9E3D7] px-4 py-3 text-sm font-semibold text-[#3A8E9C] transition-colors hover:bg-[#D3CCBE] disabled:opacity-50">
        {codeBusy ? <><Loader2 size={16} className="animate-spin"/>Envoi…</> : <><MessageCircle size={16}/>Envoyer le code de vérification</>}
      </button>
      {verificationSent && (
        <div className="glass rounded-2xl p-4">
          {autoVerified ? (
            <>
              <p className="flex items-center gap-2 text-sm font-semibold text-emerald-600"><CheckCircle2 size={18}/>Code vérifié automatiquement</p>
              <p className="mt-1 text-xs text-slate-500">Votre réponse WhatsApp a été détectée. Vous pouvez finaliser votre inscription.</p>
            </>
          ) : sentViaApi ? (
            <>
              <p className="text-sm font-semibold text-slate-900">Code envoyé sur WhatsApp</p>
              <p className="mt-1 text-xs text-slate-500">Répondez au message WhatsApp avec le code reçu pour une vérification automatique, ou saisissez-le ci-dessous.</p>
              {waitingForCode && <p className="mt-2 flex items-center gap-2 text-xs text-[#3A8E9C]"><Loader2 size={14} className="animate-spin"/>En attente de votre réponse WhatsApp…</p>}
            </>
          ) : (
            <>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Votre code de vérification</p>
              <p className="mt-1 text-2xl font-bold tracking-widest text-slate-900">{generatedCode}</p>
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="mt-3 flex items-center justify-center gap-2 rounded-full bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-emerald-500">
                <MessageCircle size={16}/>Recevoir le code sur WhatsApp
              </a>
              <p className="mt-2 text-center text-xs text-slate-500">Saisissez ce code ci-dessous pour valider votre inscription.</p>
            </>
          )}
        </div>
      )}
      {verificationSent && !autoVerified && <label>Code de vérification<input required inputMode="numeric" maxLength={6} value={verificationCode} onChange={e => setVerificationCode(e.target.value)} placeholder="6 chiffres"/></label>}
      <label>Mot de passe (6 caractères min.)<input required type="password" minLength={6} name="password" placeholder="Choisissez un mot de passe" {...field('password')}/></label>
      <label>Confirmer le mot de passe<input required type="password" minLength={6} name="passwordConfirm" placeholder="Saisissez à nouveau votre mot de passe" {...field('passwordConfirm')}/></label>
      <div className="form-grid">
        <PhotoInput label="Photo de profil" value={form.profile_photo} onChange={v => setForm({ ...form, profile_photo: v })}/>
        <PhotoInput label="Photo d’illustration 1" value={form.illustration_1} onChange={v => setForm({ ...form, illustration_1: v })}/>
      </div>
      <div className="form-grid">
        <PhotoInput label="Photo d’illustration 2" value={form.illustration_2} onChange={v => setForm({ ...form, illustration_2: v })}/>
        <PhotoInput label="Photo d’illustration 3" value={form.illustration_3} onChange={v => setForm({ ...form, illustration_3: v })}/>
      </div>
      <PhotoInput label="Photo d’illustration 4" value={form.illustration_4} onChange={v => setForm({ ...form, illustration_4: v })}/>
      <VideoInput label="Vidéo de présentation (30s max)" value={form.presentation_video} onChange={v => setForm({ ...form, presentation_video: v })}/>
      <PdfInput label="CV (PDF, facultatif)" value={form.cv_url} onChange={v => setForm({ ...form, cv_url: v })}/>
      <label>Présentez vos services<textarea required minLength={20} maxLength={1000} name="description" rows={3} placeholder="Vos spécialités, vos services et votre zone d’intervention…" {...field('description')}/></label>
      <label>Années d’expérience<input type="number" min="0" max="70" required {...field('experience')}/></label>
      <label className="join-form checkbox-label"><input type="checkbox" checked={form.available} onChange={e => setForm({ ...form, available: e.target.checked })}/>Je suis disponible pour de nouvelles demandes</label>
      <label className="join-form checkbox-label consent"><input required type="checkbox"/>Je confirme être autorisé à publier ces informations et j’accepte que mon nom, ma ville et mon WhatsApp soient publics.</label>
      {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
      <button type="submit" className="primary-button w-full" disabled={busy}>{busy ? <><Loader2 size={18} className="animate-spin"/>Publication…</> : <>Publier mon profil<ArrowUpRight size={17}/></>}</button>
    </form>
  );
}