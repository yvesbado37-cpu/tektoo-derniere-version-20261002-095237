import React, { useState, useEffect } from 'react';
import { X, ZoomIn } from 'lucide-react';

export default function ZoomableImage({ src, alt, className, wrapperClassName, icon = true, onOpen = null }) {
  const [open, setOpen] = useState(false);
  const [zoomed, setZoomed] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [open]);

  useEffect(() => { if (!open) setZoomed(false); }, [open]);

  if (!src) return null;

  return (
    <>
      <button
        type="button"
        className={`relative block bg-transparent p-0 text-left ${wrapperClassName || ''}`}
        onClick={() => (onOpen ? onOpen() : setOpen(true))}
        style={{ cursor: 'zoom-in' }}
        aria-label={alt}
      >
        <img src={src} alt={alt} className={className} draggable={false} />
        {icon && (
          <span className="pointer-events-none absolute right-1.5 top-1.5 z-10 flex h-7 w-7 items-center justify-center rounded-full bg-black/50 text-white backdrop-blur-sm">
            <ZoomIn size={14} />
          </span>
        )}
      </button>
      {!onOpen && open && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/90" onClick={() => setOpen(false)}>
          <button onClick={(e) => { e.stopPropagation(); setOpen(false); }} className="absolute right-3 top-3 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20" aria-label="Fermer"><X size={22} /></button>
          <img
            src={src}
            alt={alt}
            draggable={false}
            onClick={(e) => { e.stopPropagation(); setZoomed(z => !z); }}
            className="max-h-full max-w-full object-contain transition-transform duration-300"
            style={{ transform: zoomed ? 'scale(2.5)' : 'scale(1)', cursor: zoomed ? 'zoom-out' : 'zoom-in' }}
          />
        </div>
      )}
    </>
  );
}