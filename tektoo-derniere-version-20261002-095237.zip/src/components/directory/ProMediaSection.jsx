import React, { useState } from 'react';
import { Loader2, Upload, X, ShieldCheck, Star } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import VideoInput from '@/components/directory/VideoInput';

const MAX_PHOTOS = 10;
const MAX_VIDEOS = 5;
const MAX_VIDEO_DURATION = 60;

function PhotoTile({ src, onRemove }) {
  return (
    <div className="relative aspect-square overflow-hidden rounded-lg border border-[#D3CCBE] bg-white">
      <img src={src} alt="" className="h-full w-full object-cover" />
      <button type="button" onClick={onRemove} className="absolute right-1 top-1 bg-[#F3EFE7]/90 p-1"><X size={13} /></button>
    </div>
  );
}

function AlbumInput({ title, photos, onChange }) {
  const [busy, setBusy] = useState(false);
  const handle = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    const remaining = MAX_PHOTOS - photos.length;
    const toUpload = files.slice(0, remaining);
    setBusy(true);
    try {
      const uploaded = await Promise.all(toUpload.map(f => base44.integrations.Core.UploadPublicFile({ file: f })));
      onChange([...photos, ...uploaded.map(u => u.file_url)]);
    } finally { setBusy(false); e.target.value = ''; }
  };
  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <span className="text-xs font-semibold text-slate-700">{title}</span>
        <span className="text-xs text-slate-500">{photos.length}/{MAX_PHOTOS}</span>
      </div>
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
        {photos.map((src, i) => <PhotoTile key={i} src={src} onRemove={() => onChange(photos.filter((_, idx) => idx !== i))} />)}
        {photos.length < MAX_PHOTOS && (
          <label className="relative flex aspect-square cursor-pointer items-center justify-center overflow-hidden rounded-lg border border-dashed border-[#D3CCBE] bg-[#E9E3D7]">
            <span className="flex flex-col items-center gap-1 text-xs text-slate-500">
              {busy ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />}
              {busy ? '…' : 'Ajouter'}
            </span>
            <input type="file" accept="image/*" multiple onChange={handle} className="absolute inset-0 cursor-pointer opacity-0" disabled={busy} />
          </label>
        )}
      </div>
    </div>
  );
}

export default function ProMediaSection({ t, onChange }) {
  const album1 = t.pro_album_1 || [];
  const album2 = t.pro_album_2 || [];
  const videos = t.pro_videos || [];

  const setVideo = (index, url) => {
    const next = [...videos];
    if (url) next[index] = url; else next.splice(index, 1);
    onChange({ pro_videos: next });
  };

  return (
    <div className="mt-6 border-t border-[#3A8E9C]/30 pt-5">
      <div className="mb-4 flex items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#3A8E9C]/10 text-[#3A8E9C]"><ShieldCheck size={18} /></span>
        <div>
          <div className="flex items-center gap-1.5 text-sm font-semibold text-slate-900"><Star size={15} className="text-[#3A8E9C]" />Contenu Pro</div>
          <p className="text-xs text-slate-500">2 albums de 10 photos et 5 vidéos d'une minute.</p>
        </div>
      </div>

      <div className="grid gap-5">
        <AlbumInput title="Album 1" photos={album1} onChange={(v) => onChange({ pro_album_1: v })} />
        <AlbumInput title="Album 2" photos={album2} onChange={(v) => onChange({ pro_album_2: v })} />
        <div>
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700">Vidéos Pro</span>
            <span className="text-xs text-slate-500">{videos.length}/{MAX_VIDEOS}</span>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {Array.from({ length: MAX_VIDEOS }).map((_, i) => (
              <VideoInput key={i} label={`Vidéo ${i + 1}`} value={videos[i] || ''} onChange={(url) => setVideo(i, url)} maxDuration={MAX_VIDEO_DURATION} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}