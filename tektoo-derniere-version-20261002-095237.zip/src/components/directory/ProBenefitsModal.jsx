import React, { useEffect } from 'react';
import { Star, X, Images, Video, TrendingUp, BadgeCheck, MessageCircle } from 'lucide-react';
import { companionApps, devisProApp, frioPressApp, maintPlanApp, moneyGestApp, solarSetApp, TEKTOO_WHATSAPP_NUMBER } from '@/lib/companionApps';
const MESSAGE = 'Bonjour Equipe tektoo, j\'aimerais passer à un compte pro comment faire?';

const perks = [
  { icon: TrendingUp, title: 'Visibilité prioritaire', desc: 'Votre profil apparaît en tête des résultats de l\'annuaire.' },
  { icon: BadgeCheck, title: 'Badge Pro', desc: 'Un badge orange « Pro » qui rassure les clients.' },
  { icon: Images, title: '2 albums de 10 photos', desc: 'Montrez vos réalisations avec jusqu\'à 20 photos.' },
  { icon: Video, title: '5 vidéos d\'une minute', desc: 'Un dossier vidéo dédié sur votre profil.' },
  { icon: Star, title: 'Carte Espace Pro', desc: 'Une carte exclusive met en valeur votre contenu Pro.' },
  { icon: moneyGestApp.icon, title: 'MoneyGest', desc: 'Gardez un œil sur votre trésorerie depuis vos outils Pro.' },
  { icon: devisProApp.icon, title: 'DevisPro', desc: 'Préparez vos devis et factures plus rapidement.' },
  { icon: maintPlanApp.icon, title: 'MaintPlan', desc: 'Planifiez vos entretiens et suivez vos interventions.' },
  { icon: solarSetApp.icon, title: 'SolarSet', desc: 'Dimensionnez vos installations solaires photovoltaïques.' },
  { icon: frioPressApp.icon, title: 'FrioPress', desc: 'Déterminez les pressions BP / HP des fluides frigorigènes.' }
];

export default function ProBenefitsModal({ open, onClose }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [open, onClose]);

  if (!open) return null;
  const waHref = `https://wa.me/${TEKTOO_WHATSAPP_NUMBER}?text=${encodeURIComponent(MESSAGE)}`;

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center" role="dialog" aria-modal="true" aria-label="Avantages du compte Pro">
      <button type="button" aria-label="Fermer" className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full max-w-md overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-3xl" style={{ borderTop: '4px solid #C2792E' }}>
        <div className="flex items-center justify-between px-5 py-4" style={{ background: 'linear-gradient(135deg, rgba(194,121,46,0.08), rgba(194,121,46,0.02))' }}>
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-full text-white" style={{ backgroundColor: '#C2792E' }}><Star size={18} fill="currentColor" /></span>
            <div>
              <h2 className="text-base font-semibold text-slate-900">Le compte Pro tektoo</h2>
              <p className="text-xs text-slate-500">Développez votre activité plus vite.</p>
            </div>
          </div>
          <button type="button" onClick={onClose} className="no-sound rounded-full p-1.5 text-slate-500 hover:bg-slate-100"><X size={18} /></button>
        </div>
        <div className="max-h-[60vh] overflow-y-auto px-5 py-4">
          <ul className="grid gap-3">
            {perks.map(p => (
              <li key={p.title} className="flex items-start gap-3 rounded-2xl border border-[#E9E3D7] bg-[#F3EFE7] p-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full" style={{ backgroundColor: 'rgba(194,121,46,0.12)', color: '#C2792E' }}><p.icon size={17} /></span>
                <div>
                  <div className="text-sm font-semibold text-slate-900">{p.title}</div>
                  <div className="text-xs leading-relaxed text-slate-600">{p.desc}</div>
                </div>
              </li>
            ))}
          </ul>
          <div className="mt-4 grid gap-2">
            {companionApps.map((app) => (
              <div
                key={app.slug}
                className="flex items-center justify-between rounded-2xl border border-[#E9E3D7] bg-white px-4 py-3 text-sm font-semibold text-slate-700"
              >
                <span>{app.name}</span>
                <span className="text-slate-500">Disponible en compte Pro actif</span>
              </div>
            ))}
          </div>
        </div>
        <div className="px-5 pb-5 pt-1">
          <a href={waHref} target="_blank" rel="noreferrer" className="flex w-full items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold text-white transition-transform active:scale-95" style={{ backgroundColor: '#C2792E' }}>
            <MessageCircle size={17} /> Demander à passer Pro
          </a>
          <p className="mt-2 text-center text-[11px] text-slate-500">Vous serez redirigé vers WhatsApp.</p>
        </div>
      </div>
    </div>
  );
}