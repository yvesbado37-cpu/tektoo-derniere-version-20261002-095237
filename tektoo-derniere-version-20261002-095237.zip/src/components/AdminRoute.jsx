import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getSession } from '@/lib/technicianSession';

const UNLOCK_KEY = 'tektoo_admin_unlocked';
const YVES_TECHNICIAN_ID = '6aaa799537cfecc045c07485';

export default function AdminRoute() {
  const location = useLocation();
  const session = getSession();
  const isYves = session?.technicianId === YVES_TECHNICIAN_ID;

  const urlParams = new URLSearchParams(location.search);
  const urlToken = urlParams.get('token');
  const urlCode = urlParams.get('code');
  const hasMagicLink = !!urlToken;

  const [verifying, setVerifying] = useState(false);
  const [verified, setVerified] = useState(false);
  const [magicError, setMagicError] = useState(false);

  const alreadyUnlocked = sessionStorage.getItem(UNLOCK_KEY) === '1';

  // Vérification du lien magique reçu via WhatsApp (pointe vers /admin-pro).
  // Skip si déjà déverrouillé pour éviter de consommer un jeton inutilement.
  useEffect(() => {
    if (!isYves || !urlToken || alreadyUnlocked) return;
    let active = true;
    setVerifying(true);
    base44.functions.invoke('adminAccess', {
      action: 'verifyMagic',
      accountId: session.accountId,
      sessionToken: session.sessionToken,
      token: urlToken,
      code: urlCode
    })
      .then(() => {
        if (!active) return;
        sessionStorage.setItem(UNLOCK_KEY, '1');
        window.history.replaceState({}, '', '/admin-pro');
        setVerified(true);
        setVerifying(false);
      })
      .catch(() => {
        if (!active) return;
        setMagicError(true);
        setVerifying(false);
      });
    return () => { active = false; };
  }, [urlToken, urlCode, isYves, alreadyUnlocked]);

  if (!isYves) return <Navigate to="/mon-compte" replace />;

  // Si déjà déverrouillé cette session, on accède directement — même si l'URL
  // contient encore un jeton consommé (ex. rafraîchissement après vérification).
  if (alreadyUnlocked && !hasMagicLink) return <Outlet />;

  // Lien magique : attendre le résultat de la vérification avant de décider.
  if (hasMagicLink) {
    if (magicError) {
      // Jeton invalide/expiré : si déjà déverrouillé, on accède ; sinon on régénère.
      if (alreadyUnlocked) return <Outlet />;
      return <Navigate to="/admin-unlock" replace />;
    }
    if (verified) return <Outlet />;
    return (
      <div className="flex h-full flex-col items-center justify-center gap-2 px-5 text-center">
        <Loader2 size={22} className="animate-spin text-slate-400" />
        <p className="text-sm text-slate-500">{verifying ? 'Vérification du lien…' : 'Chargement…'}</p>
      </div>
    );
  }

  // Accès normal sans lien magique : vérifier le déverrouillage de session.
  if (!alreadyUnlocked) {
    return <Navigate to="/admin-unlock" replace state={{ from: location.pathname }} />;
  }

  return <Outlet />;
}