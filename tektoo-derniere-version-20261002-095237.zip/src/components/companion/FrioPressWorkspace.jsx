import React, { useEffect, useMemo, useState } from 'react';
import jsPDF from 'jspdf';
import { FileDown, Search } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { downloadBlob } from '@/lib/downloadFile';
import { renderPdfTable } from '@/lib/renderPdfTable';
import { getCompanionStorageKey } from '@/lib/companionHandoff';
import {
  REFRIGERANTS,
  computePressures,
  findRefrigerant,
  formatBar,
  formatPsi,
  formatTemp,
  saturationTemperature,
  searchRefrigerants
} from '@/lib/refrigerantPressures';

const today = () => new Date().toISOString().slice(0, 10);

const toNumber = (value) => {
  const parsed = Number(String(value ?? '').replace(/\s+/g, '').replace(',', '.'));
  return Number.isFinite(parsed) ? parsed : 0;
};

const buildInitialValues = () => ({
  refrigerantId: REFRIGERANTS[0]?.id || '',
  query: '',
  evaporatingC: '-20',
  condensingC: '45',
  lookupPressure: ''
});

const UiTable = /** @type {any} */ (Table);
const UiTableBody = /** @type {any} */ (TableBody);
const UiTableCell = /** @type {any} */ (TableCell);
const UiTableHead = /** @type {any} */ (TableHead);
const UiTableHeader = /** @type {any} */ (TableHeader);
const UiTableRow = /** @type {any} */ (TableRow);

const fieldClass = 'rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]';

function PressureCard({ title, accent, data }) {
  return (
    <div className={`rounded-2xl border bg-white px-4 py-3 ${accent}`}>
      <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">{title}</p>
      {data ? (
        <>
          <p className="mt-2 text-xl font-semibold text-slate-900">{formatBar(data.barGauge)} <span className="text-xs font-medium text-slate-500">rel.</span></p>
          <p className="mt-1 text-xs text-slate-600">{formatBar(data.barAbsolute)} abs. • {formatPsi(data.psiGauge)} rel. • {formatPsi(data.psiAbsolute)} abs.</p>
        </>
      ) : (
        <p className="mt-2 text-sm text-slate-500">—</p>
      )}
    </div>
  );
}

async function generateFrioPressPdf(app, values, refrigerant, pressures) {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 46;

  const writeLine = (text, size = 11, weight = 'normal', gap = 16) => {
    doc.setFont('helvetica', weight);
    doc.setFontSize(size);
    doc.setTextColor(0, 0, 0);
    const lines = doc.splitTextToSize(text, pageWidth - 80);
    doc.text(lines, 40, y);
    y += (lines.length * (size + 4)) + gap;
  };

  writeLine(app.name, 20, 'bold', 8);
  writeLine(app.tagline, 11, 'normal', 12);
  writeLine(`Fluide : ${refrigerant?.name || '—'} (${refrigerant?.family || '—'}) — généré le ${new Date().toLocaleDateString('fr-FR')}`, 10, 'normal', 16);

  if (pressures) {
    writeLine('Pressions de fonctionnement', 12, 'bold', 8);
    y = renderPdfTable(doc, {
      startY: y,
      columns: [
        { key: 'label', label: 'Circuit', width: 1.6 },
        { key: 'temp', label: 'Température', width: 1, align: 'right' },
        { key: 'gauge', label: 'Pression rel.', width: 1, align: 'right' },
        { key: 'abs', label: 'Pression abs.', width: 1, align: 'right' },
        { key: 'psi', label: 'psi (rel.)', width: 0.9, align: 'right' }
      ],
      rows: [
        { label: 'BP (évaporation)', temp: formatTemp(pressures.evaporatingC), gauge: formatBar(pressures.bp.barGauge), abs: formatBar(pressures.bp.barAbsolute), psi: formatPsi(pressures.bp.psiGauge) },
        { label: 'HP (condensation)', temp: formatTemp(pressures.condensingC), gauge: formatBar(pressures.hp.barGauge), abs: formatBar(pressures.hp.barAbsolute), psi: formatPsi(pressures.hp.psiGauge) }
      ],
      marginX: 24
    });
    y += 16;
  }

  writeLine(`Table Pression–Température de saturation — ${refrigerant?.name || ''}`, 12, 'bold', 8);
  y = renderPdfTable(doc, {
    startY: y,
    columns: [
      { key: 'temp', label: 'Température (°C)', width: 1, align: 'right' },
      { key: 'abs', label: 'Pression abs. (bar)', width: 1, align: 'right' },
      { key: 'gauge', label: 'Pression rel. (bar)', width: 1, align: 'right' },
      { key: 'psi', label: 'Pression rel. (psi)', width: 1, align: 'right' }
    ],
    rows: (refrigerant?.pt || []).map(([temp, abs]) => ({
      temp: formatTemp(temp),
      abs: formatBar(abs),
      gauge: formatBar(abs - 1.013),
      psi: formatPsi((abs - 1.013) * 14.5038)
    })),
    marginX: 24
  });

  y += 14;
  writeLine('Valeurs indicatives issues d’abaques Pression–Température. À valider avec l’abaque du fabricant.', 8.5, 'normal', 0);

  return downloadBlob(
    doc.output('blob'),
    `${app.filenamePrefix}-${refrigerant?.id || 'fluide'}-${today()}.pdf`
  );
}

export function FrioPressWorkspace({ app, technician, standalone = false }) {
  const storageKey = useMemo(
    () => getCompanionStorageKey(app.slug, technician),
    [app.slug, technician?.id, technician?.email, technician?.name, technician?.phone]
  );
  const [values, setValues] = useState(buildInitialValues);
  const [feedback, setFeedback] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    const initialValues = buildInitialValues();
    try {
      const raw = window.localStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          setValues({ ...initialValues, ...parsed });
          return;
        }
      }
    } catch {
      // Chargement du brouillon non bloquant.
    }
    setValues(initialValues);
  }, [storageKey]);

  useEffect(() => {
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(values));
    } catch {
      // Autosave non bloquante.
    }
  }, [storageKey, values]);

  const updateField = (name, value) => {
    setValues((current) => ({ ...current, [name]: value }));
    setFeedback('');
  };

  const refrigerant = useMemo(() => findRefrigerant(values.refrigerantId), [values.refrigerantId]);
  const results = searchRefrigerants(values.query);
  const pressures = useMemo(
    () => computePressures(values.refrigerantId, values.evaporatingC, values.condensingC),
    [values.refrigerantId, values.evaporatingC, values.condensingC]
  );
  const lookupTemperature = useMemo(() => {
    if (!refrigerant) return null;
    const raw = String(values.lookupPressure ?? '').trim();
    if (!raw) return null;
    // Pression saisie = relative (manomètre). On convertit en absolue.
    return saturationTemperature(refrigerant, toNumber(raw) + 1.013);
  }, [refrigerant, values.lookupPressure]);

  const handleGenerate = async () => {
    if (!refrigerant) {
      setFeedback('Sélectionnez un fluide frigorigène.');
      return;
    }
    setIsGenerating(true);
    try {
      const result = await generateFrioPressPdf(app, values, refrigerant, pressures);
      setFeedback(result?.message || 'Fiche pression PDF prête, téléchargement démarré.');
    } catch (error) {
      setFeedback(error instanceof Error && error.message
        ? error.message
        : 'La génération du PDF a échoué. Réessayez.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className={standalone ? 'glass rounded-2xl p-5' : 'p-5 sm:p-6'}>
      <h2 className="text-2xl font-semibold tracking-tight text-slate-900">{app.name}</h2>
      <p className="mt-1 text-sm text-slate-600">{app.description}</p>

      <section className="mt-5 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">1. Rechercher un fluide frigorigène</h3>
        <div className="relative mt-3">
          <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={values.query}
            onChange={(e) => updateField('query', e.target.value)}
            className={`${fieldClass} w-full pl-9`}
            placeholder="Nom, famille ou usage (ex. R134a, hydrocarbure, chambre froide)"
          />
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {results.length === 0 && <p className="text-xs text-slate-500">Aucun fluide ne correspond à cette recherche.</p>}
          {results.map((item) => {
            const selected = item.id === values.refrigerantId;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => updateField('refrigerantId', item.id)}
                className={`rounded-xl border p-3 text-left transition ${selected ? 'border-[#3A8E9C] bg-[#3A8E9C]/10' : 'border-[#D3CCBE] bg-white hover:border-[#3A8E9C]/50'}`}
              >
                <p className="text-sm font-semibold text-slate-900">{item.name}</p>
                <p className="mt-0.5 text-[11px] font-semibold uppercase tracking-wide text-[#3A8E9C]">{item.family}</p>
                <p className="mt-1 text-xs text-slate-600">{item.usage}</p>
              </button>
            );
          })}
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">2. Calculateur BP / HP</h3>
        <p className="mt-1 text-xs text-slate-500">
          Saisissez la température d’évaporation (BP) et de condensation (HP). La pression de saturation est calculée pour {refrigerant?.name || 'le fluide sélectionné'}.
        </p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Température d’évaporation (°C) — BP
            <input type="text" inputMode="decimal" value={values.evaporatingC} onChange={(e) => updateField('evaporatingC', e.target.value)} className={fieldClass} />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Température de condensation (°C) — HP
            <input type="text" inputMode="decimal" value={values.condensingC} onChange={(e) => updateField('condensingC', e.target.value)} className={fieldClass} />
          </label>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <PressureCard title="Basse pression (BP)" accent="border-sky-200" data={pressures?.bp} />
          <PressureCard title="Haute pression (HP)" accent="border-rose-200" data={pressures?.hp} />
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">3. Recherche inverse (pression → température)</h3>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 sm:items-end">
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Pression relevée au manomètre (bar relatif)
            <input type="text" inputMode="decimal" value={values.lookupPressure} onChange={(e) => updateField('lookupPressure', e.target.value)} className={fieldClass} placeholder="Ex. 4,5" />
          </label>
          <div className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm">
            {lookupTemperature === null
              ? <span className="text-slate-500">Saisissez une pression pour obtenir la température de saturation.</span>
              : <span className="font-semibold text-slate-900">Température de saturation : {formatTemp(lookupTemperature)}</span>}
          </div>
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">4. Table Pression–Température — {refrigerant?.name || ''}</h3>
        <div className="mt-3 max-h-80 overflow-auto rounded-xl border border-[#D3CCBE] bg-white">
          <UiTable className="w-full">
            <UiTableHeader className="sticky top-0 bg-[#FCFBF8]">
              <UiTableRow className="hover:bg-[#FCFBF8]">
                <UiTableHead className="text-right text-slate-700">Temp. (°C)</UiTableHead>
                <UiTableHead className="text-right text-slate-700">P. abs. (bar)</UiTableHead>
                <UiTableHead className="text-right text-slate-700">P. rel. (bar)</UiTableHead>
                <UiTableHead className="text-right text-slate-700">P. rel. (psi)</UiTableHead>
              </UiTableRow>
            </UiTableHeader>
            <UiTableBody>
              {(refrigerant?.pt || []).map(([temp, abs]) => (
                <UiTableRow key={temp}>
                  <UiTableCell className="text-right text-slate-900">{formatTemp(temp)}</UiTableCell>
                  <UiTableCell className="text-right text-slate-900">{formatBar(abs)}</UiTableCell>
                  <UiTableCell className="text-right text-slate-900">{formatBar(abs - 1.013)}</UiTableCell>
                  <UiTableCell className="text-right text-slate-900">{formatPsi((abs - 1.013) * 14.5038)}</UiTableCell>
                </UiTableRow>
              ))}
            </UiTableBody>
          </UiTable>
        </div>
        <p className="mt-2 text-[11px] text-slate-500">Valeurs indicatives — se référer à l’abaque du fabricant pour les mesures critiques.</p>
      </section>

      <div className="mt-5 flex justify-end">
        <button type="button" onClick={handleGenerate} disabled={isGenerating || !refrigerant} className="primary-button disabled:cursor-not-allowed disabled:opacity-60">
          <FileDown size={16} /> {isGenerating ? 'Génération…' : 'Générer le PDF'}
        </button>
      </div>

      {feedback && <p className="mt-3 text-sm font-medium text-emerald-600">{feedback}</p>}
    </div>
  );
}

export default FrioPressWorkspace;
