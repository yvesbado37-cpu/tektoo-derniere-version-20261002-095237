import React, { useEffect, useMemo, useState } from 'react';
import jsPDF from 'jspdf';
import { FileDown, Pencil, Plus, Trash2 } from 'lucide-react';
import { downloadBlob } from '@/lib/downloadFile';
import { renderPdfTable } from '@/lib/renderPdfTable';
import {
  computeNextPreventiveDate,
  createMaintPlanId,
  filterInterventionsByPeriod,
  formatDateFr,
  getAgendaStatus,
  getLastCompletedPreventiveDate,
  INTERVENTION_STATUSES,
  INTERVENTION_TYPES,
  isValidIsoDate,
  sortByIsoDate,
  todayIsoUtc,
  validateClientDraft,
  validateInterventionDraft
} from '@/lib/maintPlan';

const equipmentSuggestions = ['Climatiseur', 'Groupe électrogène', 'Chambre froide', 'Pompe', 'Compresseur', 'Onduleur'];

const emptyClientDraft = () => ({
  id: '',
  clientName: '',
  phone: '',
  equipmentType: '',
  powerSpec: '',
  brand: '',
  equipmentAge: '',
  firstMaintenanceDate: '',
  periodValue: '1',
  periodUnit: 'months',
  lastPreventiveDate: ''
});

const emptyInterventionDraft = (clientId = '') => ({
  clientId,
  date: todayIsoUtc(),
  interventionType: INTERVENTION_TYPES.PREVENTIVE,
  description: '',
  status: INTERVENTION_STATUSES.PLANNED
});

const getStorageKey = (app, technician) => {
  const identity = technician?.id || technician?.email || technician?.phone || technician?.name || 'anonymous';
  return `tektoo:companion:${app.slug}:${String(identity).trim().toLowerCase()}`;
};

const buildInitialValues = (technician) => ({
  clients: [],
  interventions: [],
  clientDraft: emptyClientDraft(),
  interventionDraft: emptyInterventionDraft(),
  periodStart: todayIsoUtc(),
  periodEnd: todayIsoUtc(),
  periodClientId: '',
  companyName: technician?.name || ''
});

const statusLabel = {
  late: 'En retard',
  today: 'Aujourd’hui',
  upcoming: 'À venir'
};

const interventionTypeLabel = {
  preventive: 'Préventive',
  curative: 'Curative'
};

const interventionStatusLabel = {
  planifiee: 'Planifiée',
  realisee: 'Réalisée'
};

export function MaintPlanWorkspace({ app, technician, standalone = false }) {
  const storageKey = useMemo(
    () => getStorageKey(app, technician),
    [app.slug, technician?.email, technician?.id, technician?.name, technician?.phone]
  );
  const [values, setValues] = useState(() => buildInitialValues(technician));
  const [feedback, setFeedback] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    const initialValues = buildInitialValues(technician);
    try {
      const rawDraft = window.localStorage.getItem(storageKey);
      if (rawDraft) {
        const parsedDraft = JSON.parse(rawDraft);
        if (parsedDraft && typeof parsedDraft === 'object') {
          setValues({
            ...initialValues,
            ...parsedDraft,
            clients: Array.isArray(parsedDraft.clients) ? parsedDraft.clients : [],
            interventions: Array.isArray(parsedDraft.interventions) ? parsedDraft.interventions : [],
            clientDraft: { ...emptyClientDraft(), ...parsedDraft.clientDraft },
            interventionDraft: { ...emptyInterventionDraft(), ...parsedDraft.interventionDraft }
          });
          setFeedback('Brouillon rechargé automatiquement.');
          return;
        }
      }
    } catch {
      setFeedback('Brouillon illisible, un nouveau brouillon a été initialisé.');
    }
    setValues(initialValues);
    setFeedback('');
  }, [storageKey, technician?.name]);

  useEffect(() => {
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(values));
    } catch {
      setFeedback('Impossible d’enregistrer automatiquement le brouillon sur cet appareil.');
    }
  }, [storageKey, values]);

  const clientsById = useMemo(
    () => values.clients.reduce((acc, client) => ({ ...acc, [client.id]: client }), {}),
    [values.clients]
  );

  const preventiveAgenda = useMemo(() => sortByIsoDate(values.clients
    .map((client) => {
      const nextDate = computeNextPreventiveDate(client);
      if (!isValidIsoDate(nextDate)) return null;
      const status = getAgendaStatus(nextDate);
      return {
        id: `preventive-${client.id}`,
        date: nextDate,
        clientId: client.id,
        clientName: client.clientName,
        phone: client.phone,
        equipment: `${client.equipmentType} ${client.brand ? `• ${client.brand}` : ''} ${client.powerSpec ? `• ${client.powerSpec}` : ''}`.trim(),
        interventionType: 'preventive',
        description: 'Entretien préventif périodique',
        agendaStatus: status,
        status: statusLabel[status]
      };
    })
    .filter(Boolean), 'date'), [values.clients]);

  const curativeAgenda = useMemo(() => sortByIsoDate(values.interventions
    .filter((entry) => entry.interventionType === INTERVENTION_TYPES.CURATIVE && entry.status !== INTERVENTION_STATUSES.DONE)
    .map((entry) => {
      const client = clientsById[entry.clientId];
      return {
        id: entry.id,
        date: entry.date,
        clientId: entry.clientId,
        clientName: client?.clientName || 'Client supprimé',
        phone: client?.phone || '—',
        equipment: client ? `${client.equipmentType} ${client.brand ? `• ${client.brand}` : ''} ${client.powerSpec ? `• ${client.powerSpec}` : ''}`.trim() : '—',
        interventionType: 'curative',
        description: entry.description || 'Maintenance curative',
        agendaStatus: getAgendaStatus(entry.date),
        status: interventionStatusLabel[entry.status] || 'Planifiée'
      };
    }), 'date'), [clientsById, values.interventions]);

  const agenda = useMemo(() => sortByIsoDate([...preventiveAgenda, ...curativeAgenda], 'date'), [curativeAgenda, preventiveAgenda]);

  const journal = useMemo(
    () => sortByIsoDate(values.interventions, 'date').reverse(),
    [values.interventions]
  );

  const handleClientDraftChange = (name, value) => {
    setValues((current) => ({ ...current, clientDraft: { ...current.clientDraft, [name]: value } }));
    setFeedback('');
  };

  const saveClient = () => {
    const draft = values.clientDraft;
    const validation = validateClientDraft(draft);
    if (!validation.isValid) {
      setFeedback(validation.message);
      return;
    }

    const normalizedClient = {
      ...emptyClientDraft(),
      ...draft,
      clientName: draft.clientName.trim(),
      phone: draft.phone.trim(),
      equipmentType: draft.equipmentType.trim(),
      powerSpec: draft.powerSpec.trim(),
      brand: draft.brand.trim(),
      equipmentAge: String(draft.equipmentAge || '').trim(),
      periodValue: String(Math.max(Number(draft.periodValue) || 1, 1)),
      periodUnit: draft.periodUnit || 'months',
      firstMaintenanceDate: draft.firstMaintenanceDate || '',
      lastPreventiveDate: draft.lastPreventiveDate || ''
    };

    setValues((current) => {
      const isEditing = Boolean(normalizedClient.id);
      const id = normalizedClient.id || createMaintPlanId();
      const nextClient = { ...normalizedClient, id };
      const nextClients = isEditing
        ? current.clients.map((client) => (client.id === id ? nextClient : client))
        : [...current.clients, nextClient];
      const nextInterventionDraft = current.interventionDraft.clientId
        ? current.interventionDraft
        : { ...current.interventionDraft, clientId: id };
      return {
        ...current,
        clients: nextClients,
        clientDraft: emptyClientDraft(),
        interventionDraft: nextInterventionDraft
      };
    });
    setFeedback(draft.id ? 'Fiche client mise à jour.' : 'Fiche client ajoutée.');
  };

  const editClient = (clientId) => {
    const selected = values.clients.find((client) => client.id === clientId);
    if (!selected) return;
    setValues((current) => ({ ...current, clientDraft: { ...emptyClientDraft(), ...selected } }));
    setFeedback('');
  };

  const removeClient = (clientId) => {
    const selected = values.clients.find((client) => client.id === clientId);
    if (!selected) return;
    if (!window.confirm(`Supprimer la fiche de ${selected.clientName} ?`)) return;
    setValues((current) => ({
      ...current,
      clients: current.clients.filter((client) => client.id !== clientId),
      interventions: current.interventions.filter((entry) => entry.clientId !== clientId),
      periodClientId: current.periodClientId === clientId ? '' : current.periodClientId,
      interventionDraft: current.interventionDraft.clientId === clientId ? emptyInterventionDraft() : current.interventionDraft
    }));
    setFeedback('Fiche client supprimée.');
  };

  const updateClientSchedule = (clientId, patch) => {
    setValues((current) => ({
      ...current,
      clients: current.clients.map((client) => (client.id === clientId ? { ...client, ...patch } : client))
    }));
    setFeedback('');
  };

  const handleInterventionDraftChange = (name, value) => {
    setValues((current) => ({ ...current, interventionDraft: { ...current.interventionDraft, [name]: value } }));
    setFeedback('');
  };

  const saveIntervention = () => {
    const draft = values.interventionDraft;
    const validation = validateInterventionDraft(draft, clientsById);
    if (!validation.isValid) {
      setFeedback(validation.message);
      return;
    }

    const entry = {
      id: createMaintPlanId(),
      clientId: draft.clientId,
      date: draft.date,
      interventionType: draft.interventionType,
      description: draft.description.trim(),
      status: draft.status
    };

    setValues((current) => ({
      ...current,
      interventions: [...current.interventions, entry],
      clients: current.clients.map((client) => {
        if (client.id !== entry.clientId) return client;
        if (entry.interventionType !== INTERVENTION_TYPES.PREVENTIVE || entry.status !== INTERVENTION_STATUSES.DONE) return client;
        return { ...client, lastPreventiveDate: entry.date };
      }),
      interventionDraft: emptyInterventionDraft(entry.clientId)
    }));
    setFeedback('Intervention enregistrée.');
  };

  const setInterventionDone = (entryId) => {
    const target = values.interventions.find((entry) => entry.id === entryId);
    if (!target) return;
    setValues((current) => ({
      ...current,
      interventions: current.interventions.map((entry) => (entry.id === entryId ? { ...entry, status: INTERVENTION_STATUSES.DONE } : entry)),
      clients: current.clients.map((client) => {
        if (client.id !== target.clientId) return client;
        if (target.interventionType !== INTERVENTION_TYPES.PREVENTIVE) return client;
        return { ...client, lastPreventiveDate: target.date };
      })
    }));
    setFeedback('Intervention marquée comme réalisée.');
  };

  const removeIntervention = (entryId) => {
    const target = values.interventions.find((entry) => entry.id === entryId);
    if (!target) return;
    if (!window.confirm('Supprimer cette intervention ?')) return;
    setValues((current) => {
      const nextInterventions = current.interventions.filter((entry) => entry.id !== entryId);
      return {
        ...current,
        interventions: nextInterventions,
        clients: current.clients.map((client) => {
          if (client.id !== target.clientId) return client;
          if (target.interventionType !== INTERVENTION_TYPES.PREVENTIVE || target.status !== INTERVENTION_STATUSES.DONE) return client;
          return { ...client, lastPreventiveDate: getLastCompletedPreventiveDate(nextInterventions, client.id) };
        })
      };
    });
    setFeedback('Intervention supprimée.');
  };

  const filteredPeriodInterventions = useMemo(
    () => sortByIsoDate(filterInterventionsByPeriod(values.interventions, {
      startDate: values.periodStart,
      endDate: values.periodEnd,
      clientId: values.periodClientId || undefined
    }), 'date'),
    [values.interventions, values.periodClientId, values.periodEnd, values.periodStart]
  );

  const generatePdf = async () => {
    if (!values.periodStart || !values.periodEnd || values.periodStart > values.periodEnd) {
      setFeedback('Choisissez une période valide pour générer l’historique.');
      return;
    }
    if (filteredPeriodInterventions.length === 0) {
      setFeedback('Aucune intervention sur cette période. Ajustez les filtres avant de générer le PDF.');
      return;
    }
    setIsGenerating(true);
    try {
      const doc = new jsPDF({ unit: 'pt', format: 'a4' });
      const pageWidth = doc.internal.pageSize.getWidth();
      let y = 46;

      const writeLine = (text, size = 11, weight = 'normal', gap = 16) => {
        doc.setFont('helvetica', weight);
        doc.setFontSize(size);
        doc.setTextColor(0, 0, 0);
        const lines = doc.splitTextToSize(text, pageWidth - 80);
        doc.text(lines, 40, y);
        y += (lines.length * (size + 4)) + gap;
      };

      writeLine(app.name, 20, 'bold', 8);
      writeLine(app.tagline, 11, 'normal', 10);
      writeLine(
        `Historique du ${formatDateFr(values.periodStart)} au ${formatDateFr(values.periodEnd)} — généré le ${new Date().toLocaleDateString('fr-FR')}`,
        10,
        'normal',
        16
      );

      renderPdfTable(doc, {
        startY: y,
        columns: [
          { key: 'date', label: 'Date', width: 0.8 },
          { key: 'client', label: 'Client', width: 1.1 },
          { key: 'phone', label: 'Téléphone', width: 0.95 },
          { key: 'equipment', label: 'Équipement', width: 1.4 },
          { key: 'type', label: 'Type d’intervention', width: 1.05 },
          { key: 'description', label: 'Travaux réalisés', width: 1.5 },
          { key: 'status', label: 'Statut', width: 0.7 }
        ],
        rows: filteredPeriodInterventions.map((entry) => {
          const client = clientsById[entry.clientId];
          return {
            date: formatDateFr(entry.date),
            client: client?.clientName || 'Client supprimé',
            phone: client?.phone || '—',
            equipment: client ? `${client.equipmentType} • ${client.brand || '—'} • ${client.powerSpec || '—'}` : '—',
            type: interventionTypeLabel[entry.interventionType] || '—',
            description: entry.description || '—',
            status: interventionStatusLabel[entry.status] || '—'
          };
        }),
        marginX: 24
      });

      const downloadResult = await downloadBlob(
        doc.output('blob'),
        `${app.filenamePrefix}-${values.periodStart}-${values.periodEnd}.pdf`
      );
      setFeedback(downloadResult?.message || 'Historique PDF généré avec succès.');
    } catch (error) {
      setFeedback(error instanceof Error && error.message
        ? error.message
        : 'La génération du PDF a échoué. Vérifiez les données puis réessayez.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className={standalone ? 'glass mt-4 rounded-2xl p-5' : 'p-5 sm:p-6'}>
      <h2 className="text-2xl font-semibold tracking-tight text-slate-900">{app.name}</h2>
      <p className="mt-1 text-sm text-slate-600">{app.description}</p>

      <section className="mt-6 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">1. Fiches clients / équipements</h3>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Nom du client
            <input type="text" value={values.clientDraft.clientName} onChange={(event) => handleClientDraftChange('clientName', event.target.value)} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]" />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Numéro de téléphone
            <input type="tel" value={values.clientDraft.phone} onChange={(event) => handleClientDraftChange('phone', event.target.value)} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]" />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Type d’équipement
            <input type="text" list="maintplan-equipment-types" value={values.clientDraft.equipmentType} onChange={(event) => handleClientDraftChange('equipmentType', event.target.value)} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]" />
            <datalist id="maintplan-equipment-types">
              {equipmentSuggestions.map((suggestion) => <option key={suggestion} value={suggestion} />)}
            </datalist>
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Caractéristique / puissance
            <input type="text" value={values.clientDraft.powerSpec} onChange={(event) => handleClientDraftChange('powerSpec', event.target.value)} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]" />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Marque
            <input type="text" value={values.clientDraft.brand} onChange={(event) => handleClientDraftChange('brand', event.target.value)} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]" />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Âge de l’équipement (années)
            <input type="number" min="0" step="1" value={values.clientDraft.equipmentAge} onChange={(event) => handleClientDraftChange('equipmentAge', event.target.value)} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]" />
          </label>
        </div>
        <div className="mt-4 flex justify-end">
          <button type="button" onClick={saveClient} className="primary-button">
            <Plus size={16} /> {values.clientDraft.id ? 'Mettre à jour la fiche' : 'Ajouter la fiche'}
          </button>
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">2. Planification préventive</h3>
        <div className="mt-3 space-y-3">
          {values.clients.length === 0 && <p className="text-xs text-slate-500">Ajoutez une fiche client pour démarrer la planification.</p>}
          {values.clients.map((client) => {
            const nextDate = computeNextPreventiveDate(client);
            const agendaState = getAgendaStatus(nextDate);
            return (
              <div key={client.id} className="rounded-xl border border-[#D3CCBE] bg-white p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-sm font-semibold text-slate-900">{client.clientName} — {client.equipmentType}</p>
                  <div className="flex items-center gap-2">
                    <button type="button" onClick={() => editClient(client.id)} className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-[#D3CCBE] text-slate-600"><Pencil size={14} /></button>
                    <button type="button" onClick={() => removeClient(client.id)} className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-[#D3CCBE] text-red-600"><Trash2 size={14} /></button>
                  </div>
                </div>
                <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  <label className="grid gap-1 text-xs font-semibold text-slate-700">
                    Premier entretien
                    <input type="date" value={client.firstMaintenanceDate || ''} onChange={(event) => updateClientSchedule(client.id, { firstMaintenanceDate: event.target.value })} className="rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]" />
                  </label>
                  <label className="grid gap-1 text-xs font-semibold text-slate-700">
                    Périodicité (nombre)
                    <input type="number" min="1" step="1" value={client.periodValue || '1'} onChange={(event) => updateClientSchedule(client.id, { periodValue: String(Math.max(Number(event.target.value) || 1, 1)) })} className="rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]" />
                  </label>
                  <label className="grid gap-1 text-xs font-semibold text-slate-700">
                    Unité
                    <select value={client.periodUnit || 'months'} onChange={(event) => updateClientSchedule(client.id, { periodUnit: event.target.value })} className="rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]">
                      <option value="days">Jours</option>
                      <option value="weeks">Semaines</option>
                      <option value="months">Mois</option>
                    </select>
                  </label>
                  <label className="grid gap-1 text-xs font-semibold text-slate-700">
                    Dernier préventif réalisé
                    <input type="date" value={client.lastPreventiveDate || ''} onChange={(event) => updateClientSchedule(client.id, { lastPreventiveDate: event.target.value })} className="rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]" />
                  </label>
                </div>
                <div className="mt-3 rounded-xl border border-[#D3CCBE] bg-[#F3EFE7] px-3 py-2 text-sm">
                  Prochaine intervention : <strong>{formatDateFr(nextDate)}</strong>
                  {agendaState && <span className="ml-2 rounded-full bg-white px-2 py-0.5 text-xs font-semibold text-slate-700">{statusLabel[agendaState]}</span>}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">3. Journal des interventions / 4. Tâches curatives</h3>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <label className="grid gap-1 text-xs font-semibold text-slate-700 lg:col-span-2">
            Client / équipement
            <select value={values.interventionDraft.clientId} onChange={(event) => handleInterventionDraftChange('clientId', event.target.value)} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]">
              <option value="">Sélectionnez…</option>
              {values.clients.map((client) => <option key={client.id} value={client.id}>{client.clientName} — {client.equipmentType}</option>)}
            </select>
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Date
            <input type="date" value={values.interventionDraft.date} onChange={(event) => handleInterventionDraftChange('date', event.target.value)} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]" />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Type
            <select value={values.interventionDraft.interventionType} onChange={(event) => handleInterventionDraftChange('interventionType', event.target.value)} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]">
              <option value={INTERVENTION_TYPES.PREVENTIVE}>Préventive</option>
              <option value={INTERVENTION_TYPES.CURATIVE}>Curative</option>
            </select>
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Statut
            <select value={values.interventionDraft.status} onChange={(event) => handleInterventionDraftChange('status', event.target.value)} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]">
              <option value={INTERVENTION_STATUSES.PLANNED}>Planifiée</option>
              <option value={INTERVENTION_STATUSES.DONE}>Réalisée</option>
            </select>
          </label>
        </div>
        <label className="mt-3 grid gap-1 text-xs font-semibold text-slate-700">
          Description des travaux
          <textarea rows={3} value={values.interventionDraft.description} onChange={(event) => handleInterventionDraftChange('description', event.target.value)} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]" placeholder="Ex. nettoyage, recharge, remplacement, diagnostic…" />
        </label>
        <div className="mt-4 flex justify-end">
          <button type="button" onClick={saveIntervention} className="primary-button">
            <Plus size={16} /> Enregistrer l’intervention
          </button>
        </div>

        <div className="mt-5 space-y-2">
          {journal.length === 0 && <p className="text-xs text-slate-500">Aucune intervention enregistrée.</p>}
          {journal.map((entry) => {
            const client = clientsById[entry.clientId];
            return (
              <div key={entry.id} className="rounded-xl border border-[#D3CCBE] bg-white p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-sm font-semibold text-slate-900">{formatDateFr(entry.date)} • {client?.clientName || 'Client supprimé'}</p>
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-[#F3EFE7] px-2 py-0.5 text-xs font-semibold text-slate-700">{interventionTypeLabel[entry.interventionType]}</span>
                    <span className="rounded-full bg-white px-2 py-0.5 text-xs font-semibold text-slate-700 border border-[#D3CCBE]">{interventionStatusLabel[entry.status]}</span>
                  </div>
                </div>
                <p className="mt-2 text-sm text-slate-700">{entry.description}</p>
                <div className="mt-3 flex justify-end gap-2">
                  {entry.status !== INTERVENTION_STATUSES.DONE && (
                    <button type="button" onClick={() => setInterventionDone(entry.id)} className="rounded-full border border-[#3A8E9C]/30 bg-white px-3 py-1.5 text-xs font-semibold text-[#3A8E9C]">
                      Marquer réalisée
                    </button>
                  )}
                  <button type="button" onClick={() => removeIntervention(entry.id)} className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-[#D3CCBE] text-red-600">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">Agenda des prochaines interventions</h3>
        <div className="mt-3 space-y-2">
          {agenda.length === 0 && <p className="text-xs text-slate-500">Aucune intervention à venir pour le moment.</p>}
          {agenda.map((entry) => (
            <div key={entry.id} className="rounded-xl border border-[#D3CCBE] bg-white p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-sm font-semibold text-slate-900">{formatDateFr(entry.date)} — {entry.clientName}</p>
                <span className="rounded-full bg-[#F3EFE7] px-2 py-0.5 text-xs font-semibold text-slate-700">{entry.status}</span>
              </div>
              <p className="mt-1 text-xs text-slate-600">{entry.equipment}</p>
              <p className="mt-1 text-sm text-slate-700">{entry.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">5. Historique PDF sur une période</h3>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Début
            <input type="date" value={values.periodStart} onChange={(event) => setValues((current) => ({ ...current, periodStart: event.target.value }))} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]" />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Fin
            <input type="date" value={values.periodEnd} onChange={(event) => setValues((current) => ({ ...current, periodEnd: event.target.value }))} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]" />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700 lg:col-span-2">
            Filtre client (optionnel)
            <select value={values.periodClientId} onChange={(event) => setValues((current) => ({ ...current, periodClientId: event.target.value }))} className="rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm outline-none focus:border-[#3A8E9C]">
              <option value="">Tous les clients</option>
              {values.clients.map((client) => <option key={client.id} value={client.id}>{client.clientName}</option>)}
            </select>
          </label>
        </div>
        <div className="mt-4 flex justify-end">
          <button type="button" onClick={generatePdf} disabled={isGenerating} className="primary-button disabled:cursor-not-allowed disabled:opacity-60">
            <FileDown size={16} /> {isGenerating ? 'Génération…' : 'Générer le PDF'}
          </button>
        </div>
      </section>

      {feedback && <p className="mt-4 text-sm font-medium text-emerald-600">{feedback}</p>}
    </div>
  );
}

export default MaintPlanWorkspace;
