import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import jsPDF from 'jspdf';
import { FileDown, FileText, Plus, Trash2 } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { downloadBlob } from '@/lib/downloadFile';
import { renderPdfTable } from '@/lib/renderPdfTable';
import { getCompanionStorageKey, writeDevisProHandoff } from '@/lib/companionHandoff';
import {
  BATTERIES,
  BURKINA_SOLAR,
  SOLAR_PANELS,
  computeDailyEnergyWh,
  formatKiloWattHour,
  formatNumber,
  formatWatt,
  formatWattHour,
  formatWattPeak,
  sizeSolarSet
} from '@/lib/solarSet';

const createId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

const applianceRow = (name = '', powerW = '', quantity = '1', hoursPerDay = '') => ({
  id: createId(),
  name,
  powerW,
  quantity,
  hoursPerDay
});

const today = () => new Date().toISOString().slice(0, 10);

const toNumber = (value) => {
  const parsed = Number(String(value ?? '').replace(/\s+/g, '').replace(',', '.'));
  return Number.isFinite(parsed) ? parsed : 0;
};

const buildInitialValues = (technician) => ({
  projectName: '',
  clientName: '',
  cityName: 'Ouagadougou',
  autonomyDays: '1',
  simultaneityFactor: '0.8',
  panelId: SOLAR_PANELS[2]?.id || '',
  batteryId: BATTERIES.find((b) => b.id === 'lif48-100')?.id || '',
  appliances: [applianceRow('', '', '1', '')],
  companyName: technician?.name || '',
  issueDate: today()
});

function NumericInput({ value, onChange, step = 'any', min = '0' }) {
  return (
    <input
      type="text"
      inputMode="decimal"
      value={value}
      step={step}
      min={min}
      onChange={(event) => onChange(event.target.value)}
      className="w-full min-w-0 rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-center text-sm text-slate-900 [font-variant-numeric:tabular-nums] outline-none transition focus:border-[#3A8E9C]"
    />
  );
}

function MobileTableLabel({ children }) {
  return <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500 md:hidden">{children}</span>;
}

const UiTable = /** @type {any} */ (Table);
const UiTableBody = /** @type {any} */ (TableBody);
const UiTableCell = /** @type {any} */ (TableCell);
const UiTableHead = /** @type {any} */ (TableHead);
const UiTableHeader = /** @type {any} */ (TableHeader);
const UiTableRow = /** @type {any} */ (TableRow);

async function generateSolarPdf(app, values, sizing) {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 46;

  const writeLine = (text, size = 11, weight = 'normal', gap = 16) => {
    doc.setFont('helvetica', weight);
    doc.setFontSize(size);
    doc.setTextColor(0, 0, 0);
    const lines = doc.splitTextToSize(text, pageWidth - 80);
    doc.text(lines, 40, y);
    y += (lines.length * (size + 4)) + gap;
  };

  writeLine(app.name, 20, 'bold', 8);
  writeLine(app.tagline, 11, 'normal', 12);
  if (values.projectName) writeLine(`Projet : ${values.projectName}`, 10, 'normal', 6);
  if (values.clientName) writeLine(`Client : ${values.clientName}`, 10, 'normal', 6);
  writeLine(
    `Localisation : ${values.cityName || 'Burkina Faso'} — généré le ${new Date().toLocaleDateString('fr-FR')}`,
    10,
    'normal',
    16
  );

  // Hypothèses de calcul
  writeLine('Hypothèses (conditions Burkina Faso)', 12, 'bold', 6);
  writeLine(
    `Ensoleillement retenu : ${sizing.conditions.peakSunHours} kWh/m²/jour (plage ${sizing.conditions.peakSunHoursMin}–${sizing.conditions.peakSunHoursMax}) • Rendement système : ${Math.round(sizing.conditions.performanceRatio * 100)}% • Autonomie : ${formatNumber(toNumber(values.autonomyDays), 0)} jour(s)`,
    9.5,
    'normal',
    14
  );

  // Inventaire des appareils
  y = renderPdfTable(doc, {
    startY: y,
    columns: [
      { key: 'name', label: 'Appareil', width: 2.2 },
      { key: 'power', label: 'Puissance (W)', width: 1, align: 'right' },
      { key: 'quantity', label: 'Qté', width: 0.7, align: 'right' },
      { key: 'hours', label: 'h/jour', width: 0.8, align: 'right' },
      { key: 'energy', label: 'Wh/jour', width: 1, align: 'right' }
    ],
    rows: values.appliances
      .filter((row) => row.name.trim() || toNumber(row.powerW) > 0)
      .map((row) => ({
        name: row.name.trim() || '—',
        power: formatNumber(toNumber(row.powerW)),
        quantity: formatNumber(toNumber(row.quantity)),
        hours: formatNumber(toNumber(row.hoursPerDay), 1),
        energy: formatNumber(toNumber(row.powerW) * toNumber(row.quantity) * toNumber(row.hoursPerDay))
      })),
    marginX: 24
  });

  y += 18;
  writeLine('Dimensionnement recommandé', 12, 'bold', 8);

  y = renderPdfTable(doc, {
    startY: y,
    columns: [
      { key: 'label', label: 'Élément', width: 2 },
      { key: 'value', label: 'Résultat', width: 1.4, align: 'right' }
    ],
    rows: [
      { label: 'Besoin énergétique quotidien', value: formatWattHour(sizing.dailyEnergyWh) },
      { label: 'Puissance crête du local', value: formatWatt(sizing.peakLoadW) },
      { label: 'Panneaux solaires', value: `${sizing.pv.panelCount} × ${sizing.panel?.wattPeak || 0} Wc` },
      { label: 'Puissance champ installée', value: formatWattPeak(sizing.pv.installedArrayWp) },
      { label: 'Batteries', value: `${sizing.batteryBank.totalBatteries} × ${sizing.battery?.label || '—'}` },
      { label: 'Configuration batteries', value: `${sizing.batteryBank.seriesCount}S ${sizing.batteryBank.parallelCount}P (${sizing.batteryBank.bankVoltage} V)` },
      { label: 'Capacité utile du parc', value: formatWattHour(sizing.batteryBank.bankUsableWh) },
      { label: 'Onduleur recommandé', value: `${formatWatt(sizing.inverter?.watt || 0)} / ${sizing.systemVoltage} V` }
    ],
    marginX: 24
  });

  y += 16;
  writeLine(
    'Document indicatif établi selon un inventaire déclaratif et des conditions d’ensoleillement moyennes du Burkina Faso. À valider sur site.',
    8.5,
    'normal',
    0
  );

  return downloadBlob(
    doc.output('blob'),
    `${app.filenamePrefix}-${values.issueDate || today()}.pdf`
  );
}

export function SolarSetWorkspace({ app, technician, standalone = false }) {
  const navigate = useNavigate();
  const storageKey = useMemo(
    () => getCompanionStorageKey(app.slug, technician),
    [app.slug, technician?.id, technician?.email, technician?.name, technician?.phone]
  );
  const [values, setValues] = useState(() => buildInitialValues(technician));
  const [feedback, setFeedback] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    const initialValues = buildInitialValues(technician);
    try {
      const raw = window.localStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          setValues({
            ...initialValues,
            ...parsed,
            appliances: Array.isArray(parsed.appliances) && parsed.appliances.length > 0
              ? parsed.appliances.map((row) => ({ ...applianceRow(), ...row }))
              : [applianceRow()]
          });
          setFeedback('Brouillon rechargé automatiquement.');
          return;
        }
      }
    } catch {
      // Chargement du brouillon non bloquant.
    }
    setValues(initialValues);
    setFeedback('');
  }, [storageKey, technician?.name]);

  useEffect(() => {
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(values));
    } catch {
      // Autosave non bloquante.
    }
  }, [storageKey, values]);

  const sizing = useMemo(
    () => sizeSolarSet({
      inventory: values.appliances,
      autonomyDays: values.autonomyDays,
      panelId: values.panelId,
      batteryId: values.batteryId,
      simultaneityFactor: values.simultaneityFactor,
      conditions: BURKINA_SOLAR
    }),
    [values.appliances, values.autonomyDays, values.panelId, values.batteryId, values.simultaneityFactor]
  );

  const dailyEnergy = useMemo(() => computeDailyEnergyWh(values.appliances), [values.appliances]);

  const updateField = (name, value) => {
    setValues((current) => ({ ...current, [name]: value }));
    setFeedback('');
  };

  const handleApplianceChange = (rowId, field, value) => {
    setValues((current) => ({
      ...current,
      appliances: current.appliances.map((row) => (row.id === rowId ? { ...row, [field]: value } : row))
    }));
    setFeedback('');
  };

  const addAppliance = () => {
    setValues((current) => ({ ...current, appliances: [...current.appliances, applianceRow()] }));
    setFeedback('');
  };

  const removeAppliance = (rowId) => {
    setValues((current) => ({
      ...current,
      appliances: current.appliances.length === 1 ? current.appliances : current.appliances.filter((row) => row.id !== rowId)
    }));
    setFeedback('');
  };

  const handleGenerate = async () => {
    if (!sizing.valid) {
      setFeedback('Complétez l’inventaire, l’autonomie et les choix panneau/batterie pour dimensionner.');
      return;
    }
    setIsGenerating(true);
    try {
      const result = await generateSolarPdf(app, values, sizing);
      setFeedback(result?.message || 'Dimensionnement PDF prêt, téléchargement démarré.');
    } catch (error) {
      setFeedback(error instanceof Error && error.message
        ? error.message
        : 'La génération du PDF a échoué. Vérifiez les données puis réessayez.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleTransferToDevis = () => {
    if (!sizing.valid) {
      setFeedback('Complétez le dimensionnement avant de créer un devis.');
      return;
    }
    const rows = [
      { designation: `Panneau solaire ${sizing.panel?.wattPeak || 0} Wc`, quantity: String(sizing.pv.panelCount), unitPrice: '' },
      { designation: `Batterie ${sizing.battery?.label || ''}`, quantity: String(sizing.batteryBank.totalBatteries), unitPrice: '' },
      { designation: `Onduleur hybride ${formatWatt(sizing.inverter?.watt || 0)} / ${sizing.systemVoltage} V`, quantity: '1', unitPrice: '' }
    ];
    const notes = [
      `Dimensionnement solaire ${values.cityName ? `— ${values.cityName}` : ''}`,
      `Besoin : ${formatWattHour(sizing.dailyEnergyWh)}/jour, autonomie ${formatNumber(toNumber(values.autonomyDays))} jour(s).`,
      `Champ PV : ${sizing.pv.panelCount} × ${sizing.panel?.wattPeak || 0} Wc (${formatWattPeak(sizing.pv.installedArrayWp)}).`,
      `Batteries : ${sizing.batteryBank.totalBatteries} × ${sizing.battery?.label || ''} (${sizing.batteryBank.seriesCount}S ${sizing.batteryBank.parallelCount}P).`,
      'Complétez les prix unitaires pour finaliser le devis.'
    ].join('\n');

    const ok = writeDevisProHandoff(technician, {
      clientName: values.clientName || '',
      companyName: values.companyName || '',
      issueDate: values.issueDate || today(),
      notes,
      rows
    });
    if (!ok) {
      setFeedback('Transfert impossible sur cet appareil. Vous pouvez générer le PDF à la place.');
      return;
    }
    navigate('/devispro');
  };

  const selectClass = 'w-full rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]';
  const fieldClass = 'rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]';

  return (
    <div className={standalone ? 'glass rounded-2xl p-5' : 'p-5 sm:p-6'}>
      <h2 className="text-2xl font-semibold tracking-tight text-slate-900">{app.name}</h2>
      <p className="mt-1 text-sm text-slate-600">{app.description}</p>

      <section className="mt-5 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">1. Informations du projet</h3>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Nom du projet
            <input type="text" value={values.projectName} onChange={(e) => updateField('projectName', e.target.value)} className={fieldClass} placeholder="Ex. Villa Zogona" />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Client
            <input type="text" value={values.clientName} onChange={(e) => updateField('clientName', e.target.value)} className={fieldClass} placeholder="Nom du client" />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Ville / localité
            <input type="text" value={values.cityName} onChange={(e) => updateField('cityName', e.target.value)} className={fieldClass} placeholder="Ouagadougou, Bobo-Dioulasso…" />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Autonomie souhaitée (jours sans soleil)
            <NumericInput value={values.autonomyDays} onChange={(value) => updateField('autonomyDays', value)} />
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Facteur de simultanéité (0 à 1)
            <NumericInput value={values.simultaneityFactor} onChange={(value) => updateField('simultaneityFactor', value)} />
          </label>
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">2. Inventaire des appareils (besoin du local)</h3>
        <div className="mt-3 flex justify-end">
          <button type="button" onClick={addAppliance} className="inline-flex items-center justify-center gap-2 rounded-full border border-[#3A8E9C]/30 bg-white px-4 py-2 text-sm font-semibold text-[#3A8E9C] transition hover:bg-white/70">
            <Plus size={16} /> Ajouter un appareil
          </button>
        </div>
        <div className="mt-4 overflow-x-auto">
          <UiTable className="w-full md:min-w-[720px]">
            <UiTableHeader className="hidden md:table-header-group">
              <UiTableRow className="bg-white hover:bg-white">
                <UiTableHead className="px-2 text-slate-700">Appareil</UiTableHead>
                <UiTableHead className="text-slate-700">Puissance (W)</UiTableHead>
                <UiTableHead className="text-slate-700">Quantité</UiTableHead>
                <UiTableHead className="text-slate-700">Heures/jour</UiTableHead>
                <UiTableHead className="text-slate-700">Wh/jour</UiTableHead>
                <UiTableHead className="w-[64px] text-right text-slate-700">Action</UiTableHead>
              </UiTableRow>
            </UiTableHeader>
            <UiTableBody>
              {values.appliances.map((row) => (
                <UiTableRow key={row.id} className="block space-y-3 px-2 py-4 md:table-row md:space-y-0 md:px-0 md:py-0">
                  <UiTableCell className="block border-0 px-0 py-0 align-top md:table-cell md:p-2">
                    <div className="grid gap-1.5">
                      <MobileTableLabel>Appareil</MobileTableLabel>
                      <input type="text" value={row.name} onChange={(e) => handleApplianceChange(row.id, 'name', e.target.value)} className="w-full min-w-0 rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-[#3A8E9C]" placeholder="Frigo, TV, pompe…" />
                    </div>
                  </UiTableCell>
                  <UiTableCell className="block border-0 px-0 py-0 align-top md:table-cell md:p-2">
                    <div className="grid gap-1.5"><MobileTableLabel>Puissance (W)</MobileTableLabel><NumericInput value={row.powerW} onChange={(v) => handleApplianceChange(row.id, 'powerW', v)} /></div>
                  </UiTableCell>
                  <UiTableCell className="block border-0 px-0 py-0 align-top md:table-cell md:p-2">
                    <div className="grid gap-1.5"><MobileTableLabel>Quantité</MobileTableLabel><NumericInput value={row.quantity} onChange={(v) => handleApplianceChange(row.id, 'quantity', v)} /></div>
                  </UiTableCell>
                  <UiTableCell className="block border-0 px-0 py-0 align-top md:table-cell md:p-2">
                    <div className="grid gap-1.5"><MobileTableLabel>Heures/jour</MobileTableLabel><NumericInput value={row.hoursPerDay} onChange={(v) => handleApplianceChange(row.id, 'hoursPerDay', v)} /></div>
                  </UiTableCell>
                  <UiTableCell className="block border-0 px-0 py-0 align-top md:table-cell md:p-2">
                    <div className="grid gap-1.5"><MobileTableLabel>Wh/jour</MobileTableLabel><div className="rounded-xl border border-[#D3CCBE] bg-[#F3EFE7] px-3 py-2 text-sm font-semibold text-slate-900">{formatNumber(toNumber(row.powerW) * toNumber(row.quantity) * toNumber(row.hoursPerDay))}</div></div>
                  </UiTableCell>
                  <UiTableCell className="block border-0 px-0 py-0 align-top md:table-cell md:text-right">
                    <div className="grid gap-1.5 md:flex md:justify-end">
                      <MobileTableLabel>Action</MobileTableLabel>
                      <button type="button" onClick={() => removeAppliance(row.id)} disabled={values.appliances.length === 1} className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-[#D3CCBE] text-slate-500 transition hover:border-red-200 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-40" aria-label="Supprimer l'appareil">
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </UiTableCell>
                </UiTableRow>
              ))}
            </UiTableBody>
          </UiTable>
        </div>
        <p className="mt-3 text-sm font-semibold text-slate-700">Besoin quotidien total : <span className="text-[#3A8E9C]">{formatWattHour(dailyEnergy)}</span> ({formatKiloWattHour(dailyEnergy)})</p>
      </section>

      <section className="mt-6 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
        <h3 className="text-sm font-semibold text-slate-900">3. Choix des équipements</h3>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Modèle de panneau solaire
            <select value={values.panelId} onChange={(e) => updateField('panelId', e.target.value)} className={selectClass}>
              {SOLAR_PANELS.map((panel) => <option key={panel.id} value={panel.id}>{panel.label}</option>)}
            </select>
          </label>
          <label className="grid gap-1 text-xs font-semibold text-slate-700">
            Modèle de batterie
            <select value={values.batteryId} onChange={(e) => updateField('batteryId', e.target.value)} className={selectClass}>
              {BATTERIES.map((battery) => <option key={battery.id} value={battery.id}>{battery.label}</option>)}
            </select>
          </label>
        </div>
        <p className="mt-3 text-xs text-slate-500">
          L'onduleur est recommandé automatiquement selon la puissance crête du local (marge de sécurité incluse).
        </p>
      </section>

      <section className="mt-6 rounded-2xl border border-[#3A8E9C]/25 bg-[#3A8E9C]/5 p-4">
        <h3 className="text-sm font-semibold text-slate-900">4. Résultats du dimensionnement</h3>
        {!sizing.valid ? (
          <p className="mt-2 text-sm text-slate-600">Renseignez l'inventaire, l'autonomie et les équipements pour afficher les résultats.</p>
        ) : (
          <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {[
              ['Panneaux nécessaires', `${sizing.pv.panelCount} × ${sizing.panel?.wattPeak || 0} Wc`],
              ['Puissance installée', formatWattPeak(sizing.pv.installedArrayWp)],
              ['Batteries nécessaires', `${sizing.batteryBank.totalBatteries} (${sizing.batteryBank.seriesCount}S ${sizing.batteryBank.parallelCount}P)`],
              ['Onduleur recommandé', `${formatWatt(sizing.inverter?.watt || 0)} / ${sizing.systemVoltage} V`]
            ].map(([label, value]) => (
              <div key={label} className="rounded-2xl border border-[#D3CCBE] bg-white px-4 py-3">
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">{label}</p>
                <p className="mt-2 text-base font-semibold text-slate-900">{value}</p>
              </div>
            ))}
          </div>
        )}
        {sizing.valid && (
          <div className="mt-3 grid gap-2 text-xs text-slate-600 sm:grid-cols-2">
            <p>Besoin quotidien : <strong>{formatWattHour(sizing.dailyEnergyWh)}</strong></p>
            <p>Puissance crête local : <strong>{formatWatt(sizing.peakLoadW)}</strong></p>
            <p>Capacité utile parc batterie : <strong>{formatWattHour(sizing.batteryBank.bankUsableWh)}</strong></p>
            <p>Modèle batterie : <strong>{sizing.battery?.label || '—'}</strong></p>
          </div>
        )}
      </section>

      <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-end">
        <button type="button" onClick={handleTransferToDevis} disabled={!sizing.valid} className="inline-flex items-center justify-center gap-2 rounded-full border border-[#3A8E9C]/30 bg-white px-4 py-2 text-sm font-semibold text-[#3A8E9C] transition hover:bg-[#FCFBF8] disabled:cursor-not-allowed disabled:opacity-40">
          <FileText size={16} /> Créer un devis dans DevisPro
        </button>
        <button type="button" onClick={handleGenerate} disabled={isGenerating || !sizing.valid} className="primary-button disabled:cursor-not-allowed disabled:opacity-60">
          <FileDown size={16} /> {isGenerating ? 'Génération…' : 'Générer le PDF'}
        </button>
      </div>

      {feedback && <p className="mt-3 text-sm font-medium text-emerald-600">{feedback}</p>}
    </div>
  );
}

export default SolarSetWorkspace;
