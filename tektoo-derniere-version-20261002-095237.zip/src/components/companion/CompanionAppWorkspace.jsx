import React, { useEffect, useMemo, useState } from 'react';
import jsPDF from 'jspdf';
import QRCode from 'qrcode';
import { FileDown, Plus, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableFooter, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { TEKTOO_WHATSAPP_NUMBER } from '@/lib/companionApps';
import { downloadBlob } from '@/lib/downloadFile';
import { renderPdfTable } from '@/lib/renderPdfTable';
import { MaintPlanWorkspace } from '@/components/companion/MaintPlanWorkspace';
import { SolarSetWorkspace } from '@/components/companion/SolarSetWorkspace';
import { FrioPressWorkspace } from '@/components/companion/FrioPressWorkspace';
import { takeDevisProHandoff } from '@/lib/companionHandoff';

const normalizeGroupingSpace = (value) => String(value ?? '')
  .replace(/\u202F/g, ' ')
  .replace(/\u00A0/g, ' ')
  .replace(/\u2009/g, ' ')
  .replace(/\s+/g, ' ');

const normalizeNumber = (value) => {
  const parsed = Number(
    normalizeGroupingSpace(value)
      .replace(/\//g, '')
      .replace(/\s+/g, '')
      .replace(',', '.')
  );
  return Number.isFinite(parsed) ? parsed : 0;
};

const formatCurrency = (value) => normalizeGroupingSpace(new Intl.NumberFormat('fr-FR', {
  style: 'currency',
  currency: 'XOF',
  maximumFractionDigits: 0
}).format(normalizeNumber(value)));

const formatPdfCurrency = (value) => normalizeGroupingSpace(formatCurrency(value));

const formatNumericInputValue = (value) => {
  const raw = String(value ?? '').trim();
  if (!raw) return '';

  const normalized = normalizeGroupingSpace(raw)
    .replace(/\//g, '')
    .replace(/\s+/g, '')
    .replace(',', '.');

  if (!/^[-+]?\d*(\.\d*)?$/.test(normalized)) return raw;

  const sign = normalized.startsWith('-') ? '-' : '';
  const unsigned = normalized.replace(/^[-+]/, '');
  if (!unsigned) return '';

  const [integerPart = '0', decimalPart] = unsigned.split('.');
  const groupedInteger = (integerPart.replace(/\D/g, '') || '0')
    .replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

  if (decimalPart === undefined) return `${sign}${groupedInteger}`;
  const decimalDigits = decimalPart.replace(/\D/g, '');
  if (!decimalDigits && unsigned.endsWith('.')) return `${sign}${groupedInteger},`;
  return decimalDigits ? `${sign}${groupedInteger},${decimalDigits}` : `${sign}${groupedInteger}`;
};

const today = () => new Date().toISOString().slice(0, 10);
const clampIsoDate = (value, min, max) => {
  if (!value) return '';
  if (min && value < min) return min;
  if (max && value > max) return max;
  return value;
};
const isValidIsoDate = (value) => {
  const normalized = String(value ?? '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(normalized)) return false;
  const parsed = new Date(`${normalized}T00:00:00Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === normalized;
};
const formatDateLabel = (value) => {
  if (!value) return '—';
  const parsed = new Date(`${value}T00:00:00`);
  return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleDateString('fr-FR');
};
const createId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const moneyRow = (date = today()) => ({ id: createId(), date, income: '', expense: '', savings: '' });
const quoteRow = () => ({ id: createId(), designation: '', quantity: '1', unitPrice: '' });
const moneyProfit = (row) => normalizeNumber(row.income) - normalizeNumber(row.expense);
const quoteLineTotal = (row) => Math.max(normalizeNumber(row.quantity), 0) * Math.max(normalizeNumber(row.unitPrice), 0);
const moneyHasAnyAmount = (row) => ['income', 'expense', 'savings'].some((field) => String(row?.[field] ?? '').trim() !== '');
const getStorageKey = (app, technician) => {
  const identity = technician?.id || technician?.email || technician?.phone || technician?.name || 'anonymous';
  return `tektoo:companion:${app.slug}:${String(identity).trim().toLowerCase()}`;
};
const sortMoneyRows = (rows) => [...rows].sort((left, right) => left.date.localeCompare(right.date));
const getMoneyDateBounds = (rows) => {
  const maxDate = today();
  const datedRows = (Array.isArray(rows) ? rows : [])
    .map((row) => row?.date)
    .filter((value) => isValidIsoDate(value))
    .sort((a, b) => a.localeCompare(b));
  const minDate = datedRows[0] || maxDate;
  return { minDate, maxDate };
};
const clampMoneyPeriod = (values, minDate, maxDate) => {
  const startDate = clampIsoDate(values.startDate || minDate, minDate, maxDate);
  let endDate = clampIsoDate(values.endDate || maxDate, minDate, maxDate);
  if (startDate && endDate && startDate > endDate) {
    endDate = startDate;
  }
  return { startDate, endDate };
};
const getNextMoneyDraftDate = (rows, maxDate = today()) => {
  const latestDate = sortMoneyRows(
    (Array.isArray(rows) ? rows : []).filter((row) => isValidIsoDate(row?.date))
  ).at(-1)?.date;

  if (!latestDate || latestDate >= maxDate) return maxDate;

  const nextDate = new Date(`${latestDate}T00:00:00Z`);
  nextDate.setUTCDate(nextDate.getUTCDate() + 1);
  return clampIsoDate(nextDate.toISOString().slice(0, 10), '', maxDate);
};

const getMoneyRowsInPeriod = (rows, startDate, endDate) => rows.filter((row) => {
  if (startDate && row.date && row.date < startDate) return false;
  if (endDate && row.date && row.date > endDate) return false;
  return true;
});

const getMoneyTotals = (rows) => rows.reduce((totals, row) => ({
  income: totals.income + normalizeNumber(row.income),
  expense: totals.expense + normalizeNumber(row.expense),
  profit: totals.profit + moneyProfit(row),
  savings: totals.savings + normalizeNumber(row.savings)
}), { income: 0, expense: 0, profit: 0, savings: 0 });

const getQuoteTotals = (values) => {
  const subtotal = values.rows.reduce((sum, row) => sum + quoteLineTotal(row), 0);
  const labor = Math.max(normalizeNumber(values.labor), 0);
  const discount = Math.max(normalizeNumber(values.discount), 0);
  const vatRate = Math.max(normalizeNumber(values.vatRate), 0);
  const taxableBase = Math.max(subtotal + labor - discount, 0);
  const vatAmount = taxableBase * (vatRate / 100);
  return {
    subtotal,
    labor,
    discount,
    vatRate,
    taxableBase,
    vatAmount,
    total: taxableBase + vatAmount
  };
};

const sanitizePhoneNumber = (value) => String(value ?? '').replace(/[^\d+]/g, '');
const qrTargetForPhone = (value, mode = 'whatsapp') => {
  const phone = sanitizePhoneNumber(value);
  const digitsOnly = phone.replace(/\D/g, '');
  if (mode === 'phone') return phone ? `tel:${phone}` : `tel:+${TEKTOO_WHATSAPP_NUMBER}`;
  return digitsOnly ? `https://wa.me/${digitsOnly}` : `https://wa.me/${TEKTOO_WHATSAPP_NUMBER}`;
};

const buildInitialValues = (app, technician) => {
  if (app.slug === 'moneygest') {
    const currentDate = today();
    return {
      startDate: currentDate,
      endDate: currentDate,
      rows: [],
      draftRow: moneyRow(currentDate)
    };
  }

  return {
    clientName: '',
    companyName: technician?.name || '',
    issueDate: today(),
    phoneNumber: technician?.whatsapp || TEKTOO_WHATSAPP_NUMBER,
    contactMode: 'whatsapp',
    labor: '',
    vatRate: String(app.defaultVatRate ?? 18),
    discount: '',
    notes: '',
    rows: [quoteRow()]
  };
};

const ModalContent = /** @type {any} */ (DialogContent);
const ModalTitle = /** @type {any} */ (DialogTitle);
const ModalDescription = /** @type {any} */ (DialogDescription);
const UiTable = /** @type {any} */ (Table);
const UiTableBody = /** @type {any} */ (TableBody);
const UiTableCell = /** @type {any} */ (TableCell);
const UiTableFooter = /** @type {any} */ (TableFooter);
const UiTableHead = /** @type {any} */ (TableHead);
const UiTableHeader = /** @type {any} */ (TableHeader);
const UiTableRow = /** @type {any} */ (TableRow);

async function generateMoneyPdf(app, values) {
  const rows = getMoneyRowsInPeriod(values.rows, values.startDate, values.endDate);
  const totals = getMoneyTotals(rows);
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 46;

  const writeLine = (text, size = 11, weight = 'normal', gap = 18) => {
    doc.setFont('helvetica', weight);
    doc.setFontSize(size);
    doc.setTextColor(0, 0, 0);
    const lines = doc.splitTextToSize(text, pageWidth - 80);
    doc.text(lines, 40, y);
    y += (lines.length * (size + 4)) + gap;
  };

  writeLine(app.name, 20, 'bold', 8);
  writeLine(app.tagline, 11, 'normal', 12);
  writeLine(`Bilan du ${formatDateLabel(values.startDate)} au ${formatDateLabel(values.endDate)} — généré le ${new Date().toLocaleDateString('fr-FR')}`, 10, 'normal', 16);

  y = renderPdfTable(doc, {
    startY: y,
    columns: [
      { key: 'date', label: 'Date', width: 1.1 },
      { key: 'income', label: 'Entrées', width: 1, align: 'right' },
      { key: 'expense', label: 'Sorties', width: 1, align: 'right' },
      { key: 'profit', label: 'Bénéfice', width: 1, align: 'right' },
      { key: 'savings', label: 'Épargne', width: 1, align: 'right' }
    ],
    rows: rows.map((row) => ({
      date: formatDateLabel(row.date),
      income: formatPdfCurrency(row.income),
      expense: formatPdfCurrency(row.expense),
      profit: formatPdfCurrency(moneyProfit(row)),
      savings: formatPdfCurrency(row.savings)
    })),
    marginX: 24
  });

  y += 18;
  writeLine(`Totaux de la période — Entrées : ${formatPdfCurrency(totals.income)} | Sorties : ${formatPdfCurrency(totals.expense)} | Bénéfice : ${formatPdfCurrency(totals.profit)} | Épargne : ${formatPdfCurrency(totals.savings)}`, 10, 'bold', 10);
  return downloadBlob(
    doc.output('blob'),
    `${app.filenamePrefix}-${values.startDate || today()}-${values.endDate || today()}.pdf`
  );
}

async function generateQuotePdf(app, values, qrCodeDataUrl) {
  const totals = getQuoteTotals(values);
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 40;

  const writeLine = (text, x, currentY, size = 11, weight = 'normal') => {
    doc.setFont('helvetica', weight);
    doc.setFontSize(size);
    doc.setTextColor(0, 0, 0);
    doc.text(text, x, currentY);
  };

  writeLine(app.name, 40, y, 20, 'bold');
  writeLine(app.tagline, 40, y + 20, 11, 'normal');
  writeLine(`Date du devis : ${values.issueDate || '—'}`, 40, y + 48, 10, 'normal');
  writeLine(`Client : ${values.clientName || '—'}`, 40, y + 64, 10, 'normal');
  writeLine(`Entreprise : ${values.companyName || '—'}`, 40, y + 80, 10, 'normal');
  writeLine(`Téléphone / WhatsApp : ${values.phoneNumber || '—'}`, 40, y + 96, 10, 'normal');

  if (qrCodeDataUrl) {
    doc.addImage(qrCodeDataUrl, 'PNG', pageWidth - 102, 34, 62, 62);
    writeLine(`QR ${values.contactMode === 'phone' ? 'téléphone' : 'WhatsApp'}`, pageWidth - 110, 108, 8, 'bold');
  }

  y = renderPdfTable(doc, {
    startY: 140,
    columns: [
      { key: 'designation', label: 'Désignation', width: 2.3 },
      { key: 'quantity', label: 'Qté', width: 0.7, align: 'right' },
      { key: 'unitPrice', label: 'Prix unitaire', width: 1, align: 'right' },
      { key: 'lineTotal', label: 'Total ligne', width: 1.1, align: 'right' }
    ],
    rows: values.rows.map((row) => ({
      designation: row.designation || '—',
      quantity: String(Math.max(normalizeNumber(row.quantity), 0)),
      unitPrice: formatPdfCurrency(row.unitPrice),
      lineTotal: formatPdfCurrency(quoteLineTotal(row))
    })),
    marginX: 24
  });

  y += 22;
  y = renderPdfTable(doc, {
    startY: y,
    columns: [
      { key: 'label', label: 'Récapitulatif', width: 1.7 },
      { key: 'value', label: 'Montant', width: 1, align: 'right' }
    ],
    rows: [
      { label: 'Sous-total', value: formatPdfCurrency(totals.subtotal) },
      { label: 'Main d’œuvre', value: formatPdfCurrency(totals.labor) },
      { label: 'Remise', value: formatPdfCurrency(totals.discount) },
      { label: `TVA (${totals.vatRate}%)`, value: formatPdfCurrency(totals.vatAmount) },
      { label: 'Prix total', value: formatPdfCurrency(totals.total) }
    ],
    marginX: 24
  });

  if (values.notes.trim()) {
    const noteLines = doc.splitTextToSize(values.notes.trim(), pageWidth - 48);
    const pageHeight = doc.internal.pageSize.getHeight();
    let noteY = y;
    let cursor = 0;
    let title = 'Notes';

    while (cursor < noteLines.length) {
      if (noteY + 36 > pageHeight - 40) {
        doc.addPage();
        noteY = 40;
      }

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.text(title, 40, noteY + 16);
      doc.setFont('helvetica', 'normal');

      const textStartY = noteY + 32;
      const availableLines = Math.max(Math.floor((pageHeight - 40 - textStartY) / 14), 1);
      const chunk = noteLines.slice(cursor, cursor + availableLines);
      doc.text(chunk, 40, textStartY);

      cursor += chunk.length;
      noteY = textStartY + (chunk.length * 14) + 10;
      title = 'Notes (suite)';
    }
  }

  return downloadBlob(
    doc.output('blob'),
    `${app.filenamePrefix}-${values.issueDate || today()}.pdf`
  );
}

async function generatePdf(app, values, qrCodeDataUrl) {
  if (app.slug === 'moneygest') {
    return generateMoneyPdf(app, values);
  }

  return generateQuotePdf(app, values, qrCodeDataUrl);
}

function NumericInput({ value, onChange, min = '0', step = 'any' }) {
  return (
    <input
      type="text"
      inputMode="decimal"
      value={value}
      onChange={(event) => onChange(event.target.value)}
      onBlur={(event) => onChange(formatNumericInputValue(event.target.value))}
      min={min}
      step={step}
      className="w-full min-w-0 rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-center text-sm text-slate-900 [font-variant-numeric:tabular-nums] outline-none transition focus:border-[#3A8E9C] sm:min-w-[96px]"
    />
  );
}

function MobileTableLabel({ children }) {
  return <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500 md:hidden">{children}</span>;
}

export function CompanionAppWorkspace({ app, technician, standalone = false }) {
  const [values, setValues] = useState(() => /** @type {any} */ (buildInitialValues(app, technician)));
  const [feedback, setFeedback] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState('');
  const [pendingMoneyUpdateDate, setPendingMoneyUpdateDate] = useState('');
  const [hasFutureMoneyDraftDate, setHasFutureMoneyDraftDate] = useState(false);
  const storageKey = useMemo(
    () => getStorageKey(app, technician),
    [app.slug, technician?.email, technician?.id, technician?.name, technician?.phone]
  );
  const moneyDateBounds = useMemo(() => getMoneyDateBounds(values.rows), [values.rows]);

  useEffect(() => {
    const initialValues = buildInitialValues(app, technician);
    if (app.slug === 'devispro') {
      const handoff = takeDevisProHandoff(technician);
      if (handoff) {
        const handoffRows = Array.isArray(handoff.rows) && handoff.rows.length > 0
          ? handoff.rows.map((row) => ({ ...quoteRow(), ...row }))
          : [quoteRow()];
        setValues({
          ...initialValues,
          clientName: handoff.clientName ?? initialValues.clientName,
          companyName: handoff.companyName ?? initialValues.companyName,
          issueDate: isValidIsoDate(handoff.issueDate) ? handoff.issueDate : initialValues.issueDate,
          notes: handoff.notes ?? initialValues.notes,
          rows: handoffRows
        });
        setPendingMoneyUpdateDate('');
        setHasFutureMoneyDraftDate(false);
        setQrCodeDataUrl('');
        setFeedback('Dimensionnement SolarSet importé. Complétez les prix unitaires.');
        return;
      }
    }
    try {
      const rawDraft = window.localStorage.getItem(storageKey);
      if (rawDraft) {
        const parsedDraft = JSON.parse(rawDraft);
        if (parsedDraft && typeof parsedDraft === 'object') {
          const nextValues = { ...initialValues, ...parsedDraft };
          if (app.slug === 'moneygest') {
            const maxDate = today();
            const normalizedRows = Array.isArray(nextValues.rows)
              ? sortMoneyRows(nextValues.rows.map((row) => {
                const rowDate = isValidIsoDate(row?.date) ? clampIsoDate(row.date, '', maxDate) : maxDate;
                return { ...moneyRow(rowDate), ...row, date: rowDate };
              }))
              : [];
            const bounds = getMoneyDateBounds(normalizedRows);
            const clampedPeriod = clampMoneyPeriod(nextValues, bounds.minDate, bounds.maxDate);
            nextValues.startDate = clampedPeriod.startDate;
            nextValues.endDate = clampedPeriod.endDate;
            nextValues.rows = normalizedRows;
            const savedDraftDate = isValidIsoDate(nextValues.draftRow?.date)
              ? clampIsoDate(nextValues.draftRow.date, bounds.minDate, bounds.maxDate)
              : '';
            const draftDate = savedDraftDate && !normalizedRows.some((row) => row.date === savedDraftDate)
              ? savedDraftDate
              : getNextMoneyDraftDate(normalizedRows, bounds.maxDate);
            nextValues.draftRow = { ...moneyRow(draftDate), ...nextValues.draftRow, date: draftDate };
          } else {
            nextValues.rows = Array.isArray(nextValues.rows) && nextValues.rows.length > 0
              ? nextValues.rows.map((row) => ({ ...quoteRow(), ...row }))
              : [quoteRow()];
          }
          setValues(nextValues);
          setPendingMoneyUpdateDate('');
          setHasFutureMoneyDraftDate(false);
          setFeedback('Brouillon rechargé automatiquement.');
          setQrCodeDataUrl('');
          return;
        }
      }
    } catch {
      // Draft loading errors are non-blocking.
    }
    setValues(initialValues);
    setPendingMoneyUpdateDate('');
    setHasFutureMoneyDraftDate(false);
    setFeedback('');
    setQrCodeDataUrl('');
  }, [app, storageKey, technician?.email, technician?.id, technician?.name, technician?.phone, technician?.whatsapp]);

  useEffect(() => {
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(values));
    } catch {
      // Autosave errors are non-blocking.
    }
  }, [storageKey, values]);

  useEffect(() => {
    if (app.slug !== 'moneygest') return;
    setValues((current) => {
      const clampedPeriod = clampMoneyPeriod(current, moneyDateBounds.minDate, moneyDateBounds.maxDate);
      if (clampedPeriod.startDate === current.startDate && clampedPeriod.endDate === current.endDate) return current;
      return { ...current, ...clampedPeriod };
    });
  }, [app.slug, moneyDateBounds.maxDate, moneyDateBounds.minDate]);

  useEffect(() => {
    if (app.slug !== 'devispro') return undefined;

    let active = true;
    const timer = window.setTimeout(() => {
      QRCode.toDataURL(qrTargetForPhone(values.phoneNumber, values.contactMode), {
        margin: 1,
        width: 180,
        color: { dark: '#334155', light: '#FFFFFF' }
      })
        .then((url) => {
          if (active) setQrCodeDataUrl(url);
        })
        .catch(() => {
          if (active) setQrCodeDataUrl('');
        });
    }, 180);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [app.slug, values.contactMode, values.phoneNumber]);

  const filteredMoneyRows = useMemo(() => app.slug === 'moneygest'
    ? getMoneyRowsInPeriod(values.rows, values.startDate, values.endDate)
    : [], [app.slug, values]);
  const moneyTotals = useMemo(() => getMoneyTotals(filteredMoneyRows), [filteredMoneyRows]);
  const quoteTotals = useMemo(() => app.slug === 'devispro' ? getQuoteTotals(values) : null, [app.slug, values]);

  const resetFeedback = () => setFeedback('');

  const handleMoneyPeriodChange = (name, value) => {
    setValues((current) => {
      const clampedValue = clampIsoDate(value, moneyDateBounds.minDate, moneyDateBounds.maxDate);
      const nextValues = { ...current, [name]: clampedValue };
      return { ...nextValues, ...clampMoneyPeriod(nextValues, moneyDateBounds.minDate, moneyDateBounds.maxDate) };
    });
    resetFeedback();
  };

  const handleMoneyDraftChange = (field, value) => {
    const isFutureDate = field === 'date' && isValidIsoDate(value) && value > moneyDateBounds.maxDate;
    setValues((current) => ({
      ...current,
      draftRow: {
        ...current.draftRow,
        [field]: field === 'date' ? clampIsoDate(value, '', moneyDateBounds.maxDate) : value
      }
    }));
    setPendingMoneyUpdateDate('');
    setHasFutureMoneyDraftDate(isFutureDate);
    resetFeedback();
  };

  const handleSaveMoneyDay = () => {
    const draftRow = values.draftRow || moneyRow(getNextMoneyDraftDate(values.rows, moneyDateBounds.maxDate));
    const draftDate = String(draftRow.date ?? '');

    if (hasFutureMoneyDraftDate) {
      setFeedback('La date de la journée ne peut pas dépasser aujourd’hui.');
      return;
    }

    if (!isValidIsoDate(draftDate)) {
      setFeedback('Choisissez une date valide pour enregistrer la journée.');
      return;
    }

    if (draftDate > today()) {
      setFeedback('La date de la journée ne peut pas dépasser aujourd’hui.');
      return;
    }

    const clampedDate = clampIsoDate(draftDate, '', moneyDateBounds.maxDate);

    if (!moneyHasAnyAmount(draftRow)) {
      setFeedback('Renseignez au moins un montant avant d’enregistrer la journée.');
      return;
    }

    const hasDuplicateDate = values.rows.some((row) => row.date === clampedDate);
    if (hasDuplicateDate && pendingMoneyUpdateDate !== clampedDate) {
      setPendingMoneyUpdateDate(clampedDate);
      setFeedback('Cette journée existe déjà. Cliquez encore pour la mettre à jour.');
      return;
    }

    setValues((current) => {
      const nextSavedRow = { ...moneyRow(clampedDate), ...draftRow, date: clampedDate };
      const nextRows = sortMoneyRows([
        ...current.rows.filter((row) => row.date !== clampedDate),
        nextSavedRow
      ]);
      const bounds = getMoneyDateBounds(nextRows);
      const periodValues = {
        ...current,
        rows: nextRows,
        startDate: !current.startDate || clampedDate < current.startDate ? clampedDate : current.startDate,
        endDate: !current.endDate || clampedDate > current.endDate ? clampedDate : current.endDate
      };
      return {
        ...periodValues,
        ...clampMoneyPeriod(periodValues, bounds.minDate, bounds.maxDate),
        draftRow: moneyRow(getNextMoneyDraftDate(nextRows, bounds.maxDate))
      };
    });
    setPendingMoneyUpdateDate('');
    setHasFutureMoneyDraftDate(false);
    setFeedback(hasDuplicateDate ? 'Journée mise à jour.' : 'Journée enregistrée.');
  };

  const handleQuoteMetaChange = (name, value) => {
    setValues((current) => ({ ...current, [name]: value }));
    resetFeedback();
  };

  const handleQuoteRowChange = (rowId, field, value) => {
    setValues((current) => ({
      ...current,
      rows: current.rows.map((row) => row.id === rowId ? { ...row, [field]: value } : row)
    }));
    resetFeedback();
  };

  const addQuoteRow = () => {
    setValues((current) => ({ ...current, rows: [...current.rows, quoteRow()] }));
    resetFeedback();
  };

  const removeQuoteRow = (rowId) => {
    setValues((current) => ({
      ...current,
      rows: current.rows.length === 1 ? current.rows : current.rows.filter((row) => row.id !== rowId)
    }));
    resetFeedback();
  };

  const handleGenerate = async () => {
    if (app.slug === 'moneygest' && filteredMoneyRows.length === 0) {
      setFeedback('Aucune ligne n’existe sur cette période. Ajustez les dates avant de générer le bilan PDF.');
      return;
    }
    setIsGenerating(true);
    try {
      let nextQrCode = qrCodeDataUrl;
      if (app.slug === 'devispro' && !nextQrCode) {
        nextQrCode = await QRCode.toDataURL(qrTargetForPhone(values.phoneNumber, values.contactMode), {
          margin: 1,
          width: 180,
          color: { dark: '#334155', light: '#FFFFFF' }
        });
      }
      const downloadResult = await generatePdf(app, values, nextQrCode);
      setFeedback(
        downloadResult?.message || 'Votre PDF en tableau est prêt et le téléchargement a démarré.'
      );
    } catch (error) {
      setFeedback(error instanceof Error && error.message
        ? error.message
        : 'La génération du PDF a échoué. Vérifiez les données saisies puis réessayez.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveDraft = () => {
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(values));
      setFeedback('Brouillon enregistré avec succès.');
    } catch {
      setFeedback('Impossible d’enregistrer le brouillon sur cet appareil.');
    }
  };

  const renderMoneyGest = () => {
    const currentDraftRow = values.draftRow || moneyRow(getNextMoneyDraftDate(values.rows, moneyDateBounds.maxDate));
    const isUpdatingSavedDay = Boolean(currentDraftRow.date) && pendingMoneyUpdateDate === currentDraftRow.date && values.rows.some((row) => row.date === currentDraftRow.date);
    const moneyFormTitle = isUpdatingSavedDay ? 'Modifier une journée' : 'Ajouter une journée';
    const moneyDateLabel = isUpdatingSavedDay ? 'Date de la journée à modifier' : 'Date du jour';

    return (
      <>
        <section className="mt-5">
          <h3 className="text-sm font-semibold text-slate-900">Totaux de la période</h3>
          <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
            {[
              ['Entrées', formatCurrency(moneyTotals.income)],
              ['Sorties', formatCurrency(moneyTotals.expense)],
              ['Bénéfice', formatCurrency(moneyTotals.profit)],
              ['Épargne', formatCurrency(moneyTotals.savings)],
              ['Jours', String(filteredMoneyRows.length)]
            ].map(([label, value]) => (
              <div key={label} className="rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] px-4 py-3">
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">{label}</p>
                <p className="mt-2 text-lg font-semibold text-slate-900">{value}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-6">
          <h3 className="text-sm font-semibold text-slate-900">Définir la période</h3>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <label className="grid gap-1 text-xs font-semibold text-slate-700">
              Début de période
              <input
                type="date"
                value={values.startDate}
                min={moneyDateBounds.minDate}
                max={moneyDateBounds.maxDate}
                onChange={(event) => handleMoneyPeriodChange('startDate', event.target.value)}
                className="rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]"
              />
            </label>
            <label className="grid gap-1 text-xs font-semibold text-slate-700">
              Fin de période
              <input
                type="date"
                value={values.endDate}
                min={moneyDateBounds.minDate}
                max={moneyDateBounds.maxDate}
                onChange={(event) => handleMoneyPeriodChange('endDate', event.target.value)}
                className="rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]"
              />
            </label>
          </div>
        </section>

        <section className="mt-6">
          <h3 className="text-sm font-semibold text-slate-900">{moneyFormTitle}</h3>
          <div className="mt-3 rounded-2xl border border-[#D3CCBE] bg-[#FCFBF8] p-4">
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <label className="grid gap-1 text-xs font-semibold text-slate-700">
                {moneyDateLabel}
                <input
                  type="date"
                  value={currentDraftRow.date}
                  max={moneyDateBounds.maxDate}
                  onChange={(event) => handleMoneyDraftChange('date', event.target.value)}
                  className="w-full rounded-xl border border-[#D3CCBE] bg-white px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]"
                />
              </label>
              <label className="grid gap-1 text-xs font-semibold text-slate-700">
                Entrées
                <NumericInput value={currentDraftRow.income} onChange={(value) => handleMoneyDraftChange('income', value)} />
              </label>
              <label className="grid gap-1 text-xs font-semibold text-slate-700">
                Sorties
                <NumericInput value={currentDraftRow.expense} onChange={(value) => handleMoneyDraftChange('expense', value)} />
              </label>
              <label className="grid gap-1 text-xs font-semibold text-slate-700">
                Épargne
                <NumericInput value={currentDraftRow.savings} onChange={(value) => handleMoneyDraftChange('savings', value)} />
              </label>
            </div>

            <div className="mt-3 grid gap-1.5">
              <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Bénéfice calculé</span>
              <div className="rounded-xl border border-[#D3CCBE] bg-[#F3EFE7] px-3 py-2 text-sm font-semibold text-slate-900">
                {formatCurrency(moneyProfit(currentDraftRow))}
              </div>
            </div>

            <div className="mt-4 flex justify-end">
              <button type="button" onClick={handleSaveMoneyDay} className="primary-button">
                {isUpdatingSavedDay ? 'Mettre à jour la journée' : 'Enregistrer la journée'}
              </button>
            </div>
          </div>
        </section>
      </>
    );
  };

  const renderDevisPro = () => (
    <>
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <label className="grid gap-1 text-xs font-semibold text-slate-700">
          Nom du client
          <input
            type="text"
            value={values.clientName}
            onChange={(event) => handleQuoteMetaChange('clientName', event.target.value)}
            className="rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]"
          />
        </label>
        <label className="grid gap-1 text-xs font-semibold text-slate-700">
          Nom de l'entreprise
          <input
            type="text"
            value={values.companyName}
            onChange={(event) => handleQuoteMetaChange('companyName', event.target.value)}
            className="rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]"
          />
        </label>
        <label className="grid gap-1 text-xs font-semibold text-slate-700">
          Téléphone / WhatsApp
          <input
            type="tel"
            value={values.phoneNumber}
            onChange={(event) => handleQuoteMetaChange('phoneNumber', event.target.value)}
            className="rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]"
          />
        </label>
        <label className="grid gap-1 text-xs font-semibold text-slate-700">
          Type de QR code
          <select
            value={values.contactMode}
            onChange={(event) => handleQuoteMetaChange('contactMode', event.target.value)}
            className="rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]"
          >
            <option value="whatsapp">WhatsApp</option>
            <option value="phone">Téléphone</option>
          </select>
        </label>
        <label className="grid gap-1 text-xs font-semibold text-slate-700">
          Date du devis
          <input
            type="date"
            value={values.issueDate}
            max={today()}
            onChange={(event) => handleQuoteMetaChange('issueDate', clampIsoDate(event.target.value, '', today()))}
            className="rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]"
          />
        </label>
        <label className="grid gap-1 text-xs font-semibold text-slate-700">
          Main d'œuvre
          <NumericInput value={values.labor} onChange={(value) => handleQuoteMetaChange('labor', value)} />
        </label>
        <label className="grid gap-1 text-xs font-semibold text-slate-700">
          TVA (%)
          <NumericInput value={values.vatRate} onChange={(value) => handleQuoteMetaChange('vatRate', value)} min="0" />
        </label>
        <label className="grid gap-1 text-xs font-semibold text-slate-700">
          Remise
          <NumericInput value={values.discount} onChange={(value) => handleQuoteMetaChange('discount', value)} />
        </label>
      </div>
      <label className="mt-4 grid gap-1 text-xs font-semibold text-slate-700">
        Notes
        <textarea
          rows={4}
          value={values.notes}
          onChange={(event) => handleQuoteMetaChange('notes', event.target.value)}
          className="w-full rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C]"
          placeholder="Ajoutez une précision utile à faire figurer dans le PDF."
        />
      </label>

      <div className="mt-5 flex justify-end">
        <button type="button" onClick={addQuoteRow} className="inline-flex items-center justify-center gap-2 rounded-full border border-[#3A8E9C]/30 bg-white px-4 py-2 text-sm font-semibold text-[#3A8E9C] transition hover:bg-[#FCFBF8]">
          <Plus size={16} /> Ajouter une ligne
        </button>
      </div>

      <div className="mt-5 overflow-x-auto">
        <UiTable className="w-full md:min-w-[760px]">
          <UiTableHeader className="hidden md:table-header-group">
            <UiTableRow className="bg-[#FCFBF8] hover:bg-[#FCFBF8]">
              <UiTableHead className="px-4 text-slate-700">Désignation</UiTableHead>
              <UiTableHead className="text-slate-700">Quantité</UiTableHead>
              <UiTableHead className="text-slate-700">Prix unitaire</UiTableHead>
              <UiTableHead className="text-slate-700">Prix total par désignation</UiTableHead>
              <UiTableHead className="w-[72px] text-right text-slate-700">Action</UiTableHead>
            </UiTableRow>
          </UiTableHeader>
          <UiTableBody>
            {values.rows.map((row) => (
              <UiTableRow key={row.id} className="block space-y-3 px-4 py-4 md:table-row md:space-y-0 md:px-0 md:py-0">
                <UiTableCell className="block border-0 px-0 py-0 align-top md:table-cell md:px-4 md:py-2">
                  <div className="grid gap-1.5">
                    <MobileTableLabel>Désignation</MobileTableLabel>
                    <input
                      type="text"
                      value={row.designation}
                      onChange={(event) => handleQuoteRowChange(row.id, 'designation', event.target.value)}
                      className="w-full min-w-0 rounded-xl border border-[#D3CCBE] bg-[#FCFBF8] px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-[#3A8E9C] md:min-w-[220px]"
                      placeholder="Prestations, matériaux, service…"
                    />
                  </div>
                </UiTableCell>
                <UiTableCell className="block border-0 px-0 py-0 align-top md:table-cell md:p-2">
                  <div className="grid gap-1.5">
                    <MobileTableLabel>Quantité</MobileTableLabel>
                    <NumericInput value={row.quantity} onChange={(value) => handleQuoteRowChange(row.id, 'quantity', value)} />
                  </div>
                </UiTableCell>
                <UiTableCell className="block border-0 px-0 py-0 align-top md:table-cell md:p-2">
                  <div className="grid gap-1.5">
                    <MobileTableLabel>Prix unitaire</MobileTableLabel>
                    <NumericInput value={row.unitPrice} onChange={(value) => handleQuoteRowChange(row.id, 'unitPrice', value)} />
                  </div>
                </UiTableCell>
                <UiTableCell className="block border-0 px-0 py-0 align-top md:table-cell md:p-2">
                  <div className="grid gap-1.5">
                    <MobileTableLabel>Prix total</MobileTableLabel>
                    <div className="rounded-xl border border-[#D3CCBE] bg-[#F3EFE7] px-3 py-2 text-sm font-semibold text-slate-900">
                      {formatCurrency(quoteLineTotal(row))}
                    </div>
                  </div>
                </UiTableCell>
                <UiTableCell className="block border-0 px-0 py-0 align-top md:table-cell md:text-right">
                  <div className="grid gap-1.5 md:flex md:justify-end">
                    <MobileTableLabel>Action</MobileTableLabel>
                    <button
                      type="button"
                      onClick={() => removeQuoteRow(row.id)}
                      disabled={values.rows.length === 1}
                      className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-[#D3CCBE] text-slate-500 transition hover:border-red-200 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-40"
                      aria-label="Supprimer la ligne"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </UiTableCell>
              </UiTableRow>
            ))}
          </UiTableBody>
          <UiTableFooter className="bg-[#FCFBF8]">
            <UiTableRow className="block space-y-3 px-4 py-4 hover:bg-[#FCFBF8] md:table-row md:space-y-0 md:px-0 md:py-0">
              <UiTableCell className="block border-0 px-0 py-0 font-semibold text-slate-700 md:table-cell md:px-4 md:py-2">Sous-total</UiTableCell>
              <UiTableCell className="hidden md:table-cell" />
              <UiTableCell className="hidden md:table-cell" />
              <UiTableCell className="block border-0 px-0 py-0 font-semibold text-slate-700 md:table-cell md:p-2"><div className="flex items-center justify-between gap-3 md:block"><MobileTableLabel>Montant</MobileTableLabel><span>{formatCurrency(quoteTotals?.subtotal)}</span></div></UiTableCell>
              <UiTableCell className="hidden md:table-cell" />
            </UiTableRow>
          </UiTableFooter>
        </UiTable>
      </div>
    </>
  );

  const content = (
    <div className={standalone ? 'glass rounded-2xl p-5' : 'p-5 sm:p-6'}>
      <h2 className="text-2xl font-semibold tracking-tight text-slate-900">{app.name}</h2>

      {app.slug === 'moneygest' ? renderMoneyGest() : renderDevisPro()}

      <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-end">
        {app.slug !== 'moneygest' && (
          <button type="button" onClick={handleSaveDraft} className="inline-flex items-center justify-center gap-2 rounded-full border border-[#3A8E9C]/30 bg-white px-4 py-2 text-sm font-semibold text-[#3A8E9C] transition hover:bg-[#FCFBF8]">
            Enregistrer
          </button>
        )}
        <button type="button" onClick={handleGenerate} disabled={isGenerating} className="primary-button disabled:cursor-not-allowed disabled:opacity-60">
          <FileDown size={16} /> {isGenerating ? 'Génération…' : 'Générer le PDF'}
        </button>
      </div>

      {feedback && <p className="mt-3 text-sm font-medium text-emerald-600">{feedback}</p>}
    </div>
  );

  return content;
}

export function CompanionAppLauncher({ app, technician, renderTrigger }) {
  const [open, setOpen] = useState(false);
  const workspaceBySlug = {
    maintplan: MaintPlanWorkspace,
    solarset: SolarSetWorkspace,
    friopress: FrioPressWorkspace
  };
  const WorkspaceComponent = workspaceBySlug[app.slug] || CompanionAppWorkspace;

  return (
    <>
      {renderTrigger({ open: () => setOpen(true) })}
      <Dialog open={open} onOpenChange={setOpen}>
        <ModalContent className="profile-dialog p-0 sm:max-w-6xl">
          <div className="border-b border-[#D3CCBE] bg-[#F3EFE7] px-5 py-4">
            <ModalTitle className="text-left text-lg font-semibold text-slate-900">{app.name}</ModalTitle>
            <ModalDescription className="mt-1 text-left text-sm text-slate-500">
              Ouvrez l&apos;app dans une mini-fenêtre, remplissez le tableau et téléchargez le PDF.
            </ModalDescription>
          </div>
          <WorkspaceComponent app={app} technician={technician} />
        </ModalContent>
      </Dialog>
    </>
  );
}
