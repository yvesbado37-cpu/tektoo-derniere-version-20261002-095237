import React, { useEffect, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import Header from '@/components/directory/Header';
import TopNav from '@/components/directory/TopNav';
import FloatingMessenger from '@/components/directory/FloatingMessenger';
import NotificationToast from '@/components/directory/NotificationToast';
import NotificationPermissionPrompt from '@/components/directory/NotificationPermissionPrompt';
import ProBenefitsModal from '@/components/directory/ProBenefitsModal';
import ProHintBanner from '@/components/directory/ProHintBanner';
import { playClickSound } from '@/lib/buttonSound';

export default function Layout() {
  const location = useLocation();
  const [proOpen, setProOpen] = useState(false);

  useEffect(() => {
    const handler = (e) => {
      const btn = e.target.closest('button, [role="button"], a');
      if (btn && !btn.disabled && !btn.classList.contains('no-sound')) {
        playClickSound();
      }
    };
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, []);

  useEffect(() => {
    const openPro = () => setProOpen(true);
    window.addEventListener('tektoo-open-pro', openPro);
    return () => window.removeEventListener('tektoo-open-pro', openPro);
  }, []);
  return (
    <div className="flex h-[100dvh] flex-col overflow-hidden bg-background">
      <Header />
      <TopNav />
      <FloatingMessenger />
      <NotificationToast />
      <NotificationPermissionPrompt />
      <ProHintBanner />
      <ProBenefitsModal open={proOpen} onClose={() => setProOpen(false)} />
      <main className="min-h-0 flex-1 overflow-hidden">
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.12, ease: 'linear' }}
            className="h-full"
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}