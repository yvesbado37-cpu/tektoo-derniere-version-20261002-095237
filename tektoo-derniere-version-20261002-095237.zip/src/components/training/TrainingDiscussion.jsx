import React, { useEffect, useRef, useState } from 'react';
import { FileText, Loader2, Send } from 'lucide-react';
import { trainingErrorMessage, trainingRequest, trainingStatus } from '@/lib/training';

function TrainingAttachment({ message, auth, trainingId }) {
  const [url, setUrl] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const timer = useRef(null);
  useEffect(() => () => clearTimeout(timer.current), []);
  const open = async () => {
    setBusy(true); setError('');
    try {
      const result = await trainingRequest('attachment', { ...auth, trainingId, messageId: message.id });
      setUrl(result.signed_url);
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setUrl(''), 240000);
    } catch (err) { setError(trainingErrorMessage(err)); }
    finally { setBusy(false); }
  };
  return (
    <div className="mt-2">
      <button onClick={open} disabled={busy} className="flex items-center gap-2 text-sm font-semibold text-emerald-800 underline"><FileText size={16} />{busy ? 'Chargement…' : message.attachment_name}</button>
      {error && <p role="alert" className="mt-1 text-xs text-red-600">{error}</p>}
      {url && message.attachment_type?.startsWith('image/') && <img src={url} alt={message.attachment_name} className="mt-2 max-h-72 rounded-lg object-contain" />}
      {url && message.attachment_type?.startsWith('video/') && <video src={url} controls className="mt-2 max-h-72 rounded-lg" />}
      {url && <a href={url} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-xs font-semibold text-emerald-800 underline">Ouvrir / télécharger le fichier</a>}
    </div>
  );
}

/** @param {{training: import('@/lib/training').Training, auth: import('@/lib/training').TrainingAuth,
 * onTrainingChange: (training: import('@/lib/training').Training) => void,
 * onAccessDenied: (message: string) => void}} props */
export default function TrainingDiscussion({ training, auth, onTrainingChange, onAccessDenied }) {
  const [messages, setMessages] = useState(/** @type {import('@/lib/training').TrainingMessage[]} */ ([]));
  const [identity, setIdentity] = useState(/** @type {{id: string, name: string, isTrainer: boolean} | null} */ (null));
  const [selected, setSelected] = useState(/** @type {import('@/lib/training').TrainingMessage | null} */ (null));
  const [text, setText] = useState('');
  const [file, setFile] = useState(/** @type {File | null} */ (null));
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [hasOlder, setHasOlder] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const bottom = useRef(/** @type {HTMLDivElement | null} */ (null));
  const fileInput = useRef(/** @type {HTMLInputElement | null} */ (null));
  const callbacks = useRef({ onTrainingChange, onAccessDenied });
  callbacks.current = { onTrainingChange, onAccessDenied };
  const requestAuth = { ...auth, trainingId: training.id };
  const authKey = JSON.stringify(auth);

  const merge = (previous, next) => [...new Map([...previous, ...next].map((message) => [message.id, message])).values()]
    .sort((left, right) => left.created_date.localeCompare(right.created_date) || left.id.localeCompare(right.id));

  useEffect(() => {
    let active = true;
    let timer;
    const refresh = async () => {
      try {
        const result = await trainingRequest('history', { ...JSON.parse(authKey), trainingId: training.id });
        if (!active) return;
        setIdentity(result.identity); setSelected(result.selectedQuestion); setError('');
        setMessages((current) => merge(current, result.messages));
        if (result.messages.length === 100) setHasOlder(true);
        callbacks.current.onTrainingChange(result.training);
      } catch (err) {
        if (!active) return;
        const message = trainingErrorMessage(err);
        if (err?.response?.status === 401 || err?.response?.status === 403) {
          active = false;
          callbacks.current.onAccessDenied(message);
          return;
        }
        setError(message);
      } finally {
        if (active) timer = setTimeout(refresh, 3000);
      }
    };
    refresh();
    return () => { active = false; clearTimeout(timer); };
  }, [authKey, training.id]);

  const latestId = messages.at(-1)?.id;
  useEffect(() => { bottom.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, [latestId]);

  const loadOlder = async () => {
    if (!messages[0]) return;
    setLoadingOlder(true);
    try {
      const before = messages[0].created_date;
      const beforeIds = messages.filter((message) => message.created_date === before).map((message) => message.id);
      const result = await trainingRequest('history', { ...requestAuth, before, beforeIds });
      setMessages((current) => merge(result.messages, current));
      setHasOlder(result.messages.length === 100);
    } catch (err) { setError(trainingErrorMessage(err)); }
    finally { setLoadingOlder(false); }
  };

  const control = async (action, payload) => {
    setBusy(true); setError('');
    try {
      const result = await trainingRequest(action, { ...requestAuth, ...payload });
      onTrainingChange(result.training);
      if (action === 'select') setSelected(messages.find((message) => message.id === payload.messageId) || null);
    } catch (err) { setError(trainingErrorMessage(err)); }
    finally { setBusy(false); }
  };
  const send = async (event) => {
    event.preventDefault(); setBusy(true); setError('');
    try {
      const result = await trainingRequest('send', { ...requestAuth, text, ...(file ? { file } : {}) });
      setMessages((current) => merge(current, [result.message]));
      setText(''); setFile(null);
      if (fileInput.current) fileInput.current.value = '';
    } catch (err) { setError(trainingErrorMessage(err)); }
    finally { setBusy(false); }
  };
  const live = trainingStatus(training) === 'live';
  const canSend = live && identity && (identity.isTrainer || training.messages_enabled);
  return (
    <section className="mt-4 flex min-h-0 flex-1 flex-col overflow-hidden rounded-2xl border border-emerald-200 bg-[#ECF5EE]">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-emerald-200 bg-white px-4 py-3">
        <span className="text-sm font-semibold text-emerald-800">{identity ? `${identity.name} · ${identity.isTrainer ? 'Formateur' : 'Participant'}` : 'Connexion au groupe…'}</span>
        {identity?.isTrainer && live && (
          <label className="flex items-center gap-2 text-xs font-semibold text-slate-700">
            Messages des participants
            <input type="checkbox" role="switch" checked={training.messages_enabled} disabled={busy} onChange={(event) => control('toggle', { enabled: event.target.checked })} className="h-5 w-5 accent-emerald-700" />
          </label>
        )}
        {!training.messages_enabled && <span className="text-xs font-semibold text-amber-700">Messages participants suspendus</span>}
      </div>
      {selected && (
        <div className="border-b border-emerald-200 bg-emerald-100 px-4 py-3">
          <p className="text-xs font-semibold text-emerald-800">Question retenue · {selected.author_name}</p>
          <p className="mt-1 whitespace-pre-wrap break-words text-sm">{selected.text}</p>
          {identity?.isTrainer && live && <button onClick={() => control('select', { messageId: '' })} disabled={busy} className="mt-2 text-xs font-semibold text-emerald-800 underline">Terminer cette étape / désélectionner</button>}
        </div>
      )}
      <div className="scroll-pane min-h-0 flex-1 overflow-y-auto p-4">
        {hasOlder && <button onClick={loadOlder} disabled={loadingOlder} className="mb-3 w-full text-xs font-semibold text-emerald-700">{loadingOlder ? 'Chargement…' : 'Voir les messages précédents'}</button>}
        {!messages.length && <p className="text-center text-sm text-slate-500">{live ? 'La discussion peut commencer.' : 'Le groupe ouvrira à l’heure prévue.'}</p>}
        {messages.map((message) => {
          const own = message.author_id === identity?.id;
          const question = messages.find((item) => item.id === message.reply_to);
          return (
            <article key={message.id} className={`mb-3 max-w-[92%] rounded-xl p-3 shadow-sm sm:max-w-[80%] ${own ? 'ml-auto bg-emerald-100' : 'mr-auto bg-white'}`}>
              <p className={`text-xs font-semibold ${message.is_trainer ? 'text-emerald-700' : 'text-slate-600'}`}>{message.author_name}{message.is_trainer ? ' · Formateur' : ''}</p>
              {message.reply_to && <p className="mt-2 border-l-2 border-emerald-500 pl-2 text-xs text-slate-600">Réponse à {question ? `${question.author_name} : ${question.text}` : 'une question sélectionnée'}</p>}
              {message.text && <p className="mt-1 whitespace-pre-wrap break-words text-sm text-slate-900">{message.text}</p>}
              {message.attachment_name && live && <TrainingAttachment message={message} auth={auth} trainingId={training.id} />}
              <time className="mt-2 block text-right text-[10px] text-slate-500" dateTime={message.created_date}>{new Date(message.created_date).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</time>
              {identity?.isTrainer && !message.is_trainer && live && <button disabled={busy} onClick={() => control('select', { messageId: message.id })} className="mt-2 text-xs font-semibold text-emerald-800 underline">Sélectionner cette question</button>}
            </article>
          );
        })}
        <div ref={bottom} />
      </div>
      {error && <p role="alert" className="bg-white px-4 py-2 text-sm text-red-600">{error}</p>}
      {canSend ? (
        <form onSubmit={send} className="border-t border-emerald-200 bg-white p-3">
          {identity.isTrainer && (
            <label className="mb-2 block text-xs font-semibold text-emerald-700">Document, photo ou vidéo (25 Mo maximum)
              <input ref={fileInput} type="file" accept="application/pdf,text/plain,image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm" disabled={busy} onChange={(event) => setFile(event.target.files?.[0] || null)} className="mt-1 block max-w-full text-xs" />
            </label>
          )}
          <div className="flex items-end gap-2">
            <label className="flex-1"><span className="sr-only">Votre message</span><textarea rows={2} maxLength={4000} value={text} onChange={(event) => setText(event.target.value)} placeholder={selected && identity.isTrainer ? 'Répondre à la question retenue…' : 'Écrire un message…'} className="w-full resize-none rounded-xl border p-2 text-sm outline-none focus:border-emerald-600" /></label>
            <button disabled={busy || (!text.trim() && !file)} aria-label="Envoyer le message" className="rounded-full bg-emerald-700 p-3 text-white disabled:opacity-50">{busy ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}</button>
          </div>
        </form>
      ) : <p className="border-t border-emerald-200 bg-white p-3 text-center text-xs text-slate-500">{live ? 'Le formateur a suspendu les messages. Vous pouvez suivre la session.' : 'Les échanges sont fermés en dehors de la session.'}</p>}
    </section>
  );
}
