import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import { requestAndroidBootstrapPermissions } from '@/lib/downloadFile'
import '@/index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)

// Register push service worker early so background notifications work
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw-push.js').catch(() => {});
}

requestAndroidBootstrapPermissions().catch(() => {});